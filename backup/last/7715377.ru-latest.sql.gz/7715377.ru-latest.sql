--
-- PostgreSQL database dump
--

-- Dumped from database version 12.13 (Debian 12.13-1.pgdg110+1)
-- Dumped by pg_dump version 14.5 (Debian 14.5-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.addresses (
    id bigint NOT NULL,
    name_ru character varying(512) NOT NULL,
    user_ids jsonb NOT NULL,
    description character varying(512),
    history jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.addresses OWNER TO robert;

--
-- Name: addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.addresses_id_seq OWNER TO robert;

--
-- Name: addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.addresses_id_seq OWNED BY public.addresses.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.countries (
    id bigint NOT NULL,
    name_ru character varying(512) NOT NULL,
    name_en character varying(512) NOT NULL,
    user_ids jsonb NOT NULL,
    iso_alpha2 character(2),
    iso_alpha3 character(3),
    iso_num bigint,
    phone_code bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.countries OWNER TO robert;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.countries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.countries_id_seq OWNER TO robert;

--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: employee_job; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.employee_job (
    id bigint NOT NULL,
    employee_id bigint NOT NULL,
    employer_id bigint NOT NULL,
    user_ids jsonb NOT NULL,
    contract_number character varying(32),
    hired_date date,
    fired_date date,
    occupation_id bigint,
    work_address_id bigint,
    history jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.employee_job OWNER TO robert;

--
-- Name: employee_job_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.employee_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_job_id_seq OWNER TO robert;

--
-- Name: employee_job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.employee_job_id_seq OWNED BY public.employee_job.id;


--
-- Name: employee_turnover; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.employee_turnover (
    id bigint NOT NULL,
    employee_id bigint NOT NULL,
    employer_id bigint,
    date date,
    status_id bigint NOT NULL,
    user_ids jsonb NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.employee_turnover OWNER TO robert;

--
-- Name: employee_turnover_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.employee_turnover_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_turnover_id_seq OWNER TO robert;

--
-- Name: employee_turnover_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.employee_turnover_id_seq OWNED BY public.employee_turnover.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.employees (
    id bigint NOT NULL,
    passport_number character varying(32) NOT NULL,
    last_name_ru character varying(64) NOT NULL,
    first_name_ru character varying(64) NOT NULL,
    citizenship_id bigint NOT NULL,
    status_id bigint NOT NULL,
    user_ids jsonb NOT NULL,
    gender character varying(32),
    passport_serie character varying(32),
    passport_issuer_code character varying(32),
    resident_document_serie character varying(32),
    resident_document_number character varying(32),
    phone character varying(32),
    work_permit_serie character varying(32),
    work_permit_number character varying(32),
    invitation_number character varying(32),
    cert_number character varying(32),
    visa_multiplicity character varying(32),
    visa_category character varying(32),
    visa_serie character varying(32),
    visa_number character varying(32),
    migr_card_serie character varying(32),
    migr_card_number character varying(32),
    middle_name_ru character varying(64),
    last_name_en character varying(64),
    first_name_en character varying(64),
    middle_name_en character varying(64),
    entry_checkpoint character varying(64),
    passport_issuer character varying(128),
    resident_document character varying(128),
    cert_issuer character varying(128),
    birth_place text,
    address text,
    history jsonb,
    birth_date date,
    passport_issued_date date,
    passport_expired_date date,
    resident_document_issued_date date,
    resident_document_expired_date date,
    work_permit_issued_date date,
    work_permit_started_date date,
    work_permit_expired_date date,
    work_permit_paid_till_date date,
    taxpayer_id_issued_date date,
    cert_issued_date date,
    visa_issued_date date,
    visa_started_date date,
    visa_expired_date date,
    entry_date date,
    migr_card_issued_date date,
    reg_date date,
    departure_date date,
    whence_id bigint,
    permit_id bigint,
    taxpayer_id bigint,
    host_id bigint,
    reg_address_id bigint,
    real_address_id bigint,
    resident_document_issuer_id bigint,
    work_permit_issuer_id bigint,
    visa_issuer_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.employees OWNER TO robert;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.employees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employees_id_seq OWNER TO robert;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: employers; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.employers (
    id bigint NOT NULL,
    name_ru character varying(512) NOT NULL,
    full_name_ru character varying(512) NOT NULL,
    director_id bigint NOT NULL,
    type_id bigint NOT NULL,
    user_ids jsonb NOT NULL,
    taxpayer_code character varying(32),
    active_business_type character varying(32),
    rcoad character varying(32),
    bcc character varying(32),
    acc_book_number character varying(32),
    account_number character varying(32),
    ca character varying(32),
    bic character varying(32),
    acc_reg_number character varying(32),
    uni_reg_number character varying(32),
    prime_reg_number character varying(32),
    bank character varying(64),
    phone jsonb,
    history jsonb,
    acc_reg_date date,
    prime_reg_date date,
    uni_reg_date date,
    booker_id bigint,
    taxpayer_id bigint,
    address_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.employers OWNER TO robert;

--
-- Name: employers_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.employers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employers_id_seq OWNER TO robert;

--
-- Name: employers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.employers_id_seq OWNED BY public.employers.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO robert;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO robert;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO robert;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO robert;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: occupations; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.occupations (
    id bigint NOT NULL,
    user_ids jsonb NOT NULL,
    code character varying(32) NOT NULL,
    name_ru character varying(128) NOT NULL,
    description character varying(512),
    history jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.occupations OWNER TO robert;

--
-- Name: occupations_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.occupations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.occupations_id_seq OWNER TO robert;

--
-- Name: occupations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.occupations_id_seq OWNED BY public.occupations.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO robert;

--
-- Name: permits; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.permits (
    id bigint NOT NULL,
    employer_id bigint NOT NULL,
    user_ids jsonb NOT NULL,
    number character varying(64) NOT NULL,
    quota_id bigint,
    total integer,
    issued_date date,
    expired_date date,
    history jsonb,
    details jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permits OWNER TO robert;

--
-- Name: permits_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.permits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permits_id_seq OWNER TO robert;

--
-- Name: permits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.permits_id_seq OWNED BY public.permits.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO robert;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO robert;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: quotas; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.quotas (
    id bigint NOT NULL,
    year character varying(32) NOT NULL,
    employer_id bigint NOT NULL,
    user_ids jsonb NOT NULL,
    total integer,
    history jsonb,
    details jsonb,
    issued_date date,
    expired_date date,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.quotas OWNER TO robert;

--
-- Name: quotas_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.quotas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quotas_id_seq OWNER TO robert;

--
-- Name: quotas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.quotas_id_seq OWNED BY public.quotas.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO robert;

--
-- Name: staff; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.staff (
    id bigint NOT NULL,
    year character varying(32) NOT NULL,
    month character varying(32) NOT NULL,
    employer_id bigint NOT NULL,
    employees jsonb NOT NULL,
    user_ids jsonb NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.staff OWNER TO robert;

--
-- Name: staff_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.staff_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_id_seq OWNER TO robert;

--
-- Name: staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.staff_id_seq OWNED BY public.staff.id;


--
-- Name: statuses; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.statuses (
    id bigint NOT NULL,
    name_en character varying(32) NOT NULL,
    name_ru character varying(32) NOT NULL,
    user_ids jsonb NOT NULL
);


ALTER TABLE public.statuses OWNER TO robert;

--
-- Name: statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.statuses_id_seq OWNER TO robert;

--
-- Name: statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.statuses_id_seq OWNED BY public.statuses.id;


--
-- Name: team_invitations; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.team_invitations (
    id bigint NOT NULL,
    team_id bigint NOT NULL,
    email character varying(255) NOT NULL,
    role character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.team_invitations OWNER TO robert;

--
-- Name: team_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.team_invitations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_invitations_id_seq OWNER TO robert;

--
-- Name: team_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.team_invitations_id_seq OWNED BY public.team_invitations.id;


--
-- Name: team_user; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.team_user (
    id bigint NOT NULL,
    team_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.team_user OWNER TO robert;

--
-- Name: team_user_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.team_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_user_id_seq OWNER TO robert;

--
-- Name: team_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.team_user_id_seq OWNED BY public.team_user.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.teams (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    personal_team boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.teams OWNER TO robert;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_id_seq OWNER TO robert;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: telescope_entries; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.telescope_entries (
    sequence bigint NOT NULL,
    uuid uuid NOT NULL,
    batch_id uuid NOT NULL,
    family_hash character varying(255),
    should_display_on_index boolean DEFAULT true NOT NULL,
    type character varying(20) NOT NULL,
    content text NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.telescope_entries OWNER TO robert;

--
-- Name: telescope_entries_sequence_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.telescope_entries_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telescope_entries_sequence_seq OWNER TO robert;

--
-- Name: telescope_entries_sequence_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.telescope_entries_sequence_seq OWNED BY public.telescope_entries.sequence;


--
-- Name: telescope_entries_tags; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.telescope_entries_tags (
    entry_uuid uuid NOT NULL,
    tag character varying(255) NOT NULL
);


ALTER TABLE public.telescope_entries_tags OWNER TO robert;

--
-- Name: telescope_monitoring; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.telescope_monitoring (
    tag character varying(255) NOT NULL
);


ALTER TABLE public.telescope_monitoring OWNER TO robert;

--
-- Name: types; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.types (
    id bigint NOT NULL,
    user_ids jsonb NOT NULL,
    code character varying(32) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.types OWNER TO robert;

--
-- Name: types_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.types_id_seq OWNER TO robert;

--
-- Name: types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.types_id_seq OWNED BY public.types.id;


--
-- Name: usage_permits; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.usage_permits (
    id bigint NOT NULL,
    name_ru character varying(64) NOT NULL,
    user_ids jsonb NOT NULL,
    signing_date date,
    history jsonb,
    address_id bigint,
    employer_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.usage_permits OWNER TO robert;

--
-- Name: usage_permits_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.usage_permits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usage_permits_id_seq OWNER TO robert;

--
-- Name: usage_permits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.usage_permits_id_seq OWNED BY public.usage_permits.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: robert
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    current_team_id bigint,
    profile_photo_path text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    two_factor_secret text,
    two_factor_recovery_codes text
);


ALTER TABLE public.users OWNER TO robert;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: robert
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO robert;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: robert
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: addresses id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.addresses ALTER COLUMN id SET DEFAULT nextval('public.addresses_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: employee_job id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employee_job ALTER COLUMN id SET DEFAULT nextval('public.employee_job_id_seq'::regclass);


--
-- Name: employee_turnover id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employee_turnover ALTER COLUMN id SET DEFAULT nextval('public.employee_turnover_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: employers id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employers ALTER COLUMN id SET DEFAULT nextval('public.employers_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: occupations id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.occupations ALTER COLUMN id SET DEFAULT nextval('public.occupations_id_seq'::regclass);


--
-- Name: permits id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.permits ALTER COLUMN id SET DEFAULT nextval('public.permits_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: quotas id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.quotas ALTER COLUMN id SET DEFAULT nextval('public.quotas_id_seq'::regclass);


--
-- Name: staff id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.staff ALTER COLUMN id SET DEFAULT nextval('public.staff_id_seq'::regclass);


--
-- Name: statuses id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.statuses ALTER COLUMN id SET DEFAULT nextval('public.statuses_id_seq'::regclass);


--
-- Name: team_invitations id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.team_invitations ALTER COLUMN id SET DEFAULT nextval('public.team_invitations_id_seq'::regclass);


--
-- Name: team_user id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.team_user ALTER COLUMN id SET DEFAULT nextval('public.team_user_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: telescope_entries sequence; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.telescope_entries ALTER COLUMN sequence SET DEFAULT nextval('public.telescope_entries_sequence_seq'::regclass);


--
-- Name: types id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.types ALTER COLUMN id SET DEFAULT nextval('public.types_id_seq'::regclass);


--
-- Name: usage_permits id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.usage_permits ALTER COLUMN id SET DEFAULT nextval('public.usage_permits_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.addresses (id, name_ru, user_ids, description, history, created_at, updated_at) FROM stdin;
1	Тверская обл., г. Кимры, ул. Ленина, д. 66	[2, 3]		[{"date": "2018-05-11 13:31:17", "user": "208", "prev_value": {"name": "г. Кимры, ул. Ленина, д. 66"}}, {"date": "2019-10-07 13:56:16", "user": "209", "prev_value": {"name": "171506, Тверская обл., г. Кимры, ул. Ленина, д. 66"}}, {"date": "2019-10-07 14:22:55", "user": "209", "prev_value": {"name": "171506, Тверская область,город Кимры,улица Ленина,дом 66"}}, {"date": "2019-10-11 11:46:19", "user": "209", "prev_value": {"name": "171506, Тверская обл.,город Кимры,улица Ленина,дом 66"}}, {"date": "2019-10-14 13:49:8", "user": "209", "prev_value": {"name": "171506, Тверская обл.,г. Кимры,ул. Ленина,д. 66"}}, {"date": "2019-11-01 13:33:26", "user": "207", "prev_value": {"name": " Тверская обл.,г. Кимры,ул. Ленина,д. 66"}}]	\N	\N
5	г. Москва, Ленинский пр., д. 11, стр. 1	[2]		[{"date": "2018-04-07 22:33:5", "user": "211", "prev_value": {"name": "г. Москва, д. 11, Ленинский пр., стр. 1"}}]	\N	\N
6	г. Москва, пр. Мира, д. 20, кор. 1, оф. 2	[2]		\N	\N	\N
7	Кимрский р-н, дер. Титово, д. 35	[2, 3, 4]		[{"date": "2018-12-05 8:49:36", "user": "208", "prev_value": {"name": "Кимрский р-он, дер.Титово, д.35а"}}, {"date": "2019-09-19 13:7:38", "user": "207", "prev_value": {"name": "Кимрский р-он, дер. Титово, д. 35"}}]	\N	\N
8	г. Кимры, ул. Ульяновская, д. 22а	[3, 2]		[{"date": "2018-12-04 18:37:39", "user": "208", "prev_value": {"name": "г.Кимры,ул.Ульяновская д.22а"}}]	\N	\N
9	г. Кимры, ул. 50 Лет ВЛКСМ, д. 28, кв. 87	[3, 2]		[{"date": "2018-12-04 18:38:4", "user": "208", "prev_value": {"name": "г.Кимры,ул.50 Лет ВЛКСМ д.28кв.87"}}]	\N	\N
11	г. Москва, ул. Перекопская, д. 21, кв. 56	[3, 2]		[{"date": "2018-12-04 18:39:7", "user": "208", "prev_value": {"name": "г.Москва ,ул.Перекопская д.21кв.56"}}]	\N	\N
12	Тверская обл., Кимрский р-н, пгт. Белый Городок, ул. Главная, д. 22, кв. 3	[2, 3, 4]		[{"date": "2018-12-05 8:50:14", "user": "208", "prev_value": {"name": "Тверская обл., Кимрский р-он, пгт. Белый Городок, ул. Главная, д.22, кв. 3"}}, {"date": "2019-09-19 13:6:18", "user": "207", "prev_value": {"name": "Тверская обл., Кимрский р-он, пгт. Белый Городок, ул. Главная, д. 22, кв. 3"}}]	\N	\N
14	г. Москва, ул. Крутицкий вал, д. 3, корп. 2, кв. 36	[2, 3, 4]		[{"date": "2019-03-11 15:9:40", "user": "209", "prev_value": []}, {"date": "2019-09-19 13:6:39", "user": "207", "prev_value": {"name": "г.Москва ,ул.Крутицкий вал,д.3,корп.2,кв.36"}}]	\N	\N
16	г. Уфа, ул. Пушкина, д. 45, кор. 2, оф. 11,12,13,14	[0]		[{"date": "2020-02-06 11:54:4", "user": "207", "prev_value": []}]	\N	\N
17	123308, Москва, ул. Мнёвники, д. 1	[0]		[{"date": "2020-04-21 12:11:38", "user": "207", "prev_value": []}]	\N	\N
18	142600 Московская обл., \r\nг. Орехово-Зуево, ул. Ленина, д. 102	[0]		[{"date": "2020-04-21 12:16:55", "user": "207", "prev_value": []}]	\N	\N
20	г. Рязань, ул. Новоселов, д. 35а, кв. 175	[3, 2]		[{"date": "2022-07-26 13:59:41", "user": "209", "prev_value": []}, {"date": "2022-07-26 15:51:16", "user": "209", "prev_value": {"name": "г.Рязань,ул.Новосёлов,д.35а,кв.175"}}, {"date": "2022-12-10 12:14:30", "user": 3, "prev_value": {"name_ru": "г.Рязань,ул.Новоселов,д.35а,кв.175"}}]	\N	2022-12-10 12:14:30
3	г. Тверь, ул. Грибоедова, д. 34/68, к .1	[3, 2]		[{"date": "2022-12-10 12:14:48", "user": 3, "prev_value": {"name_ru": "г. Тверь, ул. Грибоедова, 34/68 к.1"}}, {"date": "2023-01-04 11:20:18", "user": 1, "prev_value": {"name_ru": "г. Тверь, ул. Грибоедова, д. 34/68, к.1"}}]	\N	2023-01-04 11:20:18
13	Тверская обл., г. Кимры, пр. Лоткова, д. 11, кв. 64	[2, 3]		[{"date": "2019-01-10 11:5:16", "user": "209", "prev_value": []}, {"date": "2019-09-19 13:7:2", "user": "207", "prev_value": {"name": "Тверская обл.,г.Кимры,пр.Лоткова д.11,кв.64"}}, {"date": "2023-01-04 11:20:41", "user": 1, "prev_value": {"name_ru": "Тверская обл., г. Кимры, пр. Лоткова, д.11, кв. 64"}}]	\N	2023-01-04 11:20:41
4	г. Кимры, ул. Ленина, д. 66, помещение 712	[3, 2, 5]		[{"date": "2020-03-05 14:29:37", "user": "209", "prev_value": {"name": "г. Кимры, ул. Ленина, д. 111", "ownership_certificate": ""}}, {"date": "2023-01-04 11:18:52", "user": 1, "prev_value": {"name_ru": "г. Кимры, ул. Ленина, д.66,помещение 712"}}, {"date": "2023-01-04 17:5:39", "user": 1, "prev_value": {"name_ru": "г. Кимры, ул. Ленина, д.66, помещение 712"}}]	\N	2023-01-04 17:05:39
2	Тверская обл., г. Кимры, ул. Ленина, д. 111	[3, 2, 4]		[{"date": "2019-09-19 13:6:2", "user": "207", "prev_value": {"name": "Тверская область, Кимрский район, п. Приволжский, ул. Лесная, д. 8"}}, {"date": "2019-10-07 13:54:12", "user": "209", "prev_value": {"name": "Тверская обл., Кимрский р-н, п. Приволжский, ул. Лесная, д. 8"}}, {"date": "2019-10-07 14:25:13", "user": "209", "prev_value": {"name": "171531Тверская область,Кимрский район,поселок Приволжский,улица Лесная,дом 8"}}, {"date": "2019-10-07 14:27:44", "user": "209", "prev_value": {"name": "171531 Тверская обл., Кимрский р-он,пос. Приволжский, ул.  Лесная, д. 8"}}, {"date": "2019-10-14 13:48:59", "user": "209", "prev_value": {"name": "171531Тверская обл. Кимрский р-он пос.Приволжский, ул.Лесная, д.8"}}, {"date": "2019-10-17 12:6:25", "user": "209", "prev_value": {"name": "Тверская обл. Кимрский р-он пос.Приволжский, ул.Лесная, д.8"}}, {"date": "2019-10-17 12:9:11", "user": "209", "prev_value": {"name": " Кимрский р-он пос.Приволжский, ул.Лесная, д.8"}}, {"date": "2019-10-17 12:10:1", "user": "209", "prev_value": {"name": "Тверская Кимрский  пос.Приволжский, ул.Лесная, д.8"}}, {"date": "2019-10-17 12:12:32", "user": "209", "prev_value": {"name": "Тверская область Кимрский  район пос.Приволжский, ул.Лесная, д.8"}}, {"date": "2019-10-29 13:53:20", "user": "209", "prev_value": {"name": "Тверская обл.  Кимрский  р-он  пос.Приволжский,  ул. Лесная,  д.8"}}, {"date": "2019-10-29 13:55:0", "user": "209", "prev_value": {"name": "Тверская обл.        Кимрский  р-он          пос.Приволжский,  ул. Лесная,  д.8"}}, {"date": "2019-10-29 13:55:33", "user": "209", "prev_value": {"name": "Тверская обл.                             Кимрский  р-он          пос.Приволжский,  ул. Лесная,  д.8"}}, {"date": "2019-10-29 14:11:0", "user": "209", "prev_value": {"name": "Тверская обл.         Кимрский  р-он          пос.Приволжский,  ул. Лесная,  д.8"}}, {"date": "2019-11-01 13:33:39", "user": "207", "prev_value": {"name": "Тверская обл., Кимрский  р-он, пос.Приволжский,  ул. Лесная,  д.8"}}, {"date": "2019-11-01 13:37:33", "user": "207", "prev_value": {"name": "Тверская обл., Кимрский  р-н, пос. Приволжский,  ул. Лесная,  д. 8"}}, {"date": "2019-11-15 23:53:56", "user": "207", "prev_value": {"ownership_certificate": ""}}, {"date": "2019-11-18 0:42:20", "user": "207", "prev_value": {"ownership_certificate": "Договор аренды помещения № б/н от 01.11.2018"}}, {"date": "2019-11-18 0:43:59", "user": "207", "prev_value": {"ownership_certificate": "Договор аренды помещения № б/н от 01.11.2018"}}, {"date": "2019-11-18 0:45:27", "user": "207", "prev_value": {"ownership_certificate": "Договор аренды помещения № б/н от 01.11.2018"}}, {"date": "2019-11-18 0:45:45", "user": "207", "prev_value": {"ownership_certificate": "{\\"ownership_certificate0\\":{\\"employer_id\\":\\"1\\",\\"certificate\\":\\"\\\\u0414\\\\u043e\\\\u0433\\\\u043e\\\\u0432\\\\u043e\\\\u0440 \\\\u0430\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u044b \\\\u043f\\\\u043e\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u2116 \\\\u0431\\\\/\\\\u043d \\\\u043e\\\\u0442 09.01.2018\\\\t\\"}}"}}, {"date": "2019-11-18 0:46:9", "user": "207", "prev_value": {"ownership_certificate": "{\\"ownership_certificate0\\":{\\"employer_id\\":\\"1\\",\\"certificate\\":\\"\\\\u0414\\\\u043e\\\\u0433\\\\u043e\\\\u0432\\\\u043e\\\\u0440 \\\\u0430\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u044b \\\\u043f\\\\u043e\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u2116 \\\\u0431\\\\/\\\\u043d \\\\u043e\\\\u0442 09.01.2018\\\\t\\"},\\"ownership_certificate1\\":{\\"employer_id\\":\\"7\\",\\"certificate\\":\\"\\\\u0414\\\\u043e\\\\u0433\\\\u043e\\\\u0432\\\\u043e\\\\u0440 \\\\u0430\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u044b \\\\u043f\\\\u043e\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u2116 \\\\u0431\\\\/\\\\u043d \\\\u043e\\\\u0442 01.09.2018\\\\t\\"},\\"ownership_certificate2\\":{\\"employer_id\\":\\"\\",\\"certificate\\":\\"\\\\u0414\\\\u043e\\\\u0433\\\\u043e\\\\u0432\\\\u043e\\\\u0440 \\\\u0430\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u044b \\\\u043f\\\\u043e\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u2116 \\\\u0431\\\\/\\\\u043d \\\\u043e\\\\u0442 01.11.2018\\\\t\\"}}"}}, {"date": "2019-11-18 10:32:45", "user": "207", "prev_value": {"ownership_certificate": "{\\"ownership_certificate0\\":{\\"employer_id\\":\\"1\\",\\"certificate\\":\\"\\\\u0414\\\\u043e\\\\u0433\\\\u043e\\\\u0432\\\\u043e\\\\u0440 \\\\u0430\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u044b \\\\u043f\\\\u043e\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u2116 \\\\u0431\\\\/\\\\u043d \\\\u043e\\\\u0442 09.01.2018\\\\t\\"},\\"ownership_certificate1\\":{\\"employer_id\\":\\"7\\",\\"certificate\\":\\"\\\\u0414\\\\u043e\\\\u0433\\\\u043e\\\\u0432\\\\u043e\\\\u0440 \\\\u0430\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u044b \\\\u043f\\\\u043e\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u2116 \\\\u0431\\\\/\\\\u043d \\\\u043e\\\\u0442 01.09.2018\\\\t\\"},\\"ownership_certificate2\\":{\\"employer_id\\":\\"4\\",\\"certificate\\":\\"\\\\u0414\\\\u043e\\\\u0433\\\\u043e\\\\u0432\\\\u043e\\\\u0440 \\\\u0430\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u044b \\\\u043f\\\\u043e\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u2116 \\\\u0431\\\\/\\\\u043d \\\\u043e\\\\u0442 01.11.2018\\\\t\\"}}"}}, {"date": "2019-11-19 9:12:58", "user": "207", "prev_value": {"name": "Тверская обл., Кимрский р-н, пос. Приволжский,  ул. Лесная,  д. 8"}}, {"date": "2020-11-18 12:31:54", "user": "209", "prev_value": {"ownership_certificate": "{\\"employer_id\\":[\\"1\\",\\"7\\",\\"4\\"],\\"certificate\\":[\\"Договор аренды помещения № б/н от 09.01.2018\\",\\"Договор аренды помещения № б/н от 01.09.2018\\",\\"Договор аренды помещения № б/н от 01.11.2018\\\\n\\\\n\\"]}"}}, {"date": "2020-11-18 12:33:59", "user": "209", "prev_value": {"ownership_certificate": "{\\"employer_id\\":[\\"1\\",\\"7\\",\\"4\\"],\\"certificate\\":[\\"Договор аренды помещения № б/н от 01.11.2020\\",\\"Договор аренды помещения № б/н от 01.09.2018\\",\\"Договор аренды помещения № б/н от 01.11.2018\\\\n\\\\n\\"]}"}}, {"date": "2021-01-13 12:26:35", "user": "209", "prev_value": {"ownership_certificate": "{\\"employer_id\\":[\\"1\\",\\"7\\",\\"4\\"],\\"certificate\\":[\\"Договор аренды помещения № б/н от 01.11.2020\\",\\"Договор аренды помещения № б/н от 21.09.2020\\",\\"Договор аренды помещения № б/н от 31.08.2020\\\\n\\\\n\\"]}"}}, {"date": "2021-11-16 10:4:52", "user": "209", "prev_value": {"ownership_certificate": "{\\"employer_id\\":[\\"1\\",\\"7\\",\\"4\\"],\\"certificate\\":[\\"Договор аренды помещения № б/н от 01.11.2020\\",\\"Договор аренды помещения № б/н от 01.10.2020\\",\\"Договор аренды помещения № б/н от 01.09.2020\\\\n\\\\n\\"]}"}}, {"date": "2022-06-16 10:48:46", "user": "209", "prev_value": {"name": "Тверская обл., Кимрский р-н, пос. Приволжский, ул. Лесная, д. 8"}}, {"date": "2022-06-16 10:49:53", "user": "209", "prev_value": {"ownership_certificate": "{\\"employer_id\\":[\\"1\\",\\"7\\",\\"4\\"],\\"certificate\\":[\\"Договор аренды помещения № б/н от 30.09.2021\\",\\"Договор аренды помещения № б/н от 01.10.2020\\",\\"Договор аренды помещения № б/н от 01.08.2021\\\\n\\\\n\\"]}"}}, {"date": "2022-06-16 10:51:21", "user": "209", "prev_value": {"name": "Тверская обл., г.Кимры,ул.Ленина д.111,Здание  1"}}, {"date": "2022-07-01 13:27:58", "user": "209", "prev_value": {"name": "Тверская обл., г.Кимры,ул.Ленина д.111,Здание  2"}}, {"date": "2022-07-01 13:29:56", "user": "209", "prev_value": {"name": "Тверская обл., г.Кимры,ул.Ленина д.111,Здание  ", "ownership_certificate": "{\\"employer_id\\":[\\"1\\",\\"7\\",\\"4\\"],\\"certificate\\":[\\"Договор аренды помещения № 6 от 14.06.2022\\",\\"Договор аренды помещения № б/н от 01.10.2020\\",\\"Договор аренды помещения №5 от 14.06.2022\\\\n\\\\n\\"]}"}}, {"date": "2022-07-26 13:6:36", "user": "209", "prev_value": {"name": "Тверская обл., г.Кимры,ул.Ленина д.111,Здание  2"}}, {"date": "2022-12-10 12:17:46", "user": 3, "prev_value": {"name_ru": "Тверская обл., г.Кимры,ул.Ленина д.111,Здание  "}}]	\N	2022-12-10 12:17:46
15	г. Москва, ул. Б. Марфинская, д .4, корп. 3, кв. 9	[2, 3]		[{"date": "2019-03-29 14:36:20", "user": "209", "prev_value": []}, {"date": "2019-06-30 0:37:48", "user": "207", "prev_value": {"name": "Г.МОСКВА,УЛ.Б.МАРФИНСКАЯ Д.4,КОРП.3,КВ.9"}}, {"date": "2019-09-19 13:7:21", "user": "207", "prev_value": {"name": "Г.МОСКВА,УЛ.Б.МАРФИНСКАЯ, Д.4,КОРП.3,КВ.9"}}, {"date": "2023-01-04 11:19:45", "user": 1, "prev_value": {"name_ru": "Г. МОСКВА, УЛ. Б.МАРФИНСКАЯ, Д.4, КОРП. 3, КВ. 9"}}, {"date": "2023-01-04 17:10:10", "user": 1, "prev_value": {"name_ru": "Г. МОСКВА, УЛ. Б. МАРФИНСКАЯ, Д .4, КОРП. 3, КВ. 9"}}, {"date": "2023-01-04 17:10:20", "user": 1, "prev_value": {"name_ru": "Г. Москва, ул. Б. Марфинская, д .4, корп. 3, кв. 9"}}]	\N	2023-01-04 17:10:20
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.countries (id, name_ru, name_en, user_ids, iso_alpha2, iso_alpha3, iso_num, phone_code, created_at, updated_at) FROM stdin;
1	Афганистан	Afghanistan	["*"]	AF	AFG	4	93	2022-12-10 12:13:04	\N
2	Албания	Albania	["*"]	AL	ALB	8	355	2022-12-10 12:13:04	\N
3	Алжир	Algeria	["*"]	DZ	DZA	12	213	2022-12-10 12:13:04	\N
4	Американское Самоа	American Samoa	["*"]	AS	ASM	16	1684	2022-12-10 12:13:04	\N
5	Андорра	Andorra	["*"]	AD	AND	20	376	2022-12-10 12:13:04	\N
6	Ангола	Angola	["*"]	AO	AGO	24	244	2022-12-10 12:13:04	\N
7	Ангилья	Anguilla	["*"]	AI	AIA	660	1264	2022-12-10 12:13:04	\N
8	Антарктида	Antarctica	["*"]	AQ	\N	\N	0	2022-12-10 12:13:04	\N
9	Антигуа и Барбуда	Antigua and Barbuda	["*"]	AG	ATG	28	1268	2022-12-10 12:13:04	\N
10	Аргентина	Argentina	["*"]	AR	ARG	32	54	2022-12-10 12:13:04	\N
11	Армения	Armenia	["*"]	AM	ARM	51	374	2022-12-10 12:13:04	\N
12	Аруба	Aruba	["*"]	AW	ABW	533	297	2022-12-10 12:13:04	\N
13	Австралия	Australia	["*"]	AU	AUS	36	61	2022-12-10 12:13:04	\N
14	Австрия	Austria	["*"]	AT	AUT	40	43	2022-12-10 12:13:04	\N
15	Азербайджан	Azerbaijan	["*"]	AZ	AZE	31	994	2022-12-10 12:13:04	\N
16	Багамы	Bahamas	["*"]	BS	BHS	44	1242	2022-12-10 12:13:04	\N
17	Бахрейн	Bahrain	["*"]	BH	BHR	48	973	2022-12-10 12:13:04	\N
18	Бангладеш	Bangladesh	["*"]	BD	BGD	50	880	2022-12-10 12:13:04	\N
19	Барбадос	Barbados	["*"]	BB	BRB	52	1246	2022-12-10 12:13:04	\N
20	Беларyсь	Belarus	["*"]	BY	BLR	112	375	2022-12-10 12:13:04	\N
21	Бельгия	Belgium	["*"]	BE	BEL	56	32	2022-12-10 12:13:04	\N
22	Белиз	Belize	["*"]	BZ	BLZ	84	501	2022-12-10 12:13:04	\N
23	Бенин	Benin	["*"]	BJ	BEN	204	229	2022-12-10 12:13:04	\N
24	Бермуды	Bermuda	["*"]	BM	BMU	60	1441	2022-12-10 12:13:04	\N
25	Бутан	Bhutan	["*"]	BT	BTN	64	975	2022-12-10 12:13:04	\N
26	Боливия	Bolivia	["*"]	BO	BOL	68	591	2022-12-10 12:13:04	\N
27	Босния и Герцеговина	Bosnia and Herzegovina	["*"]	BA	BIH	70	387	2022-12-10 12:13:04	\N
28	Ботсвана	Botswana	["*"]	BW	BWA	72	267	2022-12-10 12:13:04	\N
29	Остров Буве	Bouvet Island	["*"]	BV	\N	\N	0	2022-12-10 12:13:04	\N
30	Бразилия	Brazil	["*"]	BR	BRA	76	55	2022-12-10 12:13:04	\N
31	Британская территория в Индийском океане	British Indian Ocean Territory	["*"]	IO	\N	\N	246	2022-12-10 12:13:04	\N
32	Бруней	Brunei Darussalam	["*"]	BN	BRN	96	673	2022-12-10 12:13:04	\N
33	Болгария	Bulgaria	["*"]	BG	BGR	100	359	2022-12-10 12:13:04	\N
34	Буркина-Фасо	Burkina Faso	["*"]	BF	BFA	854	226	2022-12-10 12:13:04	\N
35	Бурунди	Burundi	["*"]	BI	BDI	108	257	2022-12-10 12:13:04	\N
36	Камбоджа	Cambodia	["*"]	KH	KHM	116	855	2022-12-10 12:13:04	\N
37	Камерун	Cameroon	["*"]	CM	CMR	120	237	2022-12-10 12:13:04	\N
38	Канада	Canada	["*"]	CA	CAN	124	1	2022-12-10 12:13:04	\N
39	Кабо-Верде	Cape Verde	["*"]	CV	CPV	132	238	2022-12-10 12:13:04	\N
40	Каймановы острова	Cayman Islands	["*"]	KY	CYM	136	1345	2022-12-10 12:13:04	\N
41	ЦАР	Central African Republic	["*"]	CF	CAF	140	236	2022-12-10 12:13:04	\N
42	Чад	Chad	["*"]	TD	TCD	148	235	2022-12-10 12:13:04	\N
43	Чили	Chile	["*"]	CL	CHL	152	56	2022-12-10 12:13:04	\N
44	КНР	China	["*"]	CN	CHN	156	86	2022-12-10 12:13:04	\N
45	Остров Рождества	Christmas Island	["*"]	CX	\N	\N	61	2022-12-10 12:13:04	\N
46	Кокосовые острова	Cocos (Keeling) Islands	["*"]	CC	\N	\N	672	2022-12-10 12:13:04	\N
47	Колумбия	Colombia	["*"]	CO	COL	170	57	2022-12-10 12:13:04	\N
48	Коморы	Comoros	["*"]	KM	COM	174	269	2022-12-10 12:13:04	\N
49	ДР Конго	Congo	["*"]	CG	COG	178	242	2022-12-10 12:13:04	\N
50	Республика Конго	Congo, the Democratic Republic of the	["*"]	CD	COD	180	242	2022-12-10 12:13:04	\N
51	Острова Кука	Cook Islands	["*"]	CK	COK	184	682	2022-12-10 12:13:04	\N
52	Коста-Рика	Costa Rica	["*"]	CR	CRI	188	506	2022-12-10 12:13:04	\N
53	Кот-д’Ивуар	Cote D'Ivoire	["*"]	CI	CIV	384	225	2022-12-10 12:13:04	\N
54	Хорватия	Croatia	["*"]	HR	HRV	191	385	2022-12-10 12:13:04	\N
55	Куба	Cuba	["*"]	CU	CUB	192	53	2022-12-10 12:13:04	\N
56	Кипр	Cyprus	["*"]	CY	CYP	196	357	2022-12-10 12:13:04	\N
57	Чехия	Czech Republic	["*"]	CZ	CZE	203	420	2022-12-10 12:13:04	\N
58	Дания	Denmark	["*"]	DK	DNK	208	45	2022-12-10 12:13:04	\N
59	Джибути	Djibouti	["*"]	DJ	DJI	262	253	2022-12-10 12:13:04	\N
60	Доминика	Dominica	["*"]	DM	DMA	212	1767	2022-12-10 12:13:04	\N
61	Доминиканская Республика	Dominican Republic	["*"]	DO	DOM	214	1809	2022-12-10 12:13:04	\N
62	Эквадор	Ecuador	["*"]	EC	ECU	218	593	2022-12-10 12:13:04	\N
63	Египет	Egypt	["*"]	EG	EGY	818	20	2022-12-10 12:13:04	\N
64	Сальвадор	El Salvador	["*"]	SV	SLV	222	503	2022-12-10 12:13:04	\N
65	Экваториальная Гвинея	Equatorial Guinea	["*"]	GQ	GNQ	226	240	2022-12-10 12:13:04	\N
66	Эритрея	Eritrea	["*"]	ER	ERI	232	291	2022-12-10 12:13:04	\N
67	Эстония	Estonia	["*"]	EE	EST	233	372	2022-12-10 12:13:04	\N
68	Эфиопия	Ethiopia	["*"]	ET	ETH	231	251	2022-12-10 12:13:04	\N
69	Фолклендские острова (Мальвины)	Falkland Islands (Malvinas)	["*"]	FK	FLK	238	500	2022-12-10 12:13:04	\N
70	Фарерские острова	Faroe Islands	["*"]	FO	FRO	234	298	2022-12-10 12:13:04	\N
71	Фиджи	Fiji	["*"]	FJ	FJI	242	679	2022-12-10 12:13:04	\N
72	Финляндия	Finland	["*"]	FI	FIN	246	358	2022-12-10 12:13:04	\N
73	Франция	France	["*"]	FR	FRA	250	33	2022-12-10 12:13:04	\N
74	Французская Гвиана	French Guiana	["*"]	GF	GUF	254	594	2022-12-10 12:13:04	\N
75	Французская Полинезия	French Polynesia	["*"]	PF	PYF	258	689	2022-12-10 12:13:04	\N
76	Французские Южные и Антарктические Территории	French Southern Territories	["*"]	TF	\N	\N	0	2022-12-10 12:13:04	\N
77	Габон	Gabon	["*"]	GA	GAB	266	241	2022-12-10 12:13:04	\N
78	Гамбия	Gambia	["*"]	GM	GMB	270	220	2022-12-10 12:13:04	\N
79	Грузия	Georgia	["*"]	GE	GEO	268	995	2022-12-10 12:13:04	\N
80	Германия	Germany	["*"]	DE	DEU	276	49	2022-12-10 12:13:04	\N
81	Гана	Ghana	["*"]	GH	GHA	288	233	2022-12-10 12:13:04	\N
82	Гибралтар	Gibraltar	["*"]	GI	GIB	292	350	2022-12-10 12:13:04	\N
83	Греция	Greece	["*"]	GR	GRC	300	30	2022-12-10 12:13:04	\N
84	Гренландия	Greenland	["*"]	GL	GRL	304	299	2022-12-10 12:13:04	\N
85	Гренада	Grenada	["*"]	GD	GRD	308	1473	2022-12-10 12:13:04	\N
86	Гваделупа	Guadeloupe	["*"]	GP	GLP	312	590	2022-12-10 12:13:04	\N
87	Гуам	Guam	["*"]	GU	GUM	316	1671	2022-12-10 12:13:04	\N
88	Гватемала	Guatemala	["*"]	GT	GTM	320	502	2022-12-10 12:13:04	\N
89	Гвинея	Guinea	["*"]	GN	GIN	324	224	2022-12-10 12:13:04	\N
90	Гвинея-Биссау	Guinea-Bissau	["*"]	GW	GNB	624	245	2022-12-10 12:13:04	\N
91	Гвиана	Guyana	["*"]	GY	GUY	328	592	2022-12-10 12:13:04	\N
92	Гаити	Haiti	["*"]	HT	HTI	332	509	2022-12-10 12:13:04	\N
93	Херд и Макдональд	Heard Island and Mcdonald Islands	["*"]	HM	\N	\N	0	2022-12-10 12:13:04	\N
94	Ватикан	Holy See (Vatican City State)	["*"]	VA	VAT	336	39	2022-12-10 12:13:04	\N
95	Гондурас	Honduras	["*"]	HN	HND	340	504	2022-12-10 12:13:04	\N
96	Гонконг	Hong Kong	["*"]	HK	HKG	344	852	2022-12-10 12:13:04	\N
97	Венгрия	Hungary	["*"]	HU	HUN	348	36	2022-12-10 12:13:04	\N
98	Исландия	Iceland	["*"]	IS	ISL	352	354	2022-12-10 12:13:04	\N
99	Индия	India	["*"]	IN	IND	356	91	2022-12-10 12:13:04	\N
100	Индонезия	Indonesia	["*"]	ID	IDN	360	62	2022-12-10 12:13:04	\N
101	Иран	Iran, Islamic Republic of	["*"]	IR	IRN	364	98	2022-12-10 12:13:04	\N
102	Ирак	Iraq	["*"]	IQ	IRQ	368	964	2022-12-10 12:13:04	\N
103	Ирландия	Ireland	["*"]	IE	IRL	372	353	2022-12-10 12:13:04	\N
104	Израиль	Israel	["*"]	IL	ISR	376	972	2022-12-10 12:13:04	\N
105	Италия	Italy	["*"]	IT	ITA	380	39	2022-12-10 12:13:04	\N
106	Ямайка	Jamaica	["*"]	JM	JAM	388	1876	2022-12-10 12:13:04	\N
107	Япония	Japan	["*"]	JP	JPN	392	81	2022-12-10 12:13:04	\N
108	Иордания	Jordan	["*"]	JO	JOR	400	962	2022-12-10 12:13:04	\N
109	Казахстан	Kazakhstan	["*"]	KZ	KAZ	398	7	2022-12-10 12:13:04	\N
110	Кения	Kenya	["*"]	KE	KEN	404	254	2022-12-10 12:13:04	\N
111	Кирибати	Kiribati	["*"]	KI	KIR	296	686	2022-12-10 12:13:04	\N
112	КНДР	Korea, Democratic People's Republic of	["*"]	KP	PRK	408	850	2022-12-10 12:13:04	\N
113	Республика Корея	Korea, Republic of	["*"]	KR	KOR	410	82	2022-12-10 12:13:04	\N
114	Кувейт	Kuwait	["*"]	KW	KWT	414	965	2022-12-10 12:13:04	\N
115	Кыргызская Республика	Kyrgyz Republic	["*"]	KG	KGZ	417	996	2022-12-10 12:13:04	\N
116	Лаос	Lao People's Democratic Republic	["*"]	LA	LAO	418	856	2022-12-10 12:13:04	\N
117	Латвия	Latvia	["*"]	LV	LVA	428	371	2022-12-10 12:13:04	\N
118	Ливан	Lebanon	["*"]	LB	LBN	422	961	2022-12-10 12:13:04	\N
119	Лесото	Lesotho	["*"]	LS	LSO	426	266	2022-12-10 12:13:04	\N
120	Либерия	Liberia	["*"]	LR	LBR	430	231	2022-12-10 12:13:04	\N
121	Ливия	Libyan Arab Jamahiriya	["*"]	LY	LBY	434	218	2022-12-10 12:13:04	\N
122	Лихтенштейн	Liechtenstein	["*"]	LI	LIE	438	423	2022-12-10 12:13:04	\N
123	Литва	Lithuania	["*"]	LT	LTU	440	370	2022-12-10 12:13:04	\N
124	Люксембург	Luxembourg	["*"]	LU	LUX	442	352	2022-12-10 12:13:04	\N
125	Макао	Macao	["*"]	MO	MAC	446	853	2022-12-10 12:13:04	\N
126	Македония	Macedonia, the Former Yugoslav Republic of	["*"]	MK	MKD	807	389	2022-12-10 12:13:04	\N
127	Мадагаскар	Madagascar	["*"]	MG	MDG	450	261	2022-12-10 12:13:04	\N
128	Малави	Malawi	["*"]	MW	MWI	454	265	2022-12-10 12:13:04	\N
129	Малайзия	Malaysia	["*"]	MY	MYS	458	60	2022-12-10 12:13:04	\N
130	Мальдивы	Maldives	["*"]	MV	MDV	462	960	2022-12-10 12:13:04	\N
131	Мали	Mali	["*"]	ML	MLI	466	223	2022-12-10 12:13:04	\N
132	Мальта	Malta	["*"]	MT	MLT	470	356	2022-12-10 12:13:04	\N
133	Маршалловы Острова	Marshall Islands	["*"]	MH	MHL	584	692	2022-12-10 12:13:04	\N
134	Мартиника	Martinique	["*"]	MQ	MTQ	474	596	2022-12-10 12:13:04	\N
135	Мавритания	Mauritania	["*"]	MR	MRT	478	222	2022-12-10 12:13:04	\N
136	Маврикий	Mauritius	["*"]	MU	MUS	480	230	2022-12-10 12:13:04	\N
137	Майотта	Mayotte	["*"]	YT	\N	\N	269	2022-12-10 12:13:04	\N
138	Мексика	Mexico	["*"]	MX	MEX	484	52	2022-12-10 12:13:04	\N
139	Микронезия	Micronesia, Federated States of	["*"]	FM	FSM	583	691	2022-12-10 12:13:04	\N
140	Молдова	Moldova, Republic of	["*"]	MD	MDA	498	373	2022-12-10 12:13:04	\N
141	Монако	Monaco	["*"]	MC	MCO	492	377	2022-12-10 12:13:04	\N
142	Монголия	Mongolia	["*"]	MN	MNG	496	976	2022-12-10 12:13:04	\N
143	Монтсеррат	Montserrat	["*"]	MS	MSR	500	1664	2022-12-10 12:13:04	\N
144	Марокко	Morocco	["*"]	MA	MAR	504	212	2022-12-10 12:13:04	\N
145	Мозамбик	Mozambique	["*"]	MZ	MOZ	508	258	2022-12-10 12:13:04	\N
146	Мьянма	Myanmar	["*"]	MM	MMR	104	95	2022-12-10 12:13:04	\N
147	Намибия	Namibia	["*"]	NA	NAM	516	264	2022-12-10 12:13:04	\N
148	Науру	Nauru	["*"]	NR	NRU	520	674	2022-12-10 12:13:04	\N
149	Непал	Nepal	["*"]	NP	NPL	524	977	2022-12-10 12:13:04	\N
150	Нидерланды	Netherlands	["*"]	NL	NLD	528	31	2022-12-10 12:13:04	\N
151	Нидерландские Антильские острова	Netherlands Antilles	["*"]	AN	ANT	530	599	2022-12-10 12:13:04	\N
152	Новая Каледония	New Caledonia	["*"]	NC	NCL	540	687	2022-12-10 12:13:04	\N
153	Новая Зеландия	New Zealand	["*"]	NZ	NZL	554	64	2022-12-10 12:13:04	\N
154	Никарагуа	Nicaragua	["*"]	NI	NIC	558	505	2022-12-10 12:13:04	\N
155	Нигер	Niger	["*"]	NE	NER	562	227	2022-12-10 12:13:04	\N
156	Нигерия	Nigeria	["*"]	NG	NGA	566	234	2022-12-10 12:13:04	\N
157	Ниуэ	Niue	["*"]	NU	NIU	570	683	2022-12-10 12:13:04	\N
158	Остров Норфолк	Norfolk Island	["*"]	NF	NFK	574	672	2022-12-10 12:13:04	\N
159	Северные Марианские острова	Northern Mariana Islands	["*"]	MP	MNP	580	1670	2022-12-10 12:13:04	\N
160	Норвегия	Norway	["*"]	NO	NOR	578	47	2022-12-10 12:13:04	\N
161	Оман	Oman	["*"]	OM	OMN	512	968	2022-12-10 12:13:04	\N
162	Пакистан	Pakistan	["*"]	PK	PAK	586	92	2022-12-10 12:13:04	\N
163	Палау	Palau	["*"]	PW	PLW	585	680	2022-12-10 12:13:04	\N
164	Государство Палестина	Palestinian Territory, Occupied	["*"]	PS	\N	\N	970	2022-12-10 12:13:04	\N
165	Панама	Panama	["*"]	PA	PAN	591	507	2022-12-10 12:13:04	\N
166	Папуа-Новая Гвинея	Papua New Guinea	["*"]	PG	PNG	598	675	2022-12-10 12:13:04	\N
167	Парагвай	Paraguay	["*"]	PY	PRY	600	595	2022-12-10 12:13:04	\N
168	Перу	Peru	["*"]	PE	PER	604	51	2022-12-10 12:13:04	\N
169	Филиппины	Philippines	["*"]	PH	PHL	608	63	2022-12-10 12:13:04	\N
170	Острова Питкэрн	Pitcairn	["*"]	PN	PCN	612	0	2022-12-10 12:13:04	\N
171	Польша	Poland	["*"]	PL	POL	616	48	2022-12-10 12:13:04	\N
172	Португалия	Portugal	["*"]	PT	PRT	620	351	2022-12-10 12:13:04	\N
173	Пуэрто Рико	Puerto Rico	["*"]	PR	PRI	630	1787	2022-12-10 12:13:04	\N
174	Катар	Qatar	["*"]	QA	QAT	634	974	2022-12-10 12:13:04	\N
175	Реюньон	Reunion	["*"]	RE	REU	638	262	2022-12-10 12:13:04	\N
176	Румыния	Romania	["*"]	RO	ROM	642	40	2022-12-10 12:13:04	\N
177	Российская Федерация	Russian Federation	["*"]	RU	RUS	643	70	2022-12-10 12:13:04	\N
178	Руанда	Rwanda	["*"]	RW	RWA	646	250	2022-12-10 12:13:04	\N
179	Острова Святой Елены	Saint Helena	["*"]	SH	SHN	654	290	2022-12-10 12:13:04	\N
180	Сент-Китс и Невис	Saint Kitts and Nevis	["*"]	KN	KNA	659	1869	2022-12-10 12:13:04	\N
181	Сент-Люсия	Saint Lucia	["*"]	LC	LCA	662	1758	2022-12-10 12:13:04	\N
182	Сен-Пьер и Микелон	Saint Pierre and Miquelon	["*"]	PM	SPM	666	508	2022-12-10 12:13:04	\N
183	Сент-Винсент и Гренадины	Saint Vincent and the Grenadines	["*"]	VC	VCT	670	1784	2022-12-10 12:13:04	\N
184	Самоа	Samoa	["*"]	WS	WSM	882	684	2022-12-10 12:13:04	\N
185	Сан-Марино	San Marino	["*"]	SM	SMR	674	378	2022-12-10 12:13:04	\N
186	Сан-Томе и Принсипи	Sao Tome and Principe	["*"]	ST	STP	678	239	2022-12-10 12:13:04	\N
187	Саудовская Аравия	Saudi Arabia	["*"]	SA	SAU	682	966	2022-12-10 12:13:04	\N
188	Сенегал	Senegal	["*"]	SN	SEN	686	221	2022-12-10 12:13:04	\N
189	Сербия	Serbia	["*"]	RS	SRB	688	381	2022-12-10 12:13:04	\N
190	Сейшельские Острова	Seychelles	["*"]	SC	SYC	690	248	2022-12-10 12:13:04	\N
191	Сьерра-Леоне	Sierra Leone	["*"]	SL	SLE	694	232	2022-12-10 12:13:04	\N
192	Сингапур	Singapore	["*"]	SG	SGP	702	65	2022-12-10 12:13:04	\N
193	Словакия	Slovakia	["*"]	SK	SVK	703	421	2022-12-10 12:13:04	\N
194	Словения	Slovenia	["*"]	SI	SVN	705	386	2022-12-10 12:13:04	\N
195	Соломоновы Острова	Solomon Islands	["*"]	SB	SLB	90	677	2022-12-10 12:13:04	\N
196	Сомали	Somalia	["*"]	SO	SOM	706	252	2022-12-10 12:13:04	\N
197	ЮАР	South Africa	["*"]	ZA	ZAF	710	27	2022-12-10 12:13:04	\N
198	Южная Георгия и Южные Сандвичевы острова	South Georgia and the South Sandwich Islands	["*"]	GS	\N	\N	0	2022-12-10 12:13:04	\N
199	Испания	Spain	["*"]	ES	ESP	724	34	2022-12-10 12:13:04	\N
200	Шри-Ланка	Sri Lanka	["*"]	LK	LKA	144	94	2022-12-10 12:13:04	\N
201	Судан	Sudan	["*"]	SD	SDN	736	249	2022-12-10 12:13:04	\N
202	Суринам	Suriname	["*"]	SR	SUR	740	597	2022-12-10 12:13:04	\N
203	Шпицберген и Ян-Майен	Svalbard and Jan Mayen	["*"]	SJ	SJM	744	47	2022-12-10 12:13:04	\N
204	Свазиленд	Swaziland	["*"]	SZ	SWZ	748	268	2022-12-10 12:13:04	\N
205	Швеция	Sweden	["*"]	SE	SWE	752	46	2022-12-10 12:13:04	\N
206	Швейцария	Switzerland	["*"]	CH	CHE	756	41	2022-12-10 12:13:04	\N
207	Сирия	Syrian Arab Republic	["*"]	SY	SYR	760	963	2022-12-10 12:13:04	\N
208	Тайвань	Taiwan, Province of China	["*"]	TW	TWN	158	886	2022-12-10 12:13:04	\N
209	Таджикистан	Tajikistan	["*"]	TJ	TJK	762	992	2022-12-10 12:13:04	\N
210	Танзания	Tanzania, United Republic of	["*"]	TZ	TZA	834	255	2022-12-10 12:13:04	\N
211	Тайланд	Thailand	["*"]	TH	THA	764	66	2022-12-10 12:13:04	\N
212	Восточный Тимор	Timor-Leste	["*"]	TL	\N	\N	670	2022-12-10 12:13:04	\N
213	Того	Togo	["*"]	TG	TGO	768	228	2022-12-10 12:13:04	\N
214	Токелау	Tokelau	["*"]	TK	TKL	772	690	2022-12-10 12:13:04	\N
215	Тонга	Tonga	["*"]	TO	TON	776	676	2022-12-10 12:13:04	\N
216	Тринидад и Тобаго	Trinidad and Tobago	["*"]	TT	TTO	780	1868	2022-12-10 12:13:04	\N
217	Тунис	Tunisia	["*"]	TN	TUN	788	216	2022-12-10 12:13:04	\N
218	Турция	Turkey	["*"]	TR	TUR	792	90	2022-12-10 12:13:04	\N
219	Туркменистан	Turkmenistan	["*"]	TM	TKM	795	7370	2022-12-10 12:13:04	\N
220	Острова Туркс и Кайкос	Turks and Caicos Islands	["*"]	TC	TCA	796	1649	2022-12-10 12:13:04	\N
221	Тувалу	Tuvalu	["*"]	TV	TUV	798	688	2022-12-10 12:13:04	\N
222	Уганда	Uganda	["*"]	UG	UGA	800	256	2022-12-10 12:13:04	\N
223	Украина	Ukraine	["*"]	UA	UKR	804	380	2022-12-10 12:13:04	\N
224	Арабские Эмираты	United Arab Emirates	["*"]	AE	ARE	784	971	2022-12-10 12:13:04	\N
225	Великобритания	United Kingdom	["*"]	GB	GBR	826	44	2022-12-10 12:13:04	\N
226	США	United States	["*"]	US	USA	840	1	2022-12-10 12:13:04	\N
227	Отдаленные Острова США	United States Minor Outlying Islands	["*"]	UM	\N	\N	1	2022-12-10 12:13:04	\N
228	Уругвай	Uruguay	["*"]	UY	URY	858	598	2022-12-10 12:13:04	\N
229	Узбекистан	Uzbekistan	["*"]	UZ	UZB	860	998	2022-12-10 12:13:04	\N
230	Вануату	Vanuatu	["*"]	VU	VUT	548	678	2022-12-10 12:13:04	\N
231	Венесуэла	Venezuela	["*"]	VE	VEN	862	58	2022-12-10 12:13:04	\N
232	Вьетнам	Viet Nam	["*"]	VN	VNM	704	84	2022-12-10 12:13:04	\N
233	Виргинские острова (Британские)	Virgin Islands, British	["*"]	VG	VGB	92	1284	2022-12-10 12:13:04	\N
234	Виргинские острова (США)	Virgin Islands, U.s.	["*"]	VI	VIR	850	1340	2022-12-10 12:13:04	\N
235	Уэльс	Wallis and Futuna	["*"]	WF	WLF	876	681	2022-12-10 12:13:04	\N
236	Западная Сахара	Western Sahara	["*"]	EH	ESH	732	212	2022-12-10 12:13:04	\N
237	Йемен	Yemen	["*"]	YE	YEM	887	967	2022-12-10 12:13:04	\N
238	Замбия	Zambia	["*"]	ZM	ZMB	894	260	2022-12-10 12:13:04	\N
239	Зимбабве	Zimbabwe	["*"]	ZW	ZWE	716	263	2022-12-10 12:13:04	\N
\.


--
-- Data for Name: employee_job; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.employee_job (id, employee_id, employer_id, user_ids, contract_number, hired_date, fired_date, occupation_id, work_address_id, history, created_at, updated_at) FROM stdin;
3	15	1	[3, 2, 4]	63	2018-11-28	2019-11-26	7	0	\N	\N	\N
4	16	4	[2, 3, 4, 5]	14	2022-07-13	\N	30	0	\N	\N	\N
5	17	1	[2, 3, 4]	14	2016-06-06	2019-03-24	6	0	\N	\N	\N
6	18	2	[3, 2]		\N	\N	0	0	\N	\N	\N
7	19	1	[3, 5, 2]	3	2018-03-27	2019-02-05	1	0	\N	\N	\N
8	20	1	[3, 5, 2]	5	2018-03-27	2018-12-03	2	0	\N	\N	\N
9	21	1	[3, 5, 2]	6	2016-05-26	2018-03-15	1	0	\N	\N	\N
10	22	1	[3, 2, 4]	18	2016-06-06	2021-12-20	6	2	\N	\N	\N
11	23	1	[3, 4, 2]	13	2018-03-27	2019-01-29	6	0	\N	\N	\N
12	24	1	[3, 2, 4]	19	2016-06-06	2020-03-24	6	0	\N	\N	\N
13	25	1	[3, 2, 4]	11	2016-06-06	2021-04-12	1	0	\N	\N	\N
14	26	1	[3, 2, 4]	9	2016-06-06	2021-04-12	6	2	\N	\N	\N
15	27	1	[3, 2, 4]	2	2016-06-06	2020-03-24	1	2	\N	\N	\N
16	28	1	[3, 2, 4]	89	2020-11-21	2022-04-05	1	2	\N	\N	\N
17	29	1	[3, 4, 2]	16	2018-03-27	2019-02-28	1	0	\N	\N	\N
18	30	1	[3, 2, 5]		\N	2019-02-05	0	0	\N	\N	\N
19	31	1	[3, 5, 2]	26	2018-05-18	2019-02-28	1	0	\N	\N	\N
20	32	1	[3, 5, 2]	25	2018-05-18	2019-02-28	1	0	\N	\N	\N
21	33	1	[3, 5, 2]	29	2017-05-19	2018-05-10	1	0	\N	\N	\N
22	34	1	[2, 3, 4]	22	2018-05-18	2019-05-06	1	0	\N	\N	\N
23	36	4	[3, 2, 4]	1	2019-02-18	2020-01-09	1	0	\N	\N	\N
24	37	4	[3, 2, 4]	4	2019-02-18	2020-01-09	1	0	\N	\N	\N
25	38	1	[3, 5, 2]	21	2018-05-18	2019-01-09	6	0	\N	\N	\N
26	39	1	[3, 4, 2]	28	2018-05-18	2019-03-12	1	0	\N	\N	\N
27	40	1	[2, 3, 4]	23	2018-05-18	2019-04-30	1	0	\N	\N	\N
28	41	1	[3, 2, 4]	76	2019-06-23	2020-01-09	1	0	\N	\N	\N
29	42	1	[3, 4, 2]	71	2017-10-03	2018-06-24	9	0	\N	\N	\N
30	43	1	[3, 5, 2]	73	2018-06-24	2018-07-04	1	0	\N	\N	\N
31	44	1	[3, 2, 5]	74	2019-06-23	2019-11-27	1	0	\N	\N	\N
32	45	1	[3, 5, 2]	30	2017-08-16	2018-06-30	10	0	\N	\N	\N
33	46	1	[3, 4, 2]	31	2016-10-01	2018-07-17	11	0	\N	\N	\N
34	47	1	[2, 3, 4]	49	2018-10-06	2019-04-30	13	0	\N	\N	\N
35	48	1	[3, 4, 2]	50	2017-10-07	2018-05-17	6	0	\N	\N	\N
36	49	1	[3, 4, 2]	43	2017-10-19	2018-06-30	6	0	\N	\N	\N
37	50	1	[3, 2, 4]	45	2019-07-11	2019-12-06	11	0	\N	\N	\N
38	51	5	[2]		\N	\N	0	0	\N	\N	\N
39	52	6	[2]		\N	\N	0	0	\N	\N	\N
40	54	5	[2]	221	2018-04-05	\N	17	0	\N	\N	\N
41	55	5	[2]	3	2017-06-17	\N	20	0	\N	\N	\N
42	58	5	[2]		2019-11-11	\N	22	5	\N	\N	\N
43	59	4	[3, 2, 5]	14	2019-02-18	2019-11-29	1	0	\N	\N	\N
44	60	4	[3, 4, 2]		\N	\N	3	0	\N	\N	\N
45	62	1	[3, 4, 2]	72	2018-01-11	2018-04-20	6	0	\N	\N	\N
46	63	1	[2, 3, 4]	47	2018-10-18	2019-06-03	1	0	\N	\N	\N
47	64	1	[3, 2, 4]	46	2019-07-11	2019-08-29	10	0	\N	\N	\N
48	65	1	[3, 2, 4]	48	2019-07-11	2019-10-16	1	0	\N	\N	\N
49	66	1	[3, 2, 5]	52	2018-11-28	2019-11-25	10	0	\N	\N	\N
50	67	1	[3, 4, 2]	53	2017-11-29	2018-07-17	6	0	\N	\N	\N
51	68	1	[3, 2, 4]	54	2018-11-28	2020-04-07	1	0	\N	\N	\N
52	69	1	[3, 2, 4]	55	2020-11-26	2021-04-12	1	0	\N	\N	\N
53	70	1	[3, 2, 4]	56	2018-11-28	2019-11-08	6	0	\N	\N	\N
54	71	1	[3, 2, 4]	57	2020-11-26	2021-12-20	1	2	\N	\N	\N
55	72	1	[3, 2, 5]	59	2018-11-28	2019-11-14	6	0	\N	\N	\N
56	73	1	[3, 4, 2]	60	2017-11-29	2018-05-22	6	0	\N	\N	\N
57	74	1	[2, 3, 4]	64	2018-12-07	2019-04-22	6	0	\N	\N	\N
58	75	1	[3, 4, 2]	66	2018-12-07	2018-12-03	6	0	\N	\N	\N
59	76	1	[3, 2, 4]	67	2018-12-07	2020-01-29	6	0	\N	\N	\N
60	77	1	[3, 4, 2]	68	2018-12-07	2019-02-19	6	0	\N	\N	\N
61	78	1	[3, 2, 4]	69	2018-12-07	2020-12-04	6	2	\N	\N	\N
62	79	1	[3, 4, 2]	70	2018-12-07	2019-02-25	12	0	\N	\N	\N
63	80	1	[3, 2, 5]	77	2019-01-10	2019-11-29	6	0	\N	\N	\N
64	81	4	[3, 2, 4]	2	2019-02-18	2019-10-21	1	0	\N	\N	\N
65	82	1	[3, 2, 4]	80	2018-09-17	2020-12-24	5	2	\N	\N	\N
66	83	1	[3, 2, 4]	78	2020-11-26	2022-06-15	1	2	\N	\N	\N
67	84	4	[3, 4, 2]	8	2018-09-19	2019-02-19	1	0	\N	\N	\N
68	85	4	[3, 2, 4]	6	2018-09-14	2020-12-04	6	2	\N	\N	\N
69	86	4	[3, 2, 4]	9	2018-09-19	2019-09-17	1	0	\N	\N	\N
70	87	1	[3, 2, 4]	79	2018-09-14	2019-12-06	3	0	\N	\N	\N
71	88	4	[3, 2, 4]	7	2018-09-19	2019-12-06	1	0	\N	\N	\N
72	89	4	[3, 2, 4]	7	2018-09-21	2021-12-20	1	2	\N	\N	\N
73	90	4	[3, 4, 2]	5	2018-09-06	2018-09-28	1	0	\N	\N	\N
74	91	4	[3, 2, 4]	11	2021-01-26	2022-04-05	6	2	\N	\N	\N
75	92	7	[3, 2, 4]	82	2020-03-05	2020-04-07	5	2	\N	\N	\N
76	93	7	[3, 4, 2]		\N	\N	1	0	\N	\N	\N
77	94	4	[3, 2, 4]	16	2018-11-28	2022-04-05	1	2	\N	\N	\N
78	95	8	[3, 2]		\N	\N	0	0	\N	\N	\N
79	96	7	[3, 2, 4]	43	2020-03-02	2020-04-07	1	2	\N	\N	\N
80	97	4	[3, 2, 4]	12	2018-10-19	2020-04-07	5	2	\N	\N	\N
81	98	4	[3, 2, 4]	20	2020-11-17	2021-04-12	1	2	\N	\N	\N
82	99	4	[3, 2, 4]	19	2020-11-17	2022-04-05	4	2	\N	\N	\N
83	100	4	[3, 2, 4]		\N	\N	1	0	\N	\N	\N
84	101	4	[2, 3, 4]	16	2018-11-08	2019-08-16	1	0	\N	\N	\N
85	102	1	[3, 2, 4, 5]	15	\N	2022-05-11	0	0	\N	\N	\N
86	103	1	[3, 2, 4, 5]	16	\N	2022-05-11	0	0	\N	\N	\N
87	104	4	[2, 3, 4]	15	2018-11-28	2019-06-07	1	0	\N	\N	\N
89	106	4	[2, 3, 4]	17	2018-12-04	2019-01-09	1	0	\N	\N	\N
90	107	4	[2, 3, 4]	18	2018-12-10	2019-01-09	2	0	\N	\N	\N
91	108	7	[3, 2, 4]	5	2019-01-23	2019-08-26	1	0	\N	\N	\N
92	109	7	[3, 4, 2]		\N	\N	0	0	\N	\N	\N
93	110	7	[2, 3, 4]	3	2019-01-23	2019-07-02	1	0	\N	\N	\N
94	111	7	[2, 3, 4]	6	2019-01-23	2019-06-07	1	0	\N	\N	\N
95	112	4	[3, 4, 2]	22	2019-02-19	2019-03-13	1	0	\N	\N	\N
96	113	4	[2, 3, 4]	21	2019-02-19	2019-11-04	1	0	\N	\N	\N
97	114	4	[3, 4, 2]		\N	\N	4	0	\N	\N	\N
98	115	7	[3, 4, 2]	4	2019-01-23	2019-02-28	1	0	\N	\N	\N
99	116	4	[3, 2, 4]		\N	\N	1	0	\N	\N	\N
100	117	4	[3, 2, 4]		\N	\N	1	0	\N	\N	\N
101	118	7	[3, 2, 4]	21	2019-02-14	2019-09-13	1	0	\N	\N	\N
102	119	7	[2, 3, 4]	23	2019-02-19	2019-07-14	1	0	\N	\N	\N
103	120	7	[3, 4, 2]	13	2019-02-14	2019-03-12	1	0	\N	\N	\N
104	121	7	[3, 2, 4]	16	2019-02-14	2019-08-26	1	0	\N	\N	\N
105	122	7	[3, 2, 4]	22	2019-02-19	2019-08-26	1	0	\N	\N	\N
106	123	7	[3, 2, 4]	15	2019-02-14	2020-07-08	1	2	\N	\N	\N
107	124	7	[2, 3, 4]	14	2019-02-14	2019-04-04	1	0	\N	\N	\N
108	125	7	[3, 2, 4]	2	2019-01-14	2020-01-20	1	0	\N	\N	\N
109	126	7	[3, 2, 4]	17	2019-02-14	2019-07-02	1	0	\N	\N	\N
110	127	7	[3, 2, 4]	18	2019-02-14	2020-07-08	1	2	\N	\N	\N
111	128	7	[2, 3, 4]	20	2019-02-14	2019-07-08	1	0	\N	\N	\N
112	129	7	[2, 3, 4]	19	2019-02-14	2019-07-02	1	0	\N	\N	\N
113	130	7	[3, 2, 4]	12	2019-02-13	2020-04-07	1	2	\N	\N	\N
114	131	7	[3, 2, 4]	11	2019-02-08	2020-01-09	1	0	\N	\N	\N
115	132	7	[2, 3, 4]	7	2019-02-07	2019-04-30	1	0	\N	\N	\N
116	133	7	[2, 3, 4]	8	2019-02-07	2019-07-22	1	0	\N	\N	\N
117	134	7	[2, 3, 4]	10	2019-02-07	2019-08-05	1	0	\N	\N	\N
118	135	7	[2, 3, 4]	9	2019-02-07	2019-04-30	1	0	\N	\N	\N
119	136	7	[3, 2, 4]	24	2019-03-11	2020-01-09	1	0	\N	\N	\N
120	137	7	[3, 2, 4]	27	2019-03-11	2020-01-09	1	0	\N	\N	\N
121	138	7	[2, 3, 4]	26	2019-03-11	2019-06-05	1	0	\N	\N	\N
122	139	7	[2, 3, 4]	25	2019-03-11	2019-06-05	1	0	\N	\N	\N
123	140	7	[2, 3, 4]	23	2019-03-04	2019-07-22	1	0	\N	\N	\N
124	141	1	[3, 2, 4]		\N	2021-12-20	0	2	\N	\N	\N
125	142	7	[3, 2, 4]	29	2019-04-23	2019-09-02	1	0	\N	\N	\N
126	143	7	[3, 4, 2]		\N	2019-03-25	1	0	\N	\N	\N
127	144	7	[2, 3, 4]	30	2019-05-06	2019-05-13	1	0	\N	\N	\N
128	145	7	[3, 2, 4]	28	2019-03-11	2019-09-30	14	0	\N	\N	\N
129	146	7	[2, 3, 4]	32	2019-05-27	2019-07-24	1	0	\N	\N	\N
131	148	7	[3, 2, 4]	34	2019-05-27	2019-09-26	1	0	\N	\N	\N
132	149	7	[3, 2, 4]	35	2019-05-27	2019-09-26	1	0	\N	\N	\N
133	150	4	[3, 2, 4]		\N	\N	6	2	\N	\N	\N
134	151	7	[3, 2, 4]		\N	2019-09-26	0	0	\N	\N	\N
135	153	1	[3, 2, 5]	39	2016-07-07	2019-12-09	27	0	\N	\N	\N
136	154	1	[3, 2, 5]	41	2016-07-07	2019-12-09	27	0	\N	\N	\N
137	155	7	[2, 3, 4]		\N	\N	1	0	\N	\N	\N
138	156	7	[2, 3]		\N	\N	0	0	\N	\N	\N
139	157	7	[2, 3, 4]		\N	\N	0	0	\N	\N	\N
140	158	7	[2, 3, 4]		\N	\N	0	0	\N	\N	\N
141	159	1	[3, 2, 4]	42	2016-07-01	2021-09-06	27	0	\N	\N	\N
142	160	7	[3, 4, 2]		\N	2019-05-13	0	0	\N	\N	\N
143	161	7	[3, 4, 2]		\N	2019-05-13	0	0	\N	\N	\N
144	162	7	[3, 2, 4]	36	2019-06-18	2019-12-02	1	0	\N	\N	\N
145	163	7	[3, 2, 4]	37	2019-06-18	2019-09-05	1	0	\N	\N	\N
146	164	7	[2, 3, 4]	38	2019-06-21	2019-07-24	1	0	\N	\N	\N
147	165	7	[3, 2, 4]	38	2019-10-08	2019-10-31	1	0	\N	\N	\N
148	166	1	[3, 4, 2]		\N	\N	6	0	\N	\N	\N
149	167	7	[3, 2, 4]	39	2019-07-15	2019-10-01	1	0	\N	\N	\N
150	168	1	[3, 2, 4]		\N	\N	1	0	\N	\N	\N
151	169	1	[3, 2, 4]		\N	\N	1	0	\N	\N	\N
152	170	1	[3, 2, 4]	81	2019-09-05	2020-04-07	1	2	\N	\N	\N
153	171	7	[3, 2, 4]	40	2019-07-24	2020-01-20	1	0	\N	\N	\N
154	172	7	[3, 2, 4]	43	2019-08-23	2019-09-05	1	0	\N	\N	\N
155	173	7	[3, 2, 4]	42	2019-08-23	2019-09-05	1	0	\N	\N	\N
156	174	7	[3, 2, 4]	41	2019-08-23	2019-09-05	1	0	\N	\N	\N
157	175	7	[3, 2, 4]		\N	\N	0	0	\N	\N	\N
158	176	7	[3, 2, 4]		\N	2018-09-30	0	0	\N	\N	\N
159	177	1	[3, 2, 4]	83	2019-10-07	2020-12-24	1	2	\N	\N	\N
160	178	1	[3, 2, 4]	84	2019-11-01	2020-03-03	1	2	\N	\N	\N
161	179	1	[2, 3, 4]		\N	\N	1	0	\N	\N	\N
162	180	1	[3, 2, 4]	82	2019-10-07	2019-12-10	1	0	\N	\N	\N
163	181	1	[2, 3, 4]		\N	\N	1	0	\N	\N	\N
164	182	1	[3, 2, 4]	87	2019-12-10	2022-08-31	6	2	\N	\N	\N
165	183	1	[3, 2, 4]	86	2019-11-25	2020-03-03	1	2	\N	\N	\N
166	184	1	[3, 2, 4]	85	2019-11-25	2022-10-17	1	2	\N	\N	\N
167	185	4	[3, 2, 4]	23	2020-01-21	2021-04-12	6	2	\N	\N	\N
168	186	4	[3, 2, 4]		\N	\N	0	0	\N	\N	\N
169	187	4	[3, 2, 4]		\N	\N	0	0	\N	\N	\N
170	188	7	[3, 2, 4]	40	2019-12-11	2020-01-27	1	0	\N	\N	\N
171	189	7	[3, 2, 4]		\N	\N	1	0	\N	\N	\N
172	190	1	[3, 2, 4]	89	2020-11-21	2022-06-15	1	2	\N	\N	\N
173	191	7	[3, 2, 4]	41	2019-12-18	2020-01-09	1	0	\N	\N	\N
174	194	1	[3, 2, 4]	2	2022-03-15	2022-10-17	6	2	\N	\N	\N
175	195	7	[3, 2, 4]	45	2020-03-11	2020-04-07	1	2	\N	\N	\N
176	199	1	[3, 2, 4]		\N	\N	1	2	\N	\N	\N
177	200	1	[3, 2, 4]	1	2022-02-16	\N	1	2	\N	\N	\N
178	201	4	[3, 2, 4]	3	2022-04-11	2022-10-03	1	2	\N	\N	\N
180	203	4	[3, 2, 4]	2	2022-03-29	\N	6	2	\N	\N	\N
181	204	4	[3, 2, 4]		\N	\N	1	2	\N	\N	\N
182	205	1	[3, 2, 4]	4	2022-03-29	\N	1	2	\N	\N	\N
183	206	1	[3, 2, 4]	3	2022-03-15	\N	1	2	\N	\N	\N
184	208	1	[3, 2, 4]	5	2022-03-29	\N	1	2	\N	\N	\N
185	209	1	[3, 2, 4]	6	2022-03-29	\N	1	2	\N	\N	\N
186	212	1	[3, 2, 4]	7	2022-03-29	\N	1	2	\N	\N	\N
187	213	1	[3, 2, 4]		\N	\N	6	2	\N	\N	\N
188	214	1	[3, 2, 4]		\N	\N	6	2	\N	\N	\N
189	218	1	[3, 2, 4]	8	2022-04-11	\N	6	2	\N	\N	\N
190	221	12	[0]		\N	\N	0	0	\N	\N	\N
191	222	13	[0]		\N	\N	0	0	\N	\N	\N
192	223	1	[3, 2, 4]	9	2022-05-20	2022-09-02	6	2	\N	\N	\N
193	224	1	[3, 2, 4]	12	2022-06-20	\N	6	2	\N	\N	\N
194	225	1	[3, 2, 4]	11	2022-06-20	\N	6	2	\N	\N	\N
195	226	1	[3, 2, 4]	10	2022-05-20	2022-09-02	6	2	\N	\N	\N
196	227	4	[3, 2, 4]	5	2022-07-14	2022-12-14	6	2	\N	\N	\N
197	228	4	[3, 2, 4]		\N	\N	6	2	\N	\N	\N
198	230	4	[3, 2, 4]	4	2022-07-14	\N	6	2	\N	\N	\N
199	231	4	[3, 2, 4]		\N	\N	6	2	\N	\N	\N
200	233	14	[0]		\N	\N	0	0	\N	\N	\N
201	234	1	[3, 2, 4]		\N	\N	6	2	\N	\N	\N
202	235	4	[3, 2, 4]	7	2022-10-07	\N	1	2	\N	\N	\N
203	236	4	[3, 2, 4]	9	2022-10-07	\N	1	2	\N	\N	\N
204	237	4	[3, 2, 4]	8	2022-10-07	\N	1	2	\N	\N	\N
205	238	1	[3, 2, 4]	16	2022-11-10	\N	6	2	\N	\N	\N
206	239	1	[3, 2, 4]	15	2022-11-10	\N	6	2	\N	\N	\N
207	240	1	[3, 2, 4]	14	2022-11-10	\N	6	2	\N	\N	\N
209	244	1	[3, 2, 4]		\N	\N	6	2	\N	\N	\N
210	245	1	[3, 2, 4]		\N	\N	6	2	\N	\N	\N
213	248	1	[3, 2, 4]		\N	\N	6	2	\N	\N	\N
2	4	4	[3, 2]		2009-06-30	\N	32	0	[{"date": "2023-01-03 22:13:2", "user": 1, "prev_value": {"hired_date": null, "employer_id": 1, "occupation_id": 0}}]	\N	2023-01-03 22:13:02
215	4	1	[3, 2]	\N	2016-01-11	\N	32	\N	\N	2023-01-03 22:13:02	2023-01-03 22:13:02
1	3	1	[2, 3, 4, 5]	14	2022-07-13	\N	30	0	[{"date": "2023-01-03 22:13:20", "user": 1, "prev_value": {"hired_date": "2022-07-13", "occupation_id": 0}}]	\N	2023-01-03 22:13:20
130	147	4	[3, 2, 4]	25	2021-09-07	2023-01-18	1	2	[{"date": "2023-01-18 10:51:4", "user": 3, "prev_value": {"hired_date": "2021-09-07"}}, {"date": "2023-01-18 10:53:4", "user": 3, "prev_value": {"hired_date": "2021-09-07"}}, {"date": "2023-02-01 8:3:11", "user": 1, "prev_value": {"fired_date": null, "hired_date": "2021-09-07"}}]	\N	2023-02-01 08:03:11
211	246	1	[3, 2, 4]	17	2023-01-23	\N	6	2	[{"date": "2023-01-18 11:49:44", "user": 3, "prev_value": {"hired_date": null, "contract_number": ""}}, {"date": "2023-01-18 11:49:52", "user": 3, "prev_value": {"hired_date": "2023-01-23"}}, {"date": "2023-01-23 11:23:17", "user": 3, "prev_value": {"hired_date": "2023-01-23"}}, {"date": "2023-01-23 11:23:27", "user": 3, "prev_value": {"hired_date": "2023-01-23"}}]	\N	2023-01-23 11:23:27
88	105	1	[3, 2]	5а	2018-09-03	\N	27	11	[{"date": "2023-01-03 22:14:18", "user": 1, "prev_value": {"hired_date": "2018-09-03"}}, {"date": "2023-01-03 22:31:44", "user": 1, "prev_value": {"hired_date": "2018-09-03"}}, {"date": "2023-01-04 16:0:0", "user": 3, "prev_value": {"hired_date": "2018-09-03"}}]	\N	2023-01-04 16:00:00
208	241	1	[3, 2]	13	2022-07-25	\N	29	20	[{"date": "2023-01-03 22:13:56", "user": 1, "prev_value": {"hired_date": "2022-07-25"}}, {"date": "2023-01-04 16:3:32", "user": 1, "prev_value": {"hired_date": "2022-07-25"}}]	\N	2023-01-04 16:03:32
216	241	4	[3, 2]	12	2022-07-25	\N	29	20	[{"date": "2023-01-04 16:3:32", "user": 1, "prev_value": {"hired_date": "2022-07-25"}}]	2023-01-03 22:13:56	2023-01-04 16:03:32
179	202	4	[3, 2, 4]	1	2022-03-29	\N	6	2	[{"date": "2023-02-06 11:57:14", "user": 3, "prev_value": {"hired_date": "2022-03-29"}}]	\N	2023-02-06 11:57:14
212	247	1	[3, 2, 4]	18	2023-01-23	\N	6	2	[{"date": "2023-01-18 11:51:19", "user": 3, "prev_value": {"hired_date": null, "contract_number": ""}}, {"date": "2023-01-18 11:51:26", "user": 3, "prev_value": {"hired_date": "2023-01-23"}}, {"date": "2023-01-23 11:37:39", "user": 3, "prev_value": {"hired_date": "2023-01-23"}}, {"date": "2023-01-23 11:37:44", "user": 3, "prev_value": {"hired_date": "2023-01-23"}}]	\N	2023-01-23 11:37:44
\.


--
-- Data for Name: employee_turnover; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.employee_turnover (id, employee_id, employer_id, date, status_id, user_ids, created_at, updated_at) FROM stdin;
1	3	1	2022-07-13	11	[2, 3, 4, 5]	\N	\N
2	15	1	2018-06-24	12	[3, 2, 4]	\N	\N
3	15	1	2018-11-28	11	[3, 2, 4]	\N	\N
4	15	1	2019-11-26	6	[3, 2, 4]	\N	\N
5	16	4	2022-07-13	11	[2, 3, 4, 5]	\N	\N
6	17	1	2016-06-04	12	[2, 3, 4]	\N	\N
7	17	1	2016-06-06	11	[2, 3, 4]	\N	\N
8	17	1	2019-03-24	6	[2, 3, 4]	\N	\N
9	19	1	2016-05-25	12	[3, 5, 2]	\N	\N
10	19	1	2018-03-27	11	[3, 5, 2]	\N	\N
11	19	1	2019-02-05	6	[3, 5, 2]	\N	\N
12	20	1	2016-05-25	12	[3, 5, 2]	\N	\N
13	20	1	2018-03-27	11	[3, 5, 2]	\N	\N
14	20	1	2018-12-03	6	[3, 5, 2]	\N	\N
15	21	1	2016-05-25	12	[3, 5, 2]	\N	\N
16	21	1	2016-05-26	11	[3, 5, 2]	\N	\N
17	21	1	2018-03-15	6	[3, 5, 2]	\N	\N
18	22	1	2017-09-19	12	[3, 2, 4]	\N	\N
19	22	1	2016-06-06	11	[3, 2, 4]	\N	\N
20	22	1	2021-12-20	6	[3, 2, 4]	\N	\N
21	23	1	2016-06-04	12	[3, 4, 2]	\N	\N
22	23	1	2018-03-27	11	[3, 4, 2]	\N	\N
23	23	1	2019-01-29	6	[3, 4, 2]	\N	\N
24	24	1	2018-04-17	12	[3, 2, 4]	\N	\N
25	24	1	2016-06-06	11	[3, 2, 4]	\N	\N
26	24	1	2020-03-24	6	[3, 2, 4]	\N	\N
27	25	1	2016-06-04	12	[3, 2, 4]	\N	\N
28	25	1	2016-06-06	11	[3, 2, 4]	\N	\N
29	25	1	2021-04-12	6	[3, 2, 4]	\N	\N
30	26	1	2019-09-16	12	[3, 2, 4]	\N	\N
31	26	1	2016-06-06	11	[3, 2, 4]	\N	\N
32	26	1	2021-04-12	6	[3, 2, 4]	\N	\N
33	27	1	2016-06-04	12	[3, 2, 4]	\N	\N
34	27	1	2016-06-06	11	[3, 2, 4]	\N	\N
35	27	1	2020-03-24	6	[3, 2, 4]	\N	\N
36	28	1	2020-02-06	12	[3, 2, 4]	\N	\N
37	28	1	2020-11-21	11	[3, 2, 4]	\N	\N
38	28	1	2022-04-05	6	[3, 2, 4]	\N	\N
39	29	1	2016-06-08	12	[3, 4, 2]	\N	\N
40	29	1	2018-03-27	11	[3, 4, 2]	\N	\N
41	29	1	2019-02-28	6	[3, 4, 2]	\N	\N
42	30	1	2016-07-20	12	[3, 2, 5]	\N	\N
43	30	1	2019-02-05	6	[3, 2, 5]	\N	\N
44	31	1	2017-10-22	12	[3, 5, 2]	\N	\N
45	31	1	2018-05-18	11	[3, 5, 2]	\N	\N
46	31	1	2019-02-28	6	[3, 5, 2]	\N	\N
47	32	1	2018-04-02	12	[3, 5, 2]	\N	\N
48	32	1	2018-05-18	11	[3, 5, 2]	\N	\N
49	32	1	2019-02-28	6	[3, 5, 2]	\N	\N
50	33	1	2016-07-20	12	[3, 5, 2]	\N	\N
51	33	1	2017-05-19	11	[3, 5, 2]	\N	\N
52	33	1	2018-05-10	6	[3, 5, 2]	\N	\N
53	34	1	2016-08-03	12	[2, 3, 4]	\N	\N
54	34	1	2018-05-18	11	[2, 3, 4]	\N	\N
55	34	1	2019-05-06	6	[2, 3, 4]	\N	\N
56	36	4	2018-05-11	12	[3, 2, 4]	\N	\N
57	36	4	2019-02-18	11	[3, 2, 4]	\N	\N
58	36	4	2020-01-09	6	[3, 2, 4]	\N	\N
59	37	4	2018-08-10	12	[3, 2, 4]	\N	\N
60	37	4	2019-02-18	11	[3, 2, 4]	\N	\N
61	37	4	2020-01-09	6	[3, 2, 4]	\N	\N
62	38	1	2016-07-20	12	[3, 5, 2]	\N	\N
63	38	1	2018-05-18	11	[3, 5, 2]	\N	\N
64	38	1	2019-01-09	6	[3, 5, 2]	\N	\N
65	39	1	2016-08-03	12	[3, 4, 2]	\N	\N
66	39	1	2018-05-18	11	[3, 4, 2]	\N	\N
67	39	1	2019-03-12	6	[3, 4, 2]	\N	\N
68	39	1	2019-01-29	8	[3, 4, 2]	\N	\N
69	40	1	2016-08-03	12	[2, 3, 4]	\N	\N
70	40	1	2018-05-18	11	[2, 3, 4]	\N	\N
71	40	1	2019-04-30	6	[2, 3, 4]	\N	\N
72	40	1	2019-04-26	8	[2, 3, 4]	\N	\N
73	41	1	2017-11-07	12	[3, 2, 4]	\N	\N
74	41	1	2019-06-23	11	[3, 2, 4]	\N	\N
75	41	1	2020-01-09	6	[3, 2, 4]	\N	\N
76	42	1	2017-09-29	12	[3, 4, 2]	\N	\N
77	42	1	2017-10-03	11	[3, 4, 2]	\N	\N
78	42	1	2018-06-24	6	[3, 4, 2]	\N	\N
79	43	1	2017-10-17	12	[3, 5, 2]	\N	\N
80	43	1	2018-06-24	11	[3, 5, 2]	\N	\N
81	43	1	2018-07-04	6	[3, 5, 2]	\N	\N
82	44	1	2018-04-02	12	[3, 2, 5]	\N	\N
83	44	1	2019-06-23	11	[3, 2, 5]	\N	\N
84	44	1	2019-11-27	6	[3, 2, 5]	\N	\N
85	45	1	2016-10-01	12	[3, 5, 2]	\N	\N
86	45	1	2017-08-16	11	[3, 5, 2]	\N	\N
87	45	1	2018-06-30	6	[3, 5, 2]	\N	\N
88	46	1	2016-10-01	12	[3, 4, 2]	\N	\N
89	46	1	2016-10-01	11	[3, 4, 2]	\N	\N
90	46	1	2018-07-17	6	[3, 4, 2]	\N	\N
91	47	1	2016-11-10	12	[2, 3, 4]	\N	\N
92	47	1	2018-10-06	11	[2, 3, 4]	\N	\N
93	47	1	2019-04-30	6	[2, 3, 4]	\N	\N
94	48	1	2016-11-10	12	[3, 4, 2]	\N	\N
95	48	1	2017-10-07	11	[3, 4, 2]	\N	\N
96	48	1	2018-05-17	6	[3, 4, 2]	\N	\N
97	49	1	2017-09-19	12	[3, 4, 2]	\N	\N
98	49	1	2017-10-19	11	[3, 4, 2]	\N	\N
99	49	1	2018-06-30	6	[3, 4, 2]	\N	\N
100	50	1	2018-07-10	12	[3, 2, 4]	\N	\N
101	50	1	2019-07-11	11	[3, 2, 4]	\N	\N
102	50	1	2019-12-06	6	[3, 2, 4]	\N	\N
103	54	5	2018-03-26	12	[2]	\N	\N
104	54	5	2018-04-05	11	[2]	\N	\N
105	55	5	2017-06-15	12	[2]	\N	\N
106	55	5	2017-06-17	11	[2]	\N	\N
107	58	5	2019-11-11	11	[2]	\N	\N
108	59	4	2018-10-21	12	[3, 2, 5]	\N	\N
109	59	4	2019-02-18	11	[3, 2, 5]	\N	\N
110	59	4	2019-11-29	6	[3, 2, 5]	\N	\N
111	62	1	2017-10-02	12	[3, 4, 2]	\N	\N
112	62	1	2018-01-11	11	[3, 4, 2]	\N	\N
113	62	1	2018-04-20	6	[3, 4, 2]	\N	\N
114	63	1	2016-11-10	12	[2, 3, 4]	\N	\N
115	63	1	2018-10-18	11	[2, 3, 4]	\N	\N
116	63	1	2019-06-03	6	[2, 3, 4]	\N	\N
117	64	1	2016-11-10	12	[3, 2, 4]	\N	\N
118	64	1	2019-07-11	11	[3, 2, 4]	\N	\N
119	64	1	2019-08-29	6	[3, 2, 4]	\N	\N
120	65	1	2016-11-10	12	[3, 2, 4]	\N	\N
121	65	1	2019-07-11	11	[3, 2, 4]	\N	\N
122	65	1	2019-10-16	6	[3, 2, 4]	\N	\N
123	66	1	2016-12-31	12	[3, 2, 5]	\N	\N
124	66	1	2018-11-28	11	[3, 2, 5]	\N	\N
125	66	1	2019-11-25	6	[3, 2, 5]	\N	\N
126	67	1	2016-12-31	12	[3, 4, 2]	\N	\N
127	67	1	2017-11-29	11	[3, 4, 2]	\N	\N
128	67	1	2018-07-17	6	[3, 4, 2]	\N	\N
129	68	1	2019-10-12	12	[3, 2, 4]	\N	\N
130	68	1	2018-11-28	11	[3, 2, 4]	\N	\N
131	68	1	2020-04-07	6	[3, 2, 4]	\N	\N
132	68	1	2020-03-10	8	[3, 2, 4]	\N	\N
133	69	1	2016-12-31	12	[3, 2, 4]	\N	\N
134	69	1	2020-11-26	11	[3, 2, 4]	\N	\N
135	69	1	2021-04-12	6	[3, 2, 4]	\N	\N
136	70	1	2019-05-06	12	[3, 2, 4]	\N	\N
137	70	1	2018-11-28	11	[3, 2, 4]	\N	\N
138	70	1	2019-11-08	6	[3, 2, 4]	\N	\N
139	71	1	2016-12-31	12	[3, 2, 4]	\N	\N
140	71	1	2020-11-26	11	[3, 2, 4]	\N	\N
141	71	1	2021-12-20	6	[3, 2, 4]	\N	\N
142	72	1	2017-01-31	12	[3, 2, 5]	\N	\N
143	72	1	2018-11-28	11	[3, 2, 5]	\N	\N
144	72	1	2019-11-14	6	[3, 2, 5]	\N	\N
145	73	1	2017-01-31	12	[3, 4, 2]	\N	\N
146	73	1	2017-11-29	11	[3, 4, 2]	\N	\N
147	73	1	2018-05-22	6	[3, 4, 2]	\N	\N
148	74	1	2017-03-25	12	[2, 3, 4]	\N	\N
149	74	1	2018-12-07	11	[2, 3, 4]	\N	\N
150	74	1	2019-04-22	6	[2, 3, 4]	\N	\N
151	75	1	2017-02-24	12	[3, 4, 2]	\N	\N
152	75	1	2018-12-07	11	[3, 4, 2]	\N	\N
153	75	1	2018-12-03	6	[3, 4, 2]	\N	\N
154	75	1	2018-10-14	8	[3, 4, 2]	\N	\N
155	76	1	2017-02-24	12	[3, 2, 4]	\N	\N
156	76	1	2018-12-07	11	[3, 2, 4]	\N	\N
157	76	1	2020-01-29	6	[3, 2, 4]	\N	\N
158	76	1	2020-01-21	8	[3, 2, 4]	\N	\N
159	77	1	2017-02-24	12	[3, 4, 2]	\N	\N
160	77	1	2018-12-07	11	[3, 4, 2]	\N	\N
161	77	1	2019-02-19	6	[3, 4, 2]	\N	\N
162	77	1	2019-02-19	8	[3, 4, 2]	\N	\N
163	78	1	2020-01-29	12	[3, 2, 4]	\N	\N
164	78	1	2018-12-07	11	[3, 2, 4]	\N	\N
165	78	1	2020-12-04	6	[3, 2, 4]	\N	\N
166	78	1	2020-12-04	8	[3, 2, 4]	\N	\N
167	79	1	2017-02-24	12	[3, 4, 2]	\N	\N
168	79	1	2018-12-07	11	[3, 4, 2]	\N	\N
169	79	1	2019-02-25	6	[3, 4, 2]	\N	\N
170	79	1	2019-01-25	8	[3, 4, 2]	\N	\N
171	80	1	2017-11-07	12	[3, 2, 5]	\N	\N
172	80	1	2019-01-10	11	[3, 2, 5]	\N	\N
173	80	1	2019-11-29	6	[3, 2, 5]	\N	\N
174	81	4	2018-07-17	12	[3, 2, 4]	\N	\N
175	81	4	2019-02-18	11	[3, 2, 4]	\N	\N
176	81	4	2019-10-21	6	[3, 2, 4]	\N	\N
177	82	1	2018-09-13	12	[3, 2, 4]	\N	\N
178	82	1	2018-09-17	11	[3, 2, 4]	\N	\N
179	82	1	2020-12-24	6	[3, 2, 4]	\N	\N
180	83	1	2019-10-12	12	[3, 2, 4]	\N	\N
181	83	1	2020-11-26	11	[3, 2, 4]	\N	\N
182	83	1	2022-06-15	6	[3, 2, 4]	\N	\N
183	84	4	2018-09-17	12	[3, 4, 2]	\N	\N
184	84	4	2018-09-19	11	[3, 4, 2]	\N	\N
185	84	4	2019-02-19	6	[3, 4, 2]	\N	\N
186	84	4	2019-02-19	8	[3, 4, 2]	\N	\N
187	85	4	2018-09-12	12	[3, 2, 4]	\N	\N
188	85	4	2018-09-14	11	[3, 2, 4]	\N	\N
189	85	4	2020-12-04	6	[3, 2, 4]	\N	\N
190	85	4	2020-12-04	8	[3, 2, 4]	\N	\N
191	86	4	2018-09-17	12	[3, 2, 4]	\N	\N
192	86	4	2018-09-19	11	[3, 2, 4]	\N	\N
193	86	4	2019-09-17	6	[3, 2, 4]	\N	\N
194	87	1	2018-09-12	12	[3, 2, 4]	\N	\N
195	87	1	2018-09-14	11	[3, 2, 4]	\N	\N
196	87	1	2019-12-06	6	[3, 2, 4]	\N	\N
197	88	4	2018-09-17	12	[3, 2, 4]	\N	\N
198	88	4	2018-09-19	11	[3, 2, 4]	\N	\N
199	88	4	2019-12-06	6	[3, 2, 4]	\N	\N
200	89	4	2018-09-13	12	[3, 2, 4]	\N	\N
201	89	4	2018-09-21	11	[3, 2, 4]	\N	\N
202	89	4	2021-12-20	6	[3, 2, 4]	\N	\N
203	90	4	2018-08-26	12	[3, 4, 2]	\N	\N
204	90	4	2018-09-06	11	[3, 4, 2]	\N	\N
205	90	4	2018-09-28	6	[3, 4, 2]	\N	\N
206	90	4	2018-09-28	8	[3, 4, 2]	\N	\N
207	91	4	2018-09-13	12	[3, 2, 4]	\N	\N
208	91	4	2021-01-26	11	[3, 2, 4]	\N	\N
209	91	4	2022-04-05	6	[3, 2, 4]	\N	\N
210	92	7	2019-12-14	12	[3, 2, 4]	\N	\N
211	92	7	2020-03-05	11	[3, 2, 4]	\N	\N
212	92	7	2020-04-07	6	[3, 2, 4]	\N	\N
213	93	7	2018-09-03	12	[3, 4, 2]	\N	\N
214	94	4	2018-10-31	12	[3, 2, 4]	\N	\N
215	94	4	2018-11-28	11	[3, 2, 4]	\N	\N
216	94	4	2022-04-05	6	[3, 2, 4]	\N	\N
217	96	7	2020-02-23	12	[3, 2, 4]	\N	\N
218	96	7	2020-03-02	11	[3, 2, 4]	\N	\N
219	96	7	2020-04-07	6	[3, 2, 4]	\N	\N
220	97	4	2019-01-11	12	[3, 2, 4]	\N	\N
221	97	4	2018-10-19	11	[3, 2, 4]	\N	\N
222	97	4	2020-04-07	6	[3, 2, 4]	\N	\N
223	98	4	2018-12-28	12	[3, 2, 4]	\N	\N
224	98	4	2020-11-17	11	[3, 2, 4]	\N	\N
225	98	4	2021-04-12	6	[3, 2, 4]	\N	\N
226	99	4	2018-12-28	12	[3, 2, 4]	\N	\N
227	99	4	2020-11-17	11	[3, 2, 4]	\N	\N
228	99	4	2022-04-05	6	[3, 2, 4]	\N	\N
229	101	4	2018-11-08	11	[2, 3, 4]	\N	\N
230	101	4	2019-08-16	6	[2, 3, 4]	\N	\N
231	102	1	2022-05-11	6	[3, 2, 4, 5]	\N	\N
232	103	1	2022-05-11	6	[3, 2, 4, 5]	\N	\N
233	104	4	2018-10-17	12	[2, 3, 4]	\N	\N
234	104	4	2018-11-28	11	[2, 3, 4]	\N	\N
235	104	4	2019-06-07	6	[2, 3, 4]	\N	\N
236	105	1	2018-09-03	11	[3, 2]	\N	\N
237	106	4	2018-11-24	12	[2, 3, 4]	\N	\N
238	106	4	2018-12-04	11	[2, 3, 4]	\N	\N
239	106	4	2019-01-09	6	[2, 3, 4]	\N	\N
240	107	4	2018-11-27	12	[2, 3, 4]	\N	\N
241	107	4	2018-12-10	11	[2, 3, 4]	\N	\N
242	107	4	2019-01-09	6	[2, 3, 4]	\N	\N
243	108	7	2019-05-16	12	[3, 2, 4]	\N	\N
244	108	7	2019-01-23	11	[3, 2, 4]	\N	\N
245	108	7	2019-08-26	6	[3, 2, 4]	\N	\N
246	109	7	2018-12-08	12	[3, 4, 2]	\N	\N
247	109	7	2018-12-28	8	[3, 4, 2]	\N	\N
248	110	7	2018-12-08	12	[2, 3, 4]	\N	\N
249	110	7	2019-01-23	11	[2, 3, 4]	\N	\N
250	110	7	2019-07-02	6	[2, 3, 4]	\N	\N
251	111	7	2018-12-08	12	[2, 3, 4]	\N	\N
252	111	7	2019-01-23	11	[2, 3, 4]	\N	\N
253	111	7	2019-06-07	6	[2, 3, 4]	\N	\N
254	112	4	2019-01-28	12	[3, 4, 2]	\N	\N
255	112	4	2019-02-19	11	[3, 4, 2]	\N	\N
256	112	4	2019-03-13	6	[3, 4, 2]	\N	\N
257	112	4	2019-03-13	8	[3, 4, 2]	\N	\N
258	113	4	2019-01-28	12	[2, 3, 4]	\N	\N
259	113	4	2019-02-19	11	[2, 3, 4]	\N	\N
260	113	4	2019-11-04	6	[2, 3, 4]	\N	\N
261	114	4	2019-01-28	12	[3, 4, 2]	\N	\N
262	114	4	2019-02-19	8	[3, 4, 2]	\N	\N
263	115	7	2018-12-08	12	[3, 4, 2]	\N	\N
264	115	7	2019-01-23	11	[3, 4, 2]	\N	\N
265	115	7	2019-02-28	6	[3, 4, 2]	\N	\N
266	118	7	2019-01-05	12	[3, 2, 4]	\N	\N
267	118	7	2019-02-14	11	[3, 2, 4]	\N	\N
268	118	7	2019-09-13	6	[3, 2, 4]	\N	\N
269	118	7	2019-08-09	8	[3, 2, 4]	\N	\N
270	119	7	2019-01-05	12	[2, 3, 4]	\N	\N
271	119	7	2019-02-19	11	[2, 3, 4]	\N	\N
272	119	7	2019-07-14	6	[2, 3, 4]	\N	\N
273	120	7	2019-01-05	12	[3, 4, 2]	\N	\N
274	120	7	2019-02-14	11	[3, 4, 2]	\N	\N
275	120	7	2019-03-12	6	[3, 4, 2]	\N	\N
276	121	7	2019-01-05	12	[3, 2, 4]	\N	\N
277	121	7	2019-02-14	11	[3, 2, 4]	\N	\N
278	121	7	2019-08-26	6	[3, 2, 4]	\N	\N
279	122	7	2019-01-05	12	[3, 2, 4]	\N	\N
280	122	7	2019-02-19	11	[3, 2, 4]	\N	\N
281	122	7	2019-08-26	6	[3, 2, 4]	\N	\N
282	123	7	2019-01-05	12	[3, 2, 4]	\N	\N
283	123	7	2019-02-14	11	[3, 2, 4]	\N	\N
284	123	7	2020-07-08	6	[3, 2, 4]	\N	\N
285	124	7	2019-01-05	12	[2, 3, 4]	\N	\N
286	124	7	2019-02-14	11	[2, 3, 4]	\N	\N
287	124	7	2019-04-04	6	[2, 3, 4]	\N	\N
288	125	7	2019-06-11	12	[3, 2, 4]	\N	\N
289	125	7	2019-01-14	11	[3, 2, 4]	\N	\N
290	125	7	2020-01-20	6	[3, 2, 4]	\N	\N
291	126	7	2019-01-05	12	[3, 2, 4]	\N	\N
292	126	7	2019-02-14	11	[3, 2, 4]	\N	\N
293	126	7	2019-07-02	6	[3, 2, 4]	\N	\N
294	127	7	2019-01-05	12	[3, 2, 4]	\N	\N
295	127	7	2019-02-14	11	[3, 2, 4]	\N	\N
296	127	7	2020-07-08	6	[3, 2, 4]	\N	\N
297	128	7	2019-01-05	12	[2, 3, 4]	\N	\N
298	128	7	2019-02-14	11	[2, 3, 4]	\N	\N
299	128	7	2019-07-08	6	[2, 3, 4]	\N	\N
300	129	7	2019-01-05	12	[2, 3, 4]	\N	\N
301	129	7	2019-02-14	11	[2, 3, 4]	\N	\N
302	129	7	2019-07-02	6	[2, 3, 4]	\N	\N
303	130	7	2019-10-20	12	[3, 2, 4]	\N	\N
304	130	7	2019-02-13	11	[3, 2, 4]	\N	\N
305	130	7	2020-04-07	6	[3, 2, 4]	\N	\N
306	131	7	2019-01-11	12	[3, 2, 4]	\N	\N
307	131	7	2019-02-08	11	[3, 2, 4]	\N	\N
308	131	7	2020-01-09	6	[3, 2, 4]	\N	\N
309	132	7	2019-01-11	12	[2, 3, 4]	\N	\N
310	132	7	2019-02-07	11	[2, 3, 4]	\N	\N
311	132	7	2019-04-30	6	[2, 3, 4]	\N	\N
312	133	7	2019-01-11	12	[2, 3, 4]	\N	\N
313	133	7	2019-02-07	11	[2, 3, 4]	\N	\N
314	133	7	2019-07-22	6	[2, 3, 4]	\N	\N
315	134	7	2019-01-11	12	[2, 3, 4]	\N	\N
316	134	7	2019-02-07	11	[2, 3, 4]	\N	\N
317	134	7	2019-08-05	6	[2, 3, 4]	\N	\N
318	135	7	2019-01-11	12	[2, 3, 4]	\N	\N
319	135	7	2019-02-07	11	[2, 3, 4]	\N	\N
320	135	7	2019-04-30	6	[2, 3, 4]	\N	\N
321	136	7	2019-01-23	12	[3, 2, 4]	\N	\N
322	136	7	2019-03-11	11	[3, 2, 4]	\N	\N
323	136	7	2020-01-09	6	[3, 2, 4]	\N	\N
324	137	7	2019-01-23	12	[3, 2, 4]	\N	\N
325	137	7	2019-03-11	11	[3, 2, 4]	\N	\N
326	137	7	2020-01-09	6	[3, 2, 4]	\N	\N
327	138	7	2019-01-23	12	[2, 3, 4]	\N	\N
328	138	7	2019-03-11	11	[2, 3, 4]	\N	\N
329	138	7	2019-06-05	6	[2, 3, 4]	\N	\N
330	139	7	2019-01-23	12	[2, 3, 4]	\N	\N
331	139	7	2019-03-11	11	[2, 3, 4]	\N	\N
332	139	7	2019-06-05	6	[2, 3, 4]	\N	\N
333	140	7	2019-01-17	12	[2, 3, 4]	\N	\N
334	140	7	2019-03-04	11	[2, 3, 4]	\N	\N
335	140	7	2019-07-22	6	[2, 3, 4]	\N	\N
336	141	1	2021-12-20	6	[3, 2, 4]	\N	\N
337	142	7	2019-07-27	12	[3, 2, 4]	\N	\N
338	142	7	2019-04-23	11	[3, 2, 4]	\N	\N
339	142	7	2019-09-02	6	[3, 2, 4]	\N	\N
340	143	7	2019-03-03	12	[3, 4, 2]	\N	\N
341	143	7	2019-03-25	6	[3, 4, 2]	\N	\N
342	144	7	2019-03-03	12	[2, 3, 4]	\N	\N
343	144	7	2019-05-06	11	[2, 3, 4]	\N	\N
344	144	7	2019-05-13	6	[2, 3, 4]	\N	\N
345	145	7	2018-11-26	12	[3, 2, 4]	\N	\N
346	145	7	2019-03-11	11	[3, 2, 4]	\N	\N
347	145	7	2019-09-30	6	[3, 2, 4]	\N	\N
348	146	7	2019-03-12	12	[2, 3, 4]	\N	\N
349	146	7	2019-05-27	11	[2, 3, 4]	\N	\N
350	146	7	2019-07-24	6	[2, 3, 4]	\N	\N
351	147	4	2022-10-09	12	[3, 2, 4]	\N	\N
352	147	4	2021-09-07	11	[3, 2, 4]	\N	\N
353	148	7	2019-03-18	12	[3, 2, 4]	\N	\N
354	148	7	2019-05-27	11	[3, 2, 4]	\N	\N
355	148	7	2019-09-26	6	[3, 2, 4]	\N	\N
356	149	7	2019-03-18	12	[3, 2, 4]	\N	\N
357	149	7	2019-05-27	11	[3, 2, 4]	\N	\N
358	149	7	2019-09-26	6	[3, 2, 4]	\N	\N
359	151	7	2019-03-18	12	[3, 2, 4]	\N	\N
360	151	7	2019-09-26	6	[3, 2, 4]	\N	\N
361	153	1	2019-03-19	12	[3, 2, 5]	\N	\N
362	153	1	2016-07-07	11	[3, 2, 5]	\N	\N
363	153	1	2019-12-09	6	[3, 2, 5]	\N	\N
364	154	1	2016-03-15	12	[3, 2, 5]	\N	\N
365	154	1	2016-07-07	11	[3, 2, 5]	\N	\N
366	154	1	2019-12-09	6	[3, 2, 5]	\N	\N
367	155	7	2019-03-28	12	[2, 3, 4]	\N	\N
368	156	7	2019-03-28	12	[2, 3]	\N	\N
369	157	7	2019-03-28	12	[2, 3, 4]	\N	\N
370	158	7	2019-03-28	12	[2, 3, 4]	\N	\N
371	159	1	2016-07-01	11	[3, 2, 4]	\N	\N
372	159	1	2021-09-06	6	[3, 2, 4]	\N	\N
373	160	7	2019-04-25	12	[3, 4, 2]	\N	\N
374	160	7	2019-05-13	6	[3, 4, 2]	\N	\N
375	161	7	2019-04-25	12	[3, 4, 2]	\N	\N
376	161	7	2019-05-13	6	[3, 4, 2]	\N	\N
377	162	7	2019-05-16	12	[3, 2, 4]	\N	\N
378	162	7	2019-06-18	11	[3, 2, 4]	\N	\N
379	162	7	2019-12-02	6	[3, 2, 4]	\N	\N
380	163	7	2019-05-16	12	[3, 2, 4]	\N	\N
381	163	7	2019-06-18	11	[3, 2, 4]	\N	\N
382	163	7	2019-09-05	6	[3, 2, 4]	\N	\N
383	164	7	2019-05-16	12	[2, 3, 4]	\N	\N
384	164	7	2019-06-21	11	[2, 3, 4]	\N	\N
385	164	7	2019-07-24	6	[2, 3, 4]	\N	\N
386	165	7	2019-06-01	12	[3, 2, 4]	\N	\N
387	165	7	2019-10-08	11	[3, 2, 4]	\N	\N
388	165	7	2019-10-31	6	[3, 2, 4]	\N	\N
389	167	7	2019-06-10	12	[3, 2, 4]	\N	\N
390	167	7	2019-07-15	11	[3, 2, 4]	\N	\N
391	167	7	2019-10-01	6	[3, 2, 4]	\N	\N
392	170	1	2019-08-13	12	[3, 2, 4]	\N	\N
393	170	1	2019-09-05	11	[3, 2, 4]	\N	\N
394	170	1	2020-04-07	6	[3, 2, 4]	\N	\N
395	170	1	2020-03-10	8	[3, 2, 4]	\N	\N
396	171	7	2019-06-22	12	[3, 2, 4]	\N	\N
397	171	7	2019-07-24	11	[3, 2, 4]	\N	\N
398	171	7	2020-01-20	6	[3, 2, 4]	\N	\N
399	172	7	2019-07-18	12	[3, 2, 4]	\N	\N
400	172	7	2019-08-23	11	[3, 2, 4]	\N	\N
401	172	7	2019-09-05	6	[3, 2, 4]	\N	\N
402	173	7	2019-07-18	12	[3, 2, 4]	\N	\N
403	173	7	2019-08-23	11	[3, 2, 4]	\N	\N
404	173	7	2019-09-05	6	[3, 2, 4]	\N	\N
405	174	7	2019-07-18	12	[3, 2, 4]	\N	\N
406	174	7	2019-08-23	11	[3, 2, 4]	\N	\N
407	174	7	2019-09-05	6	[3, 2, 4]	\N	\N
408	175	7	2019-07-22	12	[3, 2, 4]	\N	\N
409	176	7	2019-07-27	12	[3, 2, 4]	\N	\N
410	176	7	2018-09-30	6	[3, 2, 4]	\N	\N
411	177	1	2019-09-16	12	[3, 2, 4]	\N	\N
412	177	1	2019-10-07	11	[3, 2, 4]	\N	\N
413	177	1	2020-12-24	6	[3, 2, 4]	\N	\N
414	178	1	2019-10-12	12	[3, 2, 4]	\N	\N
415	178	1	2019-11-01	11	[3, 2, 4]	\N	\N
416	178	1	2020-03-03	6	[3, 2, 4]	\N	\N
417	180	1	2019-09-16	12	[3, 2, 4]	\N	\N
418	180	1	2019-10-07	11	[3, 2, 4]	\N	\N
419	180	1	2019-12-10	6	[3, 2, 4]	\N	\N
420	182	1	2019-11-20	12	[3, 2, 4]	\N	\N
421	182	1	2019-12-10	11	[3, 2, 4]	\N	\N
422	182	1	2022-08-31	6	[3, 2, 4]	\N	\N
423	183	1	2019-10-27	12	[3, 2, 4]	\N	\N
424	183	1	2019-11-25	11	[3, 2, 4]	\N	\N
425	183	1	2020-03-03	6	[3, 2, 4]	\N	\N
426	184	1	2019-10-27	12	[3, 2, 4]	\N	\N
427	184	1	2019-11-25	11	[3, 2, 4]	\N	\N
428	184	1	2022-10-17	6	[3, 2, 4]	\N	\N
429	185	4	2019-12-26	12	[3, 2, 4]	\N	\N
430	185	4	2020-01-21	11	[3, 2, 4]	\N	\N
431	185	4	2021-04-12	6	[3, 2, 4]	\N	\N
432	186	4	2019-10-06	12	[3, 2, 4]	\N	\N
433	187	4	2019-10-06	12	[3, 2, 4]	\N	\N
434	188	7	2019-11-07	12	[3, 2, 4]	\N	\N
435	188	7	2019-12-11	11	[3, 2, 4]	\N	\N
436	188	7	2020-01-27	6	[3, 2, 4]	\N	\N
437	189	7	2019-11-07	12	[3, 2, 4]	\N	\N
438	189	7	2019-12-23	8	[3, 2, 4]	\N	\N
439	190	1	2019-12-26	12	[3, 2, 4]	\N	\N
440	190	1	2020-11-21	11	[3, 2, 4]	\N	\N
441	190	1	2022-06-15	6	[3, 2, 4]	\N	\N
442	191	7	2019-11-20	12	[3, 2, 4]	\N	\N
443	191	7	2019-12-18	11	[3, 2, 4]	\N	\N
444	191	7	2020-01-09	6	[3, 2, 4]	\N	\N
445	194	1	2022-02-13	12	[3, 2, 4]	\N	\N
446	194	1	2022-03-15	11	[3, 2, 4]	\N	\N
447	194	1	2022-10-17	6	[3, 2, 4]	\N	\N
448	195	7	2020-02-23	12	[3, 2, 4]	\N	\N
449	195	7	2020-03-11	11	[3, 2, 4]	\N	\N
450	195	7	2020-04-07	6	[3, 2, 4]	\N	\N
451	200	1	2022-01-22	12	[3, 2, 4]	\N	\N
452	200	1	2022-02-16	11	[3, 2, 4]	\N	\N
453	201	4	2022-02-19	12	[3, 2, 4]	\N	\N
454	201	4	2022-04-11	11	[3, 2, 4]	\N	\N
455	201	4	2022-10-03	6	[3, 2, 4]	\N	\N
456	202	4	2022-02-13	12	[3, 2, 4]	\N	\N
457	202	4	2022-03-29	11	[3, 2, 4]	\N	\N
458	203	4	2022-02-13	12	[3, 2, 4]	\N	\N
459	203	4	2022-03-29	11	[3, 2, 4]	\N	\N
460	205	1	2022-02-19	12	[3, 2, 4]	\N	\N
461	205	1	2022-03-29	11	[3, 2, 4]	\N	\N
462	206	1	2022-02-13	12	[3, 2, 4]	\N	\N
463	206	1	2022-03-15	11	[3, 2, 4]	\N	\N
464	208	1	2022-02-13	12	[3, 2, 4]	\N	\N
465	208	1	2022-03-29	11	[3, 2, 4]	\N	\N
466	209	1	2022-02-13	12	[3, 2, 4]	\N	\N
467	209	1	2022-03-29	11	[3, 2, 4]	\N	\N
468	212	1	2022-02-13	12	[3, 2, 4]	\N	\N
469	212	1	2022-03-29	11	[3, 2, 4]	\N	\N
470	218	1	2022-03-05	12	[3, 2, 4]	\N	\N
471	218	1	2022-04-11	11	[3, 2, 4]	\N	\N
472	223	1	2022-05-02	12	[3, 2, 4]	\N	\N
473	223	1	2022-05-20	11	[3, 2, 4]	\N	\N
474	223	1	2022-09-02	6	[3, 2, 4]	\N	\N
475	224	1	2022-06-01	12	[3, 2, 4]	\N	\N
476	224	1	2022-06-20	11	[3, 2, 4]	\N	\N
477	225	1	2022-06-01	12	[3, 2, 4]	\N	\N
478	225	1	2022-06-20	11	[3, 2, 4]	\N	\N
479	226	1	2022-05-02	12	[3, 2, 4]	\N	\N
480	226	1	2022-05-20	11	[3, 2, 4]	\N	\N
481	226	1	2022-09-02	6	[3, 2, 4]	\N	\N
482	227	4	2022-06-30	12	[3, 2, 4]	\N	\N
483	227	4	2022-07-14	11	[3, 2, 4]	\N	\N
484	227	4	2022-12-14	6	[3, 2, 4]	\N	\N
485	230	4	2022-06-30	12	[3, 2, 4]	\N	\N
486	230	4	2022-07-14	11	[3, 2, 4]	\N	\N
487	235	4	2022-09-15	12	[3, 2, 4]	\N	\N
488	235	4	2022-10-07	11	[3, 2, 4]	\N	\N
489	236	4	2022-09-15	12	[3, 2, 4]	\N	\N
490	236	4	2022-10-07	11	[3, 2, 4]	\N	\N
491	237	4	2022-09-15	12	[3, 2, 4]	\N	\N
492	237	4	2022-10-07	11	[3, 2, 4]	\N	\N
493	238	1	2022-10-20	12	[3, 2, 4]	\N	\N
494	238	1	2022-11-10	11	[3, 2, 4]	\N	\N
495	239	1	2022-10-20	12	[3, 2, 4]	\N	\N
496	239	1	2022-11-10	11	[3, 2, 4]	\N	\N
497	240	1	2022-10-20	12	[3, 2, 4]	\N	\N
498	240	1	2022-11-10	11	[3, 2, 4]	\N	\N
499	241	1	2022-07-25	11	[3, 2]	\N	\N
500	246	1	2022-12-23	12	[3, 2, 4]	\N	\N
501	247	1	2022-12-23	12	[3, 2, 4]	\N	\N
503	4	4	2009-06-30	11	[3, 2]	2023-01-03 22:13:02	2023-01-03 22:13:02
504	4	1	2016-01-11	11	[3, 2]	2023-01-03 22:13:02	2023-01-03 22:13:02
505	241	4	2022-07-25	11	[3, 2]	2023-01-03 22:13:56	2023-01-03 22:13:56
507	147	\N	2023-01-18	8	[3, 2, 4]	2023-01-18 10:53:04	2023-01-18 10:53:04
508	246	1	2023-01-23	11	[3, 2, 4]	2023-01-18 11:49:44	2023-01-18 11:49:44
509	247	1	2023-01-23	11	[3, 2, 4]	2023-01-18 11:51:19	2023-01-18 11:51:19
510	147	4	2023-01-18	6	[3, 2, 4]	2023-02-01 08:03:11	2023-02-01 08:03:11
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.employees (id, passport_number, last_name_ru, first_name_ru, citizenship_id, status_id, user_ids, gender, passport_serie, passport_issuer_code, resident_document_serie, resident_document_number, phone, work_permit_serie, work_permit_number, invitation_number, cert_number, visa_multiplicity, visa_category, visa_serie, visa_number, migr_card_serie, migr_card_number, middle_name_ru, last_name_en, first_name_en, middle_name_en, entry_checkpoint, passport_issuer, resident_document, cert_issuer, birth_place, address, history, birth_date, passport_issued_date, passport_expired_date, resident_document_issued_date, resident_document_expired_date, work_permit_issued_date, work_permit_started_date, work_permit_expired_date, work_permit_paid_till_date, taxpayer_id_issued_date, cert_issued_date, visa_issued_date, visa_started_date, visa_expired_date, entry_date, migr_card_issued_date, reg_date, departure_date, whence_id, permit_id, taxpayer_id, host_id, reg_address_id, real_address_id, resident_document_issuer_id, work_permit_issuer_id, visa_issuer_id, created_at, updated_at) FROM stdin;
3	560511	Молякова	Наталия	177	1	[2, 3, 4, 5]	FEMALE	2817															Хасановна					Отделение УФМС России по Тверской обл. в Кимрском р-не				Тверская обл.,г.Кимры,пр.Титова ,д.13а,корп.2,кв.49	[{"date": "2018-04-19 13:5:39", "user": "209", "prev_value": {"address": ""}}, {"date": "2018-04-20 9:50:0", "user": "207", "prev_value": []}, {"date": "2022-07-26 14:44:18", "user": "209", "prev_value": {"status_id": "BOSS", "hired_date": null, "contract_number": ""}}, {"date": "2022-07-27 20:51:16", "user": "207", "prev_value": {"status_id": "WORKER"}}]	\N	2017-12-23	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
4	705704	Куманеева	Мария	177	1	[3, 2]	FEMALE	2805															Федоровна					Кимрским ОВД Тверской области, код подразделения 692-017					[{"date": "2018-11-20 11:49:19", "user": "209", "prev_value": {"visa_started_date": "2023-01-03", "work_permit_started_date": "2023-01-03"}}]	\N	2007-02-16	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	177	0	0	0	0	0	0	0	0	\N	\N
15	N1461431	НГО	ДИНЬ ХЫНГ	232	6	[3, 2, 4]	MALE						69	1800004775	202409497	00084373	MULTI	WORK	12	1349193	4618	9275395		NGO	DINH HUNG		Шереметьево 566	Посольством Вьетнама в РФ		Ханойский университет индустрии	Бакзянг		[{"date": "2018-11-19 12:2:19", "user": "209", "prev_value": {"work_permit_started_date": "2019-11-28"}}, {"date": "2019-03-01 11:3:35", "user": "207", "prev_value": {"work_permit_started_date": "2018-11-28"}}, {"date": "2019-03-01 11:4:33", "user": "207", "prev_value": {"work_permit_started_date": "2018-11-29"}}, {"date": "2019-11-25 13:41:54", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}]	1983-05-15	2012-02-06	2022-02-06	\N	\N	2018-11-01	2018-11-28	2019-11-27	\N	\N	2009-07-02	2018-11-06	2018-11-29	2019-11-27	2018-06-24	2018-06-24	2018-11-20	\N	232	27	0	1	2	2	0	2	0	\N	\N
16	166106	Морозова	Юлия	177	1	[2, 3, 4, 5]	FEMALE	2811															Михайловна					Отделением УФМС России по Тверской обл. в Кимрском р-не			Тверская обл., Кимры г.	г. КИМРЫ, ул. ОРДЖОНИКИДЗЕ, д. 8/6	[{"date": "2018-09-28 11:43:8", "user": "209", "prev_value": {"passport_issuer": "ОУФМС РФ по Тверской обл в Кимрском р-не"}}, {"date": "2022-07-26 14:43:43", "user": "209", "prev_value": {"status_id": "BOSS", "hired_date": null, "occupation_id": "", "contract_number": ""}}, {"date": "2022-07-27 20:50:51", "user": "207", "prev_value": {"status_id": "WORKER"}}]	1964-07-27	2012-03-29	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	177	0	0	0	0	0	0	0	0	\N	\N
17	C0896316	БУЙ	ТХИ ЛУЕН	232	6	[2, 3, 4]	FEMALE						69	1800001703	202407745	010581-MCN/LDTBXH-DN	MULTI	WORK	12	1233332	4616	7307793		BUI	THI LUYEN		Шереметьево 335	миграционным департаментом		ЧАСТНОЕ ПТУ "ЗУИТОАН"	Тхайбинь		[{"date": "2019-02-20 16:46:9", "user": "209", "prev_value": {"occupation_id": "1"}}, {"date": "2019-03-12 12:44:50", "user": "209", "prev_value": {"hired_date": "2019-03-26"}}, {"date": "2019-03-21 22:34:59", "user": "214", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-03-22 11:30:44", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}, {"date": "2019-03-22 11:32:29", "user": "209", "prev_value": {"reg_date": "2018-03-23", "departure_date": "2019-03-24"}}, {"date": "2019-03-22 11:46:50", "user": "209", "prev_value": {"fired_date": "2019-03-22"}}, {"date": "2019-03-26 10:54:52", "user": "209", "prev_value": {"occupation_id": "6"}}, {"date": "2019-03-26 13:18:20", "user": "209", "prev_value": {"migr_card_issued_date": "2017-09-19"}}, {"date": "2019-05-22 10:28:32", "user": "209", "prev_value": {"occupation_id": "1"}}]	1982-06-20	2015-10-12	2025-10-12	\N	\N	2018-03-14	2018-03-27	2019-03-26	\N	\N	2012-07-04	2018-03-15	2018-03-28	2019-03-26	2016-06-04	2016-06-04	2019-03-26	\N	232	33	0	1	2	2	0	2	0	\N	\N
18	#1	Иванов	Андрей	0	9	[3, 2]	MALE																Эдуардович										[{"date": "2018-02-13 13:11:53", "user": "207", "prev_value": {"status_id": "BOSS", "whence_name": "", "citizenship_name": ""}}, {"date": "2018-02-13 23:8:37", "user": "207", "prev_value": {"employer_id": ""}}, {"date": "2018-04-03 21:31:13", "user": "207", "prev_value": {"current_value": "", "passport_number": "Нет", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2018-04-03 21:34:34", "user": "207", "prev_value": {"current_value": "", "passport_number": "#3", "migr_card_issued_date": "-0001-11-30"}}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
19	B6526933	НГУЕН	ДИНЬ ТУЕН	232	6	[3, 5, 2]	MALE						69	1800001767	202407741	003122319/LDTBXH-DN	MULTI	WORK	12	1233339	4616	8264443		NGUYEN	DINH TUYEN		ШЕРЕМЕТЬЕВО 760	ИММИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		ЧАСТНОЕ ПТУ "ЗУИТОАН"	ХАНАМ	ВЬЕТНАМ	[{"date": "2019-02-04 13:53:41", "user": "209", "prev_value": {"migr_card_issued_date": "2025-05-20"}}]	1986-12-11	2012-04-11	2022-04-11	\N	\N	2018-03-14	2018-03-27	2019-03-26	\N	\N	2010-09-06	2018-03-15	2018-03-28	2019-03-26	2016-05-25	2016-05-25	2018-03-23	\N	232	19	0	1	4	4	0	2	0	\N	\N
20	B8042084	НГУЕН	ТХАНЬ ТХАТ	232	6	[3, 5, 2]	MALE							1800001855	202407736	000978615/LDTBXH-DN	MULTI	WORK	12	1233331	4616	8264444		NGUYEN 	THANH THAT		ШЕРЕМЕТЬЕВО 760	миграционным департаментом		Намдиньское промышленное текстильно-швейное ПТУ	Тхайбинь		[{"date": "2018-12-03 12:14:25", "user": "209", "prev_value": {"migr_card_issued_date": "-0001-11-30"}}]	1985-03-02	2013-06-19	2023-06-19	\N	\N	2018-03-20	2018-03-27	2019-03-26	\N	\N	2006-08-30	2018-03-15	2018-03-28	2019-03-26	2016-05-25	2016-05-25	2018-03-23	\N	232	19	0	1	4	4	0	2	0	\N	\N
21	B8347944	НГУЕН	ТХИ ЛАН	232	6	[3, 5, 2]	FEMALE							1700001700	202407735	003125543/LDNDXH-DN			12	0971735	4617	8398982		NGUYEN	THI LAN		шереметьево 751	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ТХАНЬХОА		[{"date": "2018-07-25 13:54:21", "user": "209", "prev_value": {"employ_permit_id": "1", "work_permit_expired_date": "2018-03-27", "work_permit_started_date": "2017-03-28"}}]	1991-09-15	2013-10-04	2023-10-04	\N	\N	2017-03-17	2018-03-27	2019-03-26	\N	\N	2011-06-01	2017-03-24	2017-03-29	2018-03-27	2016-05-25	\N	2017-03-24	\N	232	19	0	1	4	4	0	2	0	\N	\N
22	C1273743 	НГУЕН	ТХИ ТХОАН	232	6	[3, 2, 4]	FEMALE						69	2100005260	202407749	003125545/LDTBXH-DN	MULTI	WORK	12	1946495	4617	8836224		NGUYEN 	THI THOAN		шереметьево 631	миграционным департаментом		Хайзыонгский профессиональный колледж	ХАЙЗЫОНГ		[{"date": "2019-02-20 14:10:38", "user": "209", "prev_value": {"occupation_id": "1"}}, {"date": "2019-03-12 12:46:47", "user": "209", "prev_value": {"hired_date": "2019-03-26"}}, {"date": "2019-03-25 14:40:5", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": "2018-03-14", "work_permit_expired_date": "2019-03-26", "work_permit_started_date": "2018-03-27"}}, {"date": "2019-03-25 14:42:56", "user": "209", "prev_value": {"visa_number": "1233327", "visa_issued_date": "2018-03-15", "visa_expired_date": "2019-03-26", "visa_started_date": "2018-03-28"}}, {"date": "2019-03-25 15:19:58", "user": "209", "prev_value": {"migr_card_issued_date": "2019-09-20"}}, {"date": "2019-03-26 11:34:11", "user": "209", "prev_value": {"visa_issued_date": "2018-03-18"}}, {"date": "2020-03-20 13:10:57", "user": "209", "prev_value": {"employ_permit_id": "33", "work_permit_number": "1900002940", "work_permit_issued_date": "2019-03-11", "work_permit_expired_date": "2020-03-25", "work_permit_started_date": "2019-03-26"}}, {"date": "2020-03-20 13:12:3", "user": "209", "prev_value": {"reg_date": "2018-03-23", "visa_serie": "12", "visa_number": "1560155", "visa_issued_date": "2019-03-18", "visa_expired_date": "2020-03-25", "visa_started_date": "2019-03-27"}}, {"date": "2021-03-18 16:10:30", "user": "209", "prev_value": {"employ_permit_id": "48", "work_permit_number": "2000003982", "work_permit_issued_date": "2020-03-13", "work_permit_expired_date": "2021-03-24", "work_permit_started_date": "2020-03-25"}}, {"date": "2021-03-18 16:12:14", "user": "209", "prev_value": {"reg_date": "2020-03-24", "visa_serie": "13", "visa_number": "0061691", "visa_issued_date": "2020-03-16", "visa_expired_date": "2021-03-24", "visa_started_date": "2020-03-26"}}, {"date": "2021-12-20 17:13:11", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1997-09-05	2016-01-08	2026-01-08	\N	\N	2021-03-15	\N	2022-03-23	\N	\N	2011-06-01	2021-03-15	2021-03-25	2022-03-23	2017-09-19	2017-09-19	2021-03-23	\N	232	56	0	1	2	2	0	2	0	\N	\N
23	B7068408	ЛЭ	ЧУНГ ДАМ	232	6	[3, 4, 2]	MALE							1800001735	202407739	003067 06/CDNHD	MULTI	WORK	12	1233330	4616	7307792		LE	TRUNG DAM		Шереметьево 335	миграционным департаментом		Хайзыонгский профессиональный колледж	Тхайбинь		[{"date": "2019-01-28 13:15:8", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1979-07-21	2012-08-27	2022-08-27	\N	\N	2018-03-14	2018-03-27	2019-03-26	\N	\N	2006-07-02	2018-03-15	2018-03-28	2019-03-26	2016-06-04	2004-06-20	2018-03-23	\N	232	19	0	1	2	2	0	2	0	\N	\N
24	B9676332	ФАН 	ВАН ХОАНГ	232	6	[3, 2, 4]	MALE						69	1900002965	202407747	008145 14/CDKTHY	MULTI	WORK	12	1560153	4618	8165275		PHAN	VAN HOANG		шереметьево 732	миграционным департаментом		Хынгиенский промышленный колледж	БАКНИНЬ		[{"date": "2019-02-20 14:17:35", "user": "209", "prev_value": {"hired_date": "2018-03-27", "passport_number": "В9676332", "employ_permit_id": "19", "work_permit_number": "1800001816"}}, {"date": "2019-03-12 12:47:49", "user": "209", "prev_value": {"hired_date": "2019-03-26"}}, {"date": "2019-03-25 15:9:9", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": "2018-03-14", "work_permit_expired_date": "2019-03-26", "work_permit_started_date": "2018-03-27"}}, {"date": "2019-03-25 15:11:16", "user": "209", "prev_value": {"reg_date": "2018-03-25", "visa_number": "1233335", "visa_issued_date": "2018-03-15", "visa_expired_date": "2019-03-26", "visa_started_date": "2018-03-28"}}, {"date": "2020-03-23 13:29:29", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2020-03-23 13:30:47", "user": "209", "prev_value": {"reg_date": "2018-04-20"}}]	1995-05-09	2014-10-24	2024-10-24	\N	\N	2019-03-11	2019-03-26	2020-03-25	\N	\N	2014-07-03	2019-03-18	2019-03-27	2020-03-25	2018-04-17	2018-04-17	2019-03-26	\N	232	33	0	1	2	2	0	2	0	\N	\N
25	C0952854	ДАМ	ТХИ ТХАМ	232	6	[3, 2, 4]	FEMALE						69	2100005253	202407737	010319-MCN/LDTBXH-DN	MULTI	WORK	12	1946496	4616	7307788		DAM	THI THAM		Шереметьево 335	миграционным департаментом		ЧАСТНОЕ ПТУ "ЗУИТОАН"	Тхайбинь		[{"date": "2019-02-20 14:1:53", "user": "209", "prev_value": {"hired_date": "2018-03-27", "passport_number": "С0952854", "employ_permit_id": "19", "work_permit_number": "1800001710"}}, {"date": "2019-03-12 12:45:30", "user": "209", "prev_value": {"hired_date": "2019-03-26"}}, {"date": "2019-03-25 14:3:57", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": "2018-03-14", "work_permit_expired_date": "2019-03-26", "work_permit_started_date": "2018-03-27"}}, {"date": "2019-03-25 14:6:15", "user": "209", "prev_value": {"visa_number": "1233333", "visa_issued_date": "2018-03-15", "visa_expired_date": "2019-03-26", "visa_started_date": "2018-03-28", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2020-03-20 12:51:32", "user": "209", "prev_value": {"employ_permit_id": "33", "work_permit_number": "1900002919", "work_permit_issued_date": "2019-03-11", "work_permit_expired_date": "2020-03-25", "work_permit_started_date": "2019-03-26"}}, {"date": "2020-03-20 12:52:53", "user": "209", "prev_value": {"reg_date": "2018-03-23", "visa_serie": "12", "visa_number": "1560158", "visa_issued_date": "2019-03-18", "visa_expired_date": "2020-03-25", "visa_started_date": "2019-03-27"}}, {"date": "2021-03-18 16:5:24", "user": "209", "prev_value": {"employ_permit_id": "48", "work_permit_number": "2000004009", "work_permit_issued_date": "2020-03-13", "work_permit_expired_date": "2021-03-24", "work_permit_started_date": "2020-03-25"}}, {"date": "2021-03-18 16:7:45", "user": "209", "prev_value": {"reg_date": "2020-03-24", "visa_serie": "13", "visa_number": "0061690", "visa_issued_date": "2020-03-16", "visa_expired_date": "2021-03-24", "visa_started_date": "2020-03-26"}}, {"date": "2021-04-12 13:10:6", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1997-11-04	2015-09-24	2025-09-24	\N	\N	2021-03-15	\N	2022-03-23	\N	\N	2013-07-04	2021-03-15	2021-03-25	2022-03-23	2016-06-04	2016-06-04	2021-03-23	\N	232	56	0	1	2	2	0	2	0	\N	\N
26	C0983811	ФАМ	КУОК ХУИ	232	6	[3, 2, 4]	MALE						69	2100005278	202407733	004431	MULTI	WORK	12	1946497	4619	7396812		PHAM	QUOC HUY		Шереметьево 335	миграционным департаментом		Намдинский технический техникум	Тхайбинь		[{"date": "2019-02-20 14:14:46", "user": "209", "prev_value": {"hired_date": "2018-03-27", "passport_number": "С0983811", "employ_permit_id": "19", "work_permit_number": "1800001809", "migr_card_issued_date": "2020-06-20"}}, {"date": "2019-03-12 12:47:25", "user": "209", "prev_value": {"hired_date": "2019-03-26"}}, {"date": "2019-03-25 15:1:33", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": "2018-03-14", "work_permit_expired_date": "2019-03-26", "work_permit_started_date": "2018-03-27"}}, {"date": "2019-03-25 15:2:30", "user": "209", "prev_value": {"visa_number": "1233328", "visa_issued_date": "2018-03-15", "visa_expired_date": "2019-03-26", "visa_started_date": "2018-03-28"}}, {"date": "2019-03-25 15:3:18", "user": "209", "prev_value": {"visa_number": "1560153"}}, {"date": "2019-06-03 12:6:40", "user": "209", "prev_value": {"status_id": "WORKER", "departure_date": "-0001-11-30"}}, {"date": "2019-06-24 9:27:53", "user": "209", "prev_value": {"reg_date": "2018-03-23", "status_id": "FURLOUGH", "departure_date": "2019-06-03", "migr_card_serie": "4616", "migr_card_number": "7307791", "migr_card_issued_date": "2020-06-20"}}, {"date": "2019-06-24 11:30:52", "user": "209", "prev_value": {"entry_date": "2016-06-04"}}, {"date": "2019-09-12 16:8:21", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-09-12 16:8:46", "user": "209", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-09-17 11:29:17", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-09-17 14:13:29", "user": "209", "prev_value": {"departure_date": "2019-09-12", "migr_card_number": "6925080", "migr_card_issued_date": "2019-06-19"}}, {"date": "2020-03-20 13:18:20", "user": "209", "prev_value": {"employ_permit_id": "33", "work_permit_number": "1900002958", "work_permit_issued_date": "2019-03-11", "work_permit_expired_date": "2020-03-25", "work_permit_started_date": "2019-03-26"}}, {"date": "2020-03-20 13:19:29", "user": "209", "prev_value": {"reg_date": null, "visa_serie": "12", "visa_number": "1560154", "visa_issued_date": "2019-03-18", "visa_expired_date": "2020-03-25", "visa_started_date": "2019-03-27"}}, {"date": "2020-03-23 12:51:30", "user": "209", "prev_value": {"entry_date": "2019-06-19"}}, {"date": "2021-03-18 16:15:20", "user": "209", "prev_value": {"employ_permit_id": "48", "work_permit_number": "2000003975", "work_permit_issued_date": "2020-03-13", "work_permit_expired_date": "2021-03-24", "work_permit_started_date": "2020-03-25", "work_permit_paid_till_date": null}}, {"date": "2021-03-18 16:16:40", "user": "209", "prev_value": {"reg_date": "2020-03-24", "visa_serie": "13", "visa_number": "0061693", "visa_issued_date": "2020-03-16", "visa_expired_date": "2021-03-24", "visa_started_date": "2020-03-26"}}, {"date": "2021-03-18 16:30:30", "user": "209", "prev_value": {"work_permit_paid_till_date": "2022-03-23"}}, {"date": "2021-04-12 13:16:31", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1997-01-18	2015-10-07	2025-10-07	\N	\N	2021-03-15	2021-03-24	2022-03-23	\N	\N	2015-07-02	2021-03-15	2021-03-25	2022-03-23	2019-09-16	2019-09-16	2021-03-23	\N	232	56	0	1	2	2	0	2	0	\N	\N
27	N1464340	НГО	ДИНЬ ДЫК	232	6	[3, 2, 4]	MALE						69	1900002926	202407742	003120430/LDNDXH-DN	MULTI	WORK	12	1560156	4616	7307790		NGO	DINH DUC		Шереметьево 335	ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ		Ханойское ПТУ швейной технологии и моды	БАКЖАНГ		[{"date": "2019-02-20 16:21:11", "user": "209", "prev_value": {"passport_issuer": "Посольством Вьетнама в РФ"}}, {"date": "2019-03-12 12:46:11", "user": "209", "prev_value": {"hired_date": "2019-03-26"}}, {"date": "2019-03-25 14:13:7", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": "2018-03-14", "work_permit_expired_date": "2019-03-26", "work_permit_started_date": "2018-03-27"}}, {"date": "2019-03-25 14:14:40", "user": "209", "prev_value": {"visa_number": "1233337", "visa_issued_date": "2018-03-15", "visa_expired_date": "2019-03-26", "visa_started_date": "2018-03-28"}}, {"date": "2019-03-25 15:17:8", "user": "209", "prev_value": {"migr_card_issued_date": "2004-06-16"}}, {"date": "2020-03-23 13:16:34", "user": "209", "prev_value": {"fired_date": null}}, {"date": "2020-03-23 13:16:46", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2020-03-23 13:16:57", "user": "209", "prev_value": {"work_address_id": ""}}, {"date": "2020-03-23 13:17:17", "user": "209", "prev_value": {"reg_date": "2018-03-23"}}]	1987-12-18	2012-06-06	2022-06-06	\N	\N	2019-03-11	2019-03-26	2020-03-25	\N	\N	2006-09-10	2019-03-18	2019-03-27	2020-03-25	2016-06-04	2016-06-04	2019-03-26	\N	232	33	0	1	2	2	0	2	0	\N	\N
28	C1088103	НГУЕН	ВАН ВЫОНГ	232	6	[3, 2, 4]	MALE						69	2100006240	202402391		MULTI	WORK	12	2030555	4619	9807272		NGUYEN	VAN VUONG		шереметьево 621	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			БАКНИНЬ		[{"date": "2019-02-28 15:40:26", "user": "214", "prev_value": {"departure_date": "2019-03-26"}}, {"date": "2019-03-01 12:45:14", "user": "209", "prev_value": {"passport_issued_date": "-0001-11-30", "passport_expired_date": "-0001-11-30"}}, {"date": "2019-03-01 12:46:45", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "hired_date": "-0001-11-30", "work_permit_serie": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-01 12:51:48", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "departure_date": "2019-02-23", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-01 12:52:54", "user": "209", "prev_value": {"birth_date": "-0001-11-30"}}, {"date": "2019-03-01 12:57:47", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-12-16 13:56:30", "user": "209", "prev_value": {"passport_number": "C1088103", "current_passport_number": ""}}, {"date": "2019-12-17 12:44:26", "user": "207", "prev_value": {"passport_issuer": "миграционным департаментом", "passport_number": "C1088105"}}, {"date": "2019-12-17 13:11:20", "user": "209", "prev_value": {"status_id": "FIRED", "current_passport_number": ""}}, {"date": "2019-12-17 13:12:25", "user": "209", "prev_value": {"fired_date": "2019-02-28", "hired_date": "2019-03-27", "cert_issuer": "Хынгиенский промышленный колледж", "cert_number": "007626 05/CDKTHY", "occupation_id": "6", "contract_number": "17", "employ_permit_id": "19", "work_permit_serie": "69", "work_permit_number": "1800001750", "current_passport_number": "", "work_permit_issued_date": "2018-03-14", "work_permit_expired_date": "2019-03-26", "work_permit_started_date": "2018-03-27"}}, {"date": "2019-12-17 13:13:31", "user": "209", "prev_value": {"reg_date": "2018-03-23", "entry_date": "2019-02-28", "visa_serie": "12", "visa_number": "1233338", "visa_issuer_id": "РФ, г.Тверь", "migr_card_serie": "4616", "entry_checkpoint": "шереметьево 663", "migr_card_number": "8338054", "visa_issued_date": "2018-03-15", "invitation_number": "202407748", "visa_expired_date": "2019-03-26", "visa_started_date": "2018-03-28", "migr_card_issued_date": "2016-06-08", "current_passport_number": ""}}, {"date": "2019-12-17 13:14:16", "user": "209", "prev_value": {"visa_multiplicity": "MULTI", "current_passport_number": ""}}, {"date": "2020-02-07 12:34:50", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "invitation_number": "", "visa_expired_date": "-0001-11-30", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-02-07 12:37:49", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-02-20 18:2:32", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": "-0001-11-30", "contract_number": "", "work_address_id": "", "work_permit_serie": "", "work_permit_number": "", "current_passport_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2020-02-20 18:4:6", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-03-11 11:11:38", "user": "209", "prev_value": {"fired_date": "2019-02-28"}}, {"date": "2020-04-09 13:3:56", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2685476", "visa_issued_date": "2020-02-03"}}, {"date": "2020-04-09 13:8:45", "user": "209", "prev_value": {"visa_expired_date": "2020-04-23", "visa_started_date": "2020-02-03"}}, {"date": "2020-04-09 13:11:52", "user": "209", "prev_value": {"visa_started_date": "2020-04-03"}}, {"date": "2020-11-16 16:53:46", "user": "209", "prev_value": {"hired_date": "2020-02-21", "employ_permit_id": "43", "work_permit_number": "2000003870"}}, {"date": "2020-11-16 17:0:10", "user": "209", "prev_value": {"employ_permit_id": "", "work_permit_issued_date": "2020-02-14", "work_permit_expired_date": "2020-11-21", "work_permit_started_date": "2020-02-14"}}, {"date": "2020-11-16 17:6:34", "user": "209", "prev_value": {"visa_serie": "13", "visa_number": "0061818", "visa_issued_date": "2020-04-03", "visa_expired_date": "2020-11-21", "visa_multiplicity": "SINGLE", "visa_started_date": "2020-04-24"}}, {"date": "2020-11-16 17:34:6", "user": "209", "prev_value": {"reg_date": "2020-02-07"}}, {"date": "2020-11-19 12:44:33", "user": "209", "prev_value": {"reg_date": null, "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ"}}, {"date": "2021-11-16 9:31:13", "user": "209", "prev_value": {"reg_date": "2020-11-18", "visa_number": "1771289", "visa_issued_date": "2020-11-09", "visa_expired_date": "2021-11-20", "visa_started_date": "2020-11-22"}}, {"date": "2021-11-16 9:32:21", "user": "209", "prev_value": {"work_permit_number": "2000005027", "work_permit_issued_date": "2020-10-28", "work_permit_expired_date": "2021-11-20", "work_permit_started_date": "2020-11-21"}}, {"date": "2021-11-16 10:23:42", "user": "209", "prev_value": {"employ_permit_id": "51"}}, {"date": "2022-04-05 13:45:25", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1985-05-02	2015-11-26	2025-11-26	\N	\N	2021-10-28	2021-11-20	2022-11-19	\N	\N	\N	2021-11-09	2021-11-21	2022-11-19	2020-02-06	2020-02-06	2021-11-16	\N	232	60	0	1	2	2	0	2	0	\N	\N
29	C1088104	ДО	ТХИ МИНЬ	232	6	[3, 4, 2]	FEMALE						69	1800001728	202407746	003125495/LDNDXH-DN	MULTI	WORK	12	1233336	4616	8351922		DO	THI MINH		Шереметьево 836	миграционным департаментом		Ханойское ПТУ швейной технологии и моды	БАКНИНЬ		[{"date": "2019-03-01 12:26:49", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "hired_date": "-0001-11-30", "work_permit_serie": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-01 12:28:44", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-01 12:34:54", "user": "209", "prev_value": {"birth_date": "-0001-11-30"}}, {"date": "2019-03-01 12:36:19", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-03-12 14:14:14", "user": "209", "prev_value": {"departure_date": "2019-02-23"}}]	1986-06-20	2015-11-26	2025-11-26	\N	\N	2018-03-14	2018-03-27	2019-03-26	\N	\N	\N	2018-03-15	2018-03-28	2019-03-26	2016-06-08	2016-06-08	2018-03-23	\N	232	19	0	1	2	2	0	2	0	\N	\N
30	B6208210	ХОАНГ	ТХИ ХАНЬ	232	8	[3, 2, 5]	FEMALE								202408127				12	1233334	4616	8431873		HOANG	THI HANH		шереметьево 626	миграционным департаментом			Тхайбинь		[{"date": "2019-02-04 10:40:33", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2020-03-13 11:46:3", "user": "209", "prev_value": []}]	1982-12-20	2012-02-10	2022-02-10	\N	\N	\N	\N	\N	\N	\N	\N	2018-03-15	2018-03-28	2019-03-26	2016-07-20	2020-07-20	2018-03-23	\N	232	19	0	1	4	4	0	0	0	\N	\N
31	N1901375	НИНЬ	ТХИ ЛУАН	232	6	[3, 5, 2]	FEMALE							1800002739	202408135	003121203/LDNDXH-DN	MULTI	WORK	12	1233626	4617	8966004		NINH	THI LUAN		Шереметьево 564	ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ		Ханойское ПТУ швейной технологии и моды	ХАЙЗЫОНГ		[{"date": "2019-02-28 11:49:5", "user": "209", "prev_value": {"reg_date": "2018-03-23", "departure_date": "2019-01-15"}}]	1969-05-25	2018-02-05	2028-02-05	\N	\N	2018-05-10	2018-05-18	2019-05-17	\N	\N	2007-09-04	2018-05-15	2018-05-19	2019-05-17	2017-10-22	2017-10-22	2018-05-18	\N	232	23	0	1	4	4	0	2	0	\N	\N
32	B5629081	НГУЕН	ХЫУ ТХАНГ	232	6	[3, 5, 2]	MALE							1800002721	202408134	003125234/LDNDXH-DN	MULTI	WORK	12	1233625	4618	7883754		NGUYEN	HUU THANG		шереметьево 715	ИММИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ХАНОЙ		[{"date": "2019-02-28 11:45:35", "user": "209", "prev_value": {"reg_date": "2018-04-04", "departure_date": "2019-01-15"}}, {"date": "2019-03-23 17:49:49", "user": "207", "prev_value": {"fired_date": "-0001-11-30"}}]	1968-04-04	2011-08-05	2021-08-05	\N	\N	2018-05-10	2018-05-18	2019-05-17	\N	\N	2010-06-02	2018-05-15	2018-05-19	2019-05-17	2018-04-02	2018-04-02	2018-05-18	\N	232	23	0	1	4	4	0	2	0	\N	\N
33	B4610274	ДАНГ	ВАН КЕ	232	6	[3, 5, 2]	MALE							1700002622	202408131	015945356			12	0972032	4616	8385697		DANG	VAN KE		Шереметьево 675	ИММИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Намдиньское промышленное текстильно-швейное ПТУ	ХАНОЙ		[{"date": "2018-05-11 12:8:53", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30", "passport_number": "В4610274", "migr_card_issued_date": "2020-07-20"}}, {"date": "2018-05-17 18:45:12", "user": "207", "prev_value": {"status_id": "FURLOUGH"}}]	1989-12-23	2010-11-05	2020-11-05	\N	\N	2017-05-12	2017-05-19	2018-05-18	\N	\N	2009-07-07	2017-05-15	2017-05-20	2018-05-18	2016-07-20	2020-07-20	2017-05-18	\N	232	2	0	1	4	4	0	2	0	\N	\N
34	B7676506	НГУЕН	ТХИ БИНЬ	232	6	[2, 3, 4]	FEMALE						69	1800002707	202408126	003125548/LDTBXH-DN	MULTI	WORK	12	1233624	4616	8510538		NGUYEN	THI BINH		Шереметьево 678	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ХЫНГИЕН		[{"date": "2018-05-17 12:54:54", "user": "209", "prev_value": {"visa_number": "0972038", "passport_number": "В7676506", "visa_issued_date": "2017-05-15", "visa_expired_date": "2018-05-18", "visa_started_date": "2017-05-20", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30"}}, {"date": "2019-05-06 18:42:28", "user": "214", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-05-07 12:40:33", "user": "209", "prev_value": {"reg_date": "2018-03-23", "departure_date": "2019-05-15"}}, {"date": "2019-05-07 14:4:18", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-05-07 14:4:44", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "work_permit_serie": ""}}]	1986-01-01	2013-03-25	2023-03-25	\N	\N	2018-05-10	2018-05-18	2019-05-17	\N	\N	2011-06-01	2018-05-15	2018-05-19	2019-05-17	2016-08-03	2016-08-03	2018-05-18	\N	232	23	0	1	2	2	0	2	0	\N	\N
36	N1798597	НГУЕН	ТХАНЬ ЛИЕМ	232	6	[3, 2, 4]	MALE						69	1900002411	202400380	003124936/LDTBXH-DN	MULTI	WORK	12	1349979	4618	8368689		NGUYEN	THANH LIEM		шереметьево 715	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	БАКЖАНГ		[{"date": "2019-02-18 12:19:7", "user": "209", "prev_value": {"reg_date": "2018-07-13"}}, {"date": "2020-01-09 12:36:56", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}, {"date": "2020-01-09 12:37:11", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}]	1982-04-24	2016-12-22	2026-12-22	\N	\N	2019-02-04	2019-02-18	2020-02-17	\N	\N	2010-06-30	2019-02-13	2019-02-19	2020-02-17	2018-05-11	2018-05-11	2019-02-15	\N	232	32	0	4	2	2	0	2	0	\N	\N
37	C0987699	ДАНГ	ВАН ХУНГ	232	6	[3, 2, 4]	MALE						69	1900002429	202401052		MULTI	WORK	12	1349982	4618	9661324		DANG	VAN HUNG		Шереметьево 870	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАНОЙ		[{"date": "2019-02-18 12:9:16", "user": "209", "prev_value": {"reg_date": "2018-08-15"}}, {"date": "2019-11-20 16:12:24", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2020-01-09 12:23:59", "user": "209", "prev_value": {"status_id": "FURLOUGH", "current_passport_number": ""}}, {"date": "2020-01-09 12:24:21", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}]	1993-01-10	2015-10-02	2025-10-02	\N	\N	2019-02-04	2019-02-18	2020-02-17	\N	\N	\N	2019-02-13	2019-02-19	2020-02-17	2018-08-10	2018-08-10	2019-02-15	\N	232	32	0	4	2	2	0	2	0	\N	\N
38	B4596711	НГУЕН	ТХИ ХОНГ	232	6	[3, 5, 2]	FEMALE							1800002714	202408128		MULTI	WORK	12	1233629	4616	8431883		NGUYEN	THI HONG		шереметьево 627	ИММИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хайзыонгский профессиональный колледж	Тхайбинь		[{"date": "2019-01-09 11:47:48", "user": "209", "prev_value": {"fired_date": "2019-01-05"}}]	1989-08-11	2010-10-14	2020-10-14	\N	\N	2018-05-10	2018-05-18	2019-01-10	\N	\N	\N	2018-05-15	2018-05-19	2019-01-10	2016-07-20	2016-07-20	2017-11-17	\N	232	18	0	1	4	4	0	2	0	\N	\N
39	B7816894	ФАМ	ВАН ЫОК	232	6	[3, 4, 2]	MALE						69	1800002746	202408130	003125553/LDTBXH-DN	MULTI	WORK	12	1233628	4616	8510537		PHAM 	VAN UOC		Шереметьево 678	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ХАЙЗЫОНГ		[{"date": "2019-01-28 11:8:53", "user": "209", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-03-12 12:30:33", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-03-12 12:30:52", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "work_permit_serie": ""}}]	1994-05-07	2013-04-09	2023-04-09	\N	\N	2018-05-10	2018-05-18	2019-05-17	\N	\N	2011-06-01	2018-05-15	2018-05-19	2019-05-17	2016-08-03	2016-08-03	2018-03-23	2019-01-29	232	23	0	1	2	2	0	2	0	\N	\N
40	B7677386	ФАМ	ТХИ ХАУ	232	6	[2, 3, 4]	FEMALE							1800002753	202408129	003125547/LDTBXH-DN	MULTI	WORK	12	1233627	4616	8510536		PHAM	THI HAU		Шереметьево 678	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ХЫНГИЕН		[{"date": "2018-05-17 13:18:43", "user": "209", "prev_value": {"visa_number": "0972034", "passport_number": "В7677386", "visa_issued_date": "2017-05-15", "visa_expired_date": "2018-05-18", "visa_started_date": "2017-05-20", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30"}}, {"date": "2019-04-26 9:55:33", "user": "214", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-04-29 11:48:56", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-04-29 11:49:16", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1991-01-20	2013-03-20	2023-03-20	\N	\N	2018-05-10	2018-05-18	2019-05-17	\N	\N	2011-06-01	2018-05-15	2018-05-19	2019-05-17	2016-08-03	2016-08-03	2018-03-23	2019-04-26	232	23	0	1	2	2	0	2	0	\N	\N
41	C2403752	НГУЕН	ТХИ ТХУ ХАНГ	232	6	[3, 2, 4]	FEMALE						69	1900003655	202401878	003124911/LDNDXH-DN	MULTI	WORK	12	1560696	4617	9015358		NGUYEN	THI THU HANG		Шереметьево 695	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ТУЕНКУАНГ		[{"date": "2018-06-19 11:35:10", "user": "209", "prev_value": {"reg_date": "2017-12-20", "visa_number": "1017905", "visa_issued_date": "2017-12-07", "visa_expired_date": "2018-06-24", "visa_started_date": "2017-12-07", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-05-20 11:55:54", "user": "209", "prev_value": {"employ_permit_id": "24", "work_permit_serie": "", "work_permit_number": "1800002961", "work_permit_issued_date": "2018-06-04", "work_permit_expired_date": "2019-06-23", "work_permit_started_date": "2018-06-24"}}, {"date": "2019-06-21 10:41:54", "user": "209", "prev_value": {"hired_date": "2018-06-24", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30"}}, {"date": "2019-06-21 10:44:39", "user": "209", "prev_value": {"visa_number": "1348078", "visa_issued_date": "2018-06-13", "visa_expired_date": "2019-06-23", "visa_started_date": "2018-06-25"}}, {"date": "2020-01-09 12:52:47", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}, {"date": "2020-01-09 12:53:3", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-09 12:53:45", "user": "209", "prev_value": {"reg_date": "2018-06-19", "current_passport_number": ""}}]	1974-09-20	2016-11-29	2026-11-29	\N	\N	2019-06-10	2019-06-23	2020-03-25	\N	\N	2010-06-30	2019-06-11	2019-06-24	2020-03-25	2017-11-07	2017-11-07	2019-06-21	\N	232	33	0	1	2	2	0	2	0	\N	\N
42	B9577191	ЛЕ	ТХАНЬ ТУ	232	6	[3, 4, 2]	MALE							1700003986	202401595	00088841			12	1017866	4617	8887049		LE	THANH TU		Шереметьево 564	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	ТХАНЬХОА		[{"date": "2018-06-25 13:16:11", "user": "209", "prev_value": {"passport_issued_date": "2017-12-07", "passport_expired_date": "2027-12-07"}}]	1990-02-08	2014-09-11	2024-09-11	\N	\N	2017-08-23	2017-08-23	2018-06-24	\N	\N	2015-07-02	2017-12-07	2017-12-07	2018-06-24	2017-09-29	2017-09-29	2017-12-08	\N	232	4	0	1	2	2	0	2	0	\N	\N
43	N1902027	НГУЕН	БАО ШОН	232	6	[3, 5, 2]	MALE							1800002979	202401662	011472-MCN/LDTBXH-DN			12	1348080	4617	8955152		NGUYEN	BAO SON		шереметьево 785	ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ		ЧАСТНОЕ ПТУ "ЗУИТАН"	НГЕАН		[{"date": "2019-02-27 11:57:27", "user": "209", "prev_value": {"fired_date": "2018-06-04"}}]	1998-10-26	2018-03-27	2028-03-27	\N	\N	2018-06-04	2018-06-24	2019-06-23	\N	\N	2016-07-04	2018-06-13	2018-06-25	2019-06-23	2017-10-17	2017-10-17	2018-06-19	\N	232	24	0	1	4	4	0	2	0	\N	\N
44	C2871092	НГУЕН	АНЬ ТУАН	232	6	[3, 2, 5]	MALE						69	1900003662	202401663		MULTI	WORK	12	1560697	4618	7966490		NGUYEN	ANH TUAN		Шереметьево 825	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАНЬХОА		[{"date": "2018-06-19 11:13:50", "user": "209", "prev_value": {"visa_number": "1017845", "visa_issued_date": "2017-12-07", "visa_expired_date": "2018-06-24", "visa_started_date": "2017-12-07", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-05-20 11:28:42", "user": "209", "prev_value": {"occupation_id": "1", "employ_permit_id": "24", "work_permit_serie": ""}}, {"date": "2019-05-20 11:29:6", "user": "209", "prev_value": {"cert_issuer": "ЧАСТНОЕ ПТУ \\"ЗУИТАН\\"", "cert_number": "011477-MCN/LDTBXH-DN", "cert_issued_date": "2016-07-04"}}, {"date": "2019-05-20 11:29:56", "user": "209", "prev_value": {"reg_date": "2018-04-04"}}, {"date": "2019-05-20 11:54:35", "user": "209", "prev_value": {"work_permit_number": "1800002954", "work_permit_issued_date": "2018-06-04", "work_permit_expired_date": "2019-06-23", "work_permit_started_date": "2018-06-24"}}, {"date": "2019-05-20 11:54:56", "user": "209", "prev_value": {"visa_serie": "12", "visa_number": "1348079", "visa_issued_date": "2018-06-13", "visa_expired_date": "2019-06-23", "visa_started_date": "2018-06-25"}}, {"date": "2019-05-22 10:36:19", "user": "209", "prev_value": {"occupation_id": "6"}}, {"date": "2019-05-22 11:51:15", "user": "209", "prev_value": {"visa_serie": "", "visa_number": "", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2019-06-21 10:31:14", "user": "209", "prev_value": {"hired_date": "2018-06-24", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30"}}, {"date": "2019-06-21 10:33:32", "user": "209", "prev_value": {"visa_number": "1348079", "visa_issued_date": "2018-06-13", "visa_expired_date": "2019-06-23", "visa_started_date": "2018-06-25"}}, {"date": "2019-11-27 13:41:23", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}, {"date": "2019-11-28 16:48:10", "user": "209", "prev_value": {"reg_date": "2018-06-19"}}]	1998-10-23	2017-02-24	2027-02-24	\N	\N	2019-06-10	2019-06-23	2020-03-25	\N	\N	\N	2019-06-11	2019-06-24	2020-03-25	2018-04-02	2018-04-02	2019-06-21	\N	232	33	0	1	4	4	0	2	0	\N	\N
45	B8469009	ДО	ХЫУ ТАНГ	232	6	[3, 5, 2]	MALE							1700003432	202408761	00084375			12	0972420	4616	8757135		DO	HUU TANG		Шереметьево 800	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	ХЫНГИЕН		[{"date": "2018-06-29 11:43:20", "user": "209", "prev_value": {"reg_date": "2017-10-14"}}]	1984-07-18	2013-11-04	2023-11-04	\N	\N	2017-08-07	2017-08-16	2018-08-15	\N	\N	2009-07-02	2017-08-10	2017-08-16	2018-08-15	2016-10-01	2011-08-20	2017-08-15	\N	232	5	0	1	4	4	0	2	0	\N	\N
46	B3997686	НГУЕН	ТХИ ХУЕН ЧАНГ	232	6	[3, 4, 2]	FEMALE							1700003440	202408760	00084381 09/DHCNHN			12	0972421	4616	8715435		NGUYEN	THI HUYEN TRANG		шереметьево 742	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	БАКЗАНГ		[{"date": "2018-07-18 11:26:14", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30", "passport_number": "В3997686", "migr_card_issued_date": "2001-10-20"}}]	1984-06-11	2010-04-14	2020-04-14	\N	\N	2017-08-07	2017-08-16	2018-08-15	\N	\N	2009-07-02	2017-08-10	2017-08-16	2018-08-15	2016-10-01	2016-10-01	2017-08-15	\N	232	5	0	1	2	2	0	2	0	\N	\N
47	B6691088	ЛЫОНГ	ВАН ХАЙ	232	6	[2, 3, 4]	MALE						69	1800004084	202409040	0084392 09/DHCNHN	MULTI	WORK	12	1348731	4616	7848852		LUONG	VAN HAI		ДОМОДЕВО 464	ИММИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	ХЫНГИЕН		[{"date": "2018-10-05 10:52:5", "user": "209", "prev_value": {"work_permit_number": "1700004718", "migr_card_issued_date": "2010-11-20", "work_permit_issued_date": "2017-09-22", "work_permit_started_date": "2017-10-07"}}, {"date": "2019-04-26 9:56:4", "user": "214", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-04-29 11:40:8", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-04-29 11:40:38", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "departure_date": "2019-04-26"}}]	1984-09-02	2012-05-10	2022-05-10	\N	\N	2018-09-24	2018-10-06	2019-07-11	\N	\N	2009-07-02	2018-10-01	2018-10-07	2019-07-11	2016-11-10	2016-11-10	2017-10-06	\N	232	26	0	1	2	2	0	2	0	\N	\N
48	B8744969	ФАМ	ТХИ ЛИНЬ	232	6	[3, 4, 2]	FEMALE							1700004740	202409039	010312			12	0972964	4616	7848853		PHAM	THI LINH		Шереметьево 464	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хынгиенский промышленный колледж	ХЫНГИЕН		[{"date": "2018-05-18 15:1:17", "user": "209", "prev_value": {"migr_card_issued_date": "2010-11-20"}}]	1995-09-22	2014-01-10	2024-01-10	\N	\N	2017-09-22	2017-10-07	2018-10-06	\N	\N	2013-07-04	2017-10-04	2017-10-08	2018-10-06	2016-11-10	2016-11-10	2017-10-06	\N	232	6	0	1	2	2	0	2	0	\N	\N
49	B5659335	ЛЕ	ТХИ НАМ	232	6	[3, 4, 2]	FEMALE							1700004820	202409101	004102 10/CDNHD			12	1017177	4617	8836223		LE	THI NAM		шереметьево 631	ИММИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хынгиенский промышленный колледж	КУАНГНИНЬ		[{"date": "2018-06-29 11:48:40", "user": "209", "prev_value": {"reg_date": "2017-09-20"}}]	1992-06-15	2011-08-25	2021-08-25	\N	\N	2017-10-02	2017-10-19	2018-10-18	\N	\N	2010-07-02	2017-10-16	2017-10-20	2018-10-18	2017-09-19	2017-09-19	2017-10-18	\N	232	7	0	1	2	2	0	2	0	\N	\N
50	C0890341	ЛЕ	ВАН ТХАНГ	232	6	[3, 2, 4]	MALE						69	1900003790	202409098		MULTI	WORK	12	1560796	4618	9331686		LE	VAN THANG		Шереметьево 396	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХЫНГИЕН		[{"date": "2018-10-05 11:45:34", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "visa_number": "1017173", "visa_issued_date": "2017-10-16", "visa_expired_date": "2018-10-18", "visa_started_date": "2017-10-20", "work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": "2017-10-02", "work_permit_expired_date": "2018-10-18", "work_permit_started_date": "2017-10-19"}}, {"date": "2019-06-24 10:54:16", "user": "209", "prev_value": {"employ_permit_id": "26", "work_permit_number": "1800004077", "work_permit_issued_date": "2018-09-24", "work_permit_expired_date": "2019-07-11", "work_permit_started_date": "2018-10-18"}}, {"date": "2019-06-24 10:54:55", "user": "209", "prev_value": {"visa_number": "1348737", "visa_issued_date": "2018-10-01", "visa_expired_date": "2019-07-11", "visa_started_date": "2018-10-19"}}, {"date": "2019-07-10 12:37:56", "user": "209", "prev_value": {"hired_date": "2018-10-18", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 12:39:40", "user": "209", "prev_value": {"reg_date": "2017-10-18", "visa_number": "", "visa_issued_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2019-07-10 14:26:44", "user": "209", "prev_value": {"entry_date": "2016-11-10", "migr_card_serie": "4616", "migr_card_number": "7857485", "migr_card_issued_date": "2016-11-10"}}, {"date": "2019-12-06 13:13:24", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-12-06 13:13:48", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-12-06 13:14:18", "user": "209", "prev_value": {"reg_date": "2018-10-05"}}]	1994-08-23	2015-10-15	2025-10-15	\N	\N	2019-06-28	2019-07-11	2020-07-10	\N	\N	\N	2019-07-04	2019-07-12	2020-07-10	2018-07-10	2018-07-10	2019-07-10	\N	232	35	0	1	2	2	0	2	0	\N	\N
51	123456	Иванов	Иван	177	1	[2]	MALE	4811															Иванович					ОУФМС РФ по району Медведково			г. Урюпинск	1234321, г. Москва, ул. Хохлова, д. 1, кв. 2	[{"date": "2018-04-02 19:12:39", "user": "211", "prev_value": {"gender": "", "address": "", "whence_id": "", "birth_place": "", "whence_name": "", "citizenship_id": "", "reg_address_id": "", "passport_issuer": "", "real_address_id": "", "citizenship_name": "", "reg_address_name": "", "real_address_name": "", "passport_issued_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}]	1972-04-02	2012-04-10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	177	0	0	0	5	5	0	0	0	\N	\N
52	#2	Сергиенко	Дмитрий	0	9	[2]																	Владимирович										[{"date": "2018-04-02 22:38:35", "user": "211", "prev_value": {"whence_name": "", "citizenship_name": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2018-04-03 17:3:39", "user": "207", "prev_value": {"passport_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2018-04-03 22:49:28", "user": "207", "prev_value": {"current_value": "", "passport_number": "---- ------", "migr_card_issued_date": "-0001-11-30"}}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
54	U1234567	Рахмонов	Асламбек	229	11	[2]	MALE				1234/17			1700001602		00084373					4617	7877107	Кужугетович	Rakhmonov	Aslambek Kuzhugetovich		шереметьево 715	Иммиграциооный департамент	TEMPORARY_RESIDENT_LICENSE	Ташкентское ПТУ	Ташкент	Узбекистан, г.Ташкент, ул.Тамерлана, д.16, кв.108	[{"date": "2018-04-09 10:5:16", "user": "211", "prev_value": {"employ_permit_id": "21"}}, {"date": "2019-04-07 15:12:59", "user": "207", "prev_value": {"hired_date": "2018-03-05"}}]	1988-06-14	2017-07-25	2027-07-25	2017-05-12	1970-01-01	2018-03-25	2018-04-03	2019-04-02	\N	2017-06-15	2015-08-11	\N	\N	\N	2018-03-26	2018-03-26	2018-03-26	\N	229	0	7712345678	5	5	5	6	6	0	\N	\N
55	K4567891	Чен	Цао Цао	44	11	[2]	MALE							1700001621	12347890	 А111222	MULTI	WORK	12	0971715	4617	8351911		Chen	Xiao Xiao		Шереметьево 836	Посольством КНР в РФ		Пекинский колледж	Пекин	КНР, г. Пекин, пл. Тянаньминь, д. 10, кв. 20	[{"date": "2018-04-07 0:30:10", "user": "211", "prev_value": {"current_value": "", "reg_address_name": "г. Москва, Ленинский пр., д. 11, стр. 1, кв. 2", "real_address_name": "г. Москва, Ленинский пр., д. 11, стр. 1, кв. 2"}}]	1991-07-23	2010-10-07	2020-10-07	\N	\N	2017-06-17	2017-06-17	2018-06-02	\N	2017-06-27	2014-07-04	2017-06-17	2017-06-17	2018-06-02	2017-06-15	2017-06-15	2017-06-15	\N	44	22	773456789	5	5	5	0	6	0	\N	\N
58	N2345678	НГУЕН	ТХИ ТЕО	232	10	[2]	FEMALE							770001234567										NGUYEN	THI TEO			Иммиграционный департамент			Бакзянг	Бакзянг, Дыкхю, Камжанг, д. 16	[{"date": "2019-02-12 11:45:34", "user": "211", "prev_value": {"passport_issuer": "Иммиграциооный департамент"}}, {"date": "2019-11-11 22:33:39", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 22:36:54", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 22:39:18", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 22:40:32", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 22:42:30", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 22:58:38", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 22:58:45", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 22:59:10", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 22:59:23", "user": "207", "prev_value": {"hired_date": "-0001-11-30"}}, {"date": "2019-11-11 22:59:29", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 23:2:30", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 23:2:36", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 23:3:49", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 23:3:53", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 23:4:43", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 23:4:47", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 23:6:41", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 23:6:46", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 23:9:31", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 23:9:36", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 23:11:53", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 23:11:57", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-12 0:2:56", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-12 0:4:11", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-12 0:8:27", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-12 8:4:31", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-12 8:22:16", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-12 8:22:23", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-12 8:29:59", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-12 8:30:5", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-12 8:33:44", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-12 8:33:49", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-12 8:35:27", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-12 8:35:32", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-12 8:45:6", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-12 8:45:12", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-12 8:45:17", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-12-23 15:4:1", "user": "211", "prev_value": {"occupation_id": "", "work_address_id": "", "current_passport_number": ""}}]	1990-06-22	2018-02-16	2028-02-16	\N	\N	2018-07-06	2018-09-06	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	21	0	0	6	0	0	6	0	\N	\N
59	C4755275	ДО	ВАН ЧУНГ	232	6	[3, 2, 5]	MALE						69	1900002404	202401546		MULTI	WORK	12	1349980	4618	9899484		DO	VAN TRUNG		Шереметьево 584	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАНЬХОА		[{"date": "2019-02-18 12:16:36", "user": "209", "prev_value": {"reg_date": "2018-11-30"}}, {"date": "2019-11-29 12:46:37", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}]	1997-01-25	2018-03-09	2028-03-09	\N	\N	2019-02-04	2019-02-18	2020-02-17	\N	\N	\N	2019-02-13	2019-02-19	2020-02-17	2018-10-21	2018-10-21	2019-02-15	\N	232	32	0	4	4	4	0	2	0	\N	\N
60	C3047553	ЧЫОНГ	ТХИ ДАМ	232	2	[3, 4, 2]	FEMALE																	TRUONG	THI DAM			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			КАМАУ		[{"date": "2018-08-08 11:47:2", "user": "209", "prev_value": {"status_id": "BUSINESS_VISA"}}]	1984-02-12	2017-05-11	2027-05-11	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	25	0	4	2	2	0	0	0	\N	\N
61	N1462430	ЛЕ 	СУАН АНЬ	232	11	[213]	MALE																	LE	XUAN ANX			ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ			ВЬЕТНАМ, ХАНОЙ	ВЬЕТНАМ, Г. ХАНОЙ, РАЙОН ТХАНЬ СУАН БАК, УЛ. НГУЕН КВИ ДЫК, ДОМ Б6	[{"date": "2018-04-13 0:8:38", "user": "207", "prev_value": []}, {"date": "2018-04-13 0:11:27", "user": "207", "prev_value": []}]	1985-01-20	2012-04-11	2022-04-11	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	0	0	0	0	0	0	0	0	\N	\N
62	C2395562	ЛИ	ШИНЬ ХОАН АНЬ	232	6	[3, 4, 2]	MALE							1800001051					12	1107640	4617	8887179		LI	SINH HOAN ANH			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ИЕНБАЙ		[{"date": "2018-04-23 16:12:25", "user": "209", "prev_value": {"status_id": "WORKER", "passport_number": "С2395562"}}, {"date": "2018-05-17 18:44:31", "user": "207", "prev_value": {"status_id": "FURLOUGH"}}]	1998-05-12	2016-11-22	2026-11-22	\N	\N	2018-01-11	2018-01-11	2019-01-10	\N	\N	\N	2018-01-10	2018-01-12	2019-01-10	2017-10-02	2017-10-02	2018-01-12	\N	232	8	0	1	2	2	0	2	0	\N	\N
63	C0941862	НГУЕН	ХОАНГ СУАН БАК	232	6	[2, 3, 4]	MALE						69	1800004101	202409103	004413 14/CDNHD	MULTI	WORK	12	1348738	4616	7834654		NGUYEN	HOANG XUAN BAC		Шереметьево 387	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хайзыонгский промышленный  колледж	НГЕАН		[{"date": "2018-10-05 12:50:15", "user": "209", "prev_value": {"visa_number": "1017174", "visa_issued_date": "2017-10-16", "visa_expired_date": "2018-10-18", "visa_started_date": "2017-10-20"}}, {"date": "2019-06-03 12:5:13", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-06-03 12:6:7", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1997-06-18	2015-09-23	2025-09-23	\N	\N	2018-09-24	2018-10-18	2019-07-11	\N	\N	2014-07-03	2018-10-01	2018-10-19	2019-07-11	2016-11-10	2016-11-10	2017-10-18	\N	232	26	0	1	2	2	0	2	0	\N	\N
64	C2117471	ХОАНГ	ВАН ЗИЕН	232	6	[3, 2, 4]	MALE						69	1900003800	202409102	00084808 15/DHCNHN	MULTI	WORK	12	1560795	4616	7849834		HOANG	VAN DIEN		шереметьево 715	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	БАККАН		[{"date": "2018-10-05 11:33:13", "user": "209", "prev_value": {"hired_date": "2017-10-19", "visa_number": "1017176", "visa_issued_date": "2017-10-16", "visa_expired_date": "2018-10-18", "visa_started_date": "2017-10-20", "work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": "2017-10-02", "work_permit_expired_date": "2018-10-18", "work_permit_started_date": "2017-10-19"}}, {"date": "2019-06-24 10:58:8", "user": "209", "prev_value": {"hired_date": "2018-10-18", "employ_permit_id": "26", "work_permit_number": "1800004119", "work_permit_issued_date": "2018-09-24", "work_permit_expired_date": "2019-07-11", "work_permit_started_date": "2018-10-18"}}, {"date": "2019-07-10 13:48:5", "user": "209", "prev_value": {"work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 13:49:29", "user": "209", "prev_value": {"reg_date": "2017-10-18", "visa_number": "1348739", "visa_issued_date": "2018-10-01", "visa_expired_date": "2019-07-11", "visa_started_date": "2018-10-19"}}, {"date": "2019-08-29 11:50:57", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-08-29 11:51:33", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-08-29 11:53:18", "user": "209", "prev_value": {"reg_date": "2018-10-05"}}]	1992-06-06	2016-08-01	2026-08-01	\N	\N	2019-06-28	2019-07-11	2020-07-10	\N	\N	2015-07-02	2019-07-04	2019-07-12	2020-07-10	2016-11-10	2016-11-10	2019-07-10	\N	232	35	0	1	2	2	0	2	0	\N	\N
71	N2363986	НГУЕН	НГОК ХЫНГ	232	6	[3, 2, 4]	MALE						69	2100006257	202409498	004117	MULTI	WORK	12	2030557	4616	8960559		NGUYEN	NGOC HUNG		Шереметьево 576	ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ		Хайзыонгский профессиональный колледж	ТАЙНИНЬ		[{"date": "2018-11-15 13:32:8", "user": "209", "prev_value": {"reg_date": "2017-11-29", "visa_number": "1017663", "visa_issued_date": "2017-11-24", "visa_expired_date": "2018-11-28", "visa_started_date": "2017-11-30"}}, {"date": "2019-11-26 12:29:12", "user": "209", "prev_value": {"occupation_id": "6", "employ_permit_id": "27", "work_permit_number": "1800004782", "work_permit_issued_date": "2018-11-01", "work_permit_expired_date": "2019-11-27", "work_permit_started_date": "2018-11-28"}}, {"date": "2019-11-26 12:30:15", "user": "209", "prev_value": {"visa_serie": "12", "visa_number": "1349192", "visa_issued_date": "2018-11-06", "visa_expired_date": "2019-11-27", "visa_started_date": "2018-11-29"}}, {"date": "2019-11-28 17:21:50", "user": "209", "prev_value": {"hired_date": "2018-11-28"}}, {"date": "2019-11-28 17:22:4", "user": "209", "prev_value": {"reg_date": "2018-11-20"}}, {"date": "2020-11-16 17:24:48", "user": "209", "prev_value": {"hired_date": "2019-11-27", "employ_permit_id": "41", "work_permit_number": "1900004747", "work_permit_issued_date": "2019-11-12", "work_permit_expired_date": "2020-11-26", "work_permit_started_date": "2019-11-27"}}, {"date": "2020-11-16 17:26:10", "user": "209", "prev_value": {"visa_serie": "13", "visa_number": "0053856", "visa_issued_date": "2019-11-13", "visa_expired_date": "2020-11-26", "visa_started_date": "2019-11-28"}}, {"date": "2020-11-16 17:26:57", "user": "209", "prev_value": {"reg_date": "2019-11-26"}}, {"date": "2020-11-19 12:43:15", "user": "209", "prev_value": {"reg_date": null}}, {"date": "2021-09-28 12:45:25", "user": "209", "prev_value": {"birth_place": "ТЭИНИНЬ", "passport_issuer": "ИММИГРАЦИОННЫЙ ДЕПАРТАМЕНТ", "passport_number": "B7664229", "passport_issued_date": "2013-02-19", "passport_expired_date": "2023-02-19"}}, {"date": "2021-09-28 12:45:50", "user": "209", "prev_value": {"occupation_id": "2"}}, {"date": "2021-09-28 12:48:47", "user": "209", "prev_value": {"passport_number": "N 2363986"}}, {"date": "2021-11-16 9:53:6", "user": "209", "prev_value": {"employ_permit_id": "52", "work_permit_number": "2000004993", "work_permit_issued_date": "2020-10-21", "work_permit_expired_date": "2021-11-25", "work_permit_started_date": "2020-11-26"}}, {"date": "2021-11-16 9:54:30", "user": "209", "prev_value": {"reg_date": "2020-11-18", "visa_number": "1771269", "visa_issued_date": "2020-11-03", "visa_expired_date": "2021-11-25", "visa_started_date": "2020-11-27"}}, {"date": "2021-12-20 17:37:8", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1991-01-08	2021-09-17	2031-09-17	\N	\N	2021-10-28	2021-11-25	2022-11-24	\N	\N	2010-07-02	2021-11-09	2021-11-26	2022-11-24	2016-12-31	2016-12-31	2021-11-16	\N	232	61	0	1	2	2	0	2	0	\N	\N
65	C1067572	НГУЕН	ТУАН ТУ	232	6	[3, 2, 4]	MALE						69	1900003831	202409100	004415 14/CDNHD	MULTI	WORK	12	1560794	4616	7847062		NGUYEN	TUAN TU		Шереметьево 412	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хайзыонгский промышленный колледж	ХАНОЙ		[{"date": "2018-10-05 11:29:22", "user": "209", "prev_value": {"hired_date": "2017-10-19"}}, {"date": "2019-06-24 10:55:50", "user": "209", "prev_value": {"employ_permit_id": "26", "work_permit_number": "1800004091", "work_permit_issued_date": "2018-09-24", "work_permit_expired_date": "2019-07-11", "work_permit_started_date": "2018-10-18"}}, {"date": "2019-06-24 10:56:7", "user": "209", "prev_value": {"visa_number": "1348740", "visa_issued_date": "2018-10-01", "visa_expired_date": "2019-07-11", "visa_started_date": "2018-10-19"}}, {"date": "2019-07-10 13:1:38", "user": "209", "prev_value": {"hired_date": "2018-10-18", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 13:2:41", "user": "209", "prev_value": {"reg_date": "2017-10-18", "visa_number": "", "visa_issued_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2019-10-16 12:2:21", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-10-16 12:2:41", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-10-16 12:3:44", "user": "209", "prev_value": {"reg_date": "2018-10-05"}}]	1997-09-18	2015-11-25	2025-11-25	\N	\N	2019-06-28	2019-07-11	2020-07-10	\N	\N	2014-07-03	2019-07-04	2019-07-11	2020-07-10	2016-11-10	2016-11-10	2019-07-10	\N	232	35	0	1	2	2	0	2	0	\N	\N
66	C2224003	ФАМ	ВАН БАК	232	6	[3, 2, 5]	MALE						69	1800004800	202409493	00084422	MULTI	WORK	12	1349195	4616	8960552		PHAM 	VAN BAC		Шереметьево 576	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	Тхайбинь		[{"date": "2018-11-15 13:49:51", "user": "209", "prev_value": {"reg_date": "2017-11-29", "visa_number": "1017656", "visa_issued_date": "2017-11-24", "visa_expired_date": "2018-11-28", "visa_started_date": "2017-11-30"}}, {"date": "2019-11-25 13:17:42", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}]	1988-04-26	2016-08-22	2026-08-22	\N	\N	2018-11-01	2018-11-28	2019-11-27	\N	\N	2010-07-02	2018-11-06	2018-11-29	2019-11-27	2016-12-31	2016-12-31	2018-11-20	\N	232	27	0	1	4	4	0	2	0	\N	\N
67	B8915840	ВУ	ТХИ ХОНГ ИЕН	232	6	[3, 4, 2]	FEMALE							1700005214	202409487	007916			12	1017659	4616	8989113		VU	THI HONG YEN		шереметьево 627	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хынгиенский промышленный колледж	ХАНОЙ		[{"date": "2019-02-27 11:56:30", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1989-01-18	2014-02-25	2024-02-25	\N	\N	2017-11-20	2017-11-29	2018-11-28	\N	\N	2009-07-02	2017-11-24	2017-11-30	2018-11-28	2016-12-31	2016-12-31	2017-11-29	\N	232	9	0	1	2	2	0	2	0	\N	\N
68	C2224813	ДИНЬ	ТХУ ЧАНГ	232	6	[3, 2, 4]	FEMALE						69	1900004730	202409486	00084375	MULTI	WORK	13	0053855	4619	7541468		DINH 	THU TRANG		Шереметьево 584	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	ТУЕНКУАНГ		[{"date": "2018-11-19 11:43:9", "user": "209", "prev_value": {"visa_number": "1017658", "visa_issued_date": "2017-11-24", "visa_expired_date": "2018-11-28", "visa_started_date": "2017-11-30"}}, {"date": "2019-09-27 11:26:48", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-10-14 11:20:10", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-10-14 11:25:48", "user": "209", "prev_value": {"reg_date": "2017-11-29", "entry_date": "2016-12-31", "migr_card_serie": "4616", "entry_checkpoint": "Шереметьево 576", "migr_card_number": "8960551", "migr_card_issued_date": "2016-12-31"}}, {"date": "2019-11-26 12:23:50", "user": "209", "prev_value": {"occupation_id": "10", "employ_permit_id": "27", "work_permit_number": "1800004768", "work_permit_issued_date": "2018-11-01", "work_permit_expired_date": "2019-11-27", "work_permit_started_date": "2018-11-28"}}, {"date": "2019-11-26 12:25:7", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "visa_serie": "12", "visa_number": "1349199", "visa_issued_date": "2018-11-06", "visa_expired_date": "2019-11-27", "visa_started_date": "2018-11-29"}}, {"date": "2019-11-28 17:14:9", "user": "209", "prev_value": {"reg_date": "2019-10-15"}}, {"date": "2020-03-10 11:28:31", "user": "209", "prev_value": {"departure_date": null, "work_permit_paid_till_date": null}}, {"date": "2020-03-11 11:13:56", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2020-04-07 11:13:30", "user": "209", "prev_value": {"status_id": "FURLOUGH", "fired_date": null}}]	1985-11-21	2016-08-25	2026-08-25	\N	\N	2019-11-12	2019-11-27	2020-11-26	\N	\N	2009-07-02	2019-11-13	2019-11-28	2020-11-26	2019-10-12	2019-10-12	2019-11-26	2020-03-10	232	41	0	1	2	2	0	2	0	\N	\N
69	C2176899	ЧАН	ТХИ НЯН	232	6	[3, 2, 4]	FEMALE						69	2000005010	202409484	00084381	MULTI	WORK	12	1771268	4616	8960550		TRAN 	THI NHAN		Шереметьево 576	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	БАКЖАНГ		[{"date": "2018-11-15 14:25:13", "user": "209", "prev_value": {"reg_date": "2017-11-29", "hired_date": "2017-11-29", "visa_number": "1017662", "visa_issued_date": "2017-11-24", "visa_expired_date": "2018-11-28", "visa_started_date": "2017-11-30"}}, {"date": "2019-11-26 12:45:14", "user": "209", "prev_value": {"occupation_id": "13", "employ_permit_id": "27", "work_permit_number": "1800004824", "work_permit_issued_date": "2018-11-01", "work_permit_expired_date": "2019-11-27", "work_permit_started_date": "2018-11-28"}}, {"date": "2019-11-26 12:46:18", "user": "209", "prev_value": {"visa_serie": "12", "visa_number": "1349194", "visa_issued_date": "2018-11-06", "visa_expired_date": "2019-11-27", "visa_started_date": "2018-11-29"}}, {"date": "2019-11-28 17:52:32", "user": "209", "prev_value": {"hired_date": "2018-11-28"}}, {"date": "2019-11-28 17:52:56", "user": "209", "prev_value": {"reg_date": "2018-11-20"}}, {"date": "2020-11-16 17:9:19", "user": "209", "prev_value": {"employ_permit_id": "41", "work_permit_number": "1900004722"}}, {"date": "2020-11-16 17:12:26", "user": "209", "prev_value": {"hired_date": "2019-11-27", "work_permit_issued_date": "2019-11-12", "work_permit_expired_date": "2020-11-26", "work_permit_started_date": "2019-11-27"}}, {"date": "2020-11-16 17:13:21", "user": "209", "prev_value": {"work_permit_issued_date": "2020-10-21"}}, {"date": "2020-11-16 17:14:31", "user": "209", "prev_value": {"work_permit_issued_date": "2020-10-20"}}, {"date": "2020-11-16 17:15:56", "user": "209", "prev_value": {"visa_serie": "13", "visa_number": "0053854", "visa_issued_date": "2019-11-13", "visa_expired_date": "2020-11-26", "visa_started_date": "2019-11-28"}}, {"date": "2020-11-16 17:16:46", "user": "209", "prev_value": {"reg_date": "2019-11-26"}}, {"date": "2020-11-19 12:37:6", "user": "209", "prev_value": {"reg_date": null}}, {"date": "2020-11-19 12:37:48", "user": "209", "prev_value": {"reg_date": "2020-11-19"}}, {"date": "2021-04-12 13:23:55", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1980-10-24	2016-08-18	2026-08-18	\N	\N	2020-10-21	2020-11-26	2021-11-25	\N	\N	2009-07-02	2020-11-03	2020-11-27	2021-11-25	2016-12-31	2016-12-31	2020-11-18	\N	232	52	0	1	2	2	0	2	0	\N	\N
70	B6078375	ФАМ	ВАН ЗУЕТ	232	6	[3, 2, 4]	MALE						69	1800004817	202409482	004124	MULTI	WORK	12	1349196	4619	6690359		PHAM	VAN DUYET		шереметьево 129	ИММИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хайзыонгский профессиональный колледж	ХАНОЙ		[{"date": "2018-11-15 14:17:56", "user": "209", "prev_value": {"reg_date": "2018-06-26", "visa_number": "1017664", "visa_issued_date": "2017-11-24", "visa_expired_date": "2018-11-28", "visa_started_date": "2017-11-30"}}, {"date": "2019-03-12 22:45:14", "user": "214", "prev_value": {"reg_date": "2018-11-20", "birth_date": "1992-10-13", "entry_date": "2018-06-24", "hired_date": "2018-11-28", "departure_date": "-0001-11-30", "cert_issued_date": "2010-07-02", "visa_issued_date": "2018-11-06", "visa_expired_date": "2019-11-27", "visa_started_date": "2018-11-29", "passport_issued_date": "2012-03-20", "migr_card_issued_date": "2018-06-24", "passport_expired_date": "2022-03-20", "work_permit_issued_date": "2018-11-01", "work_permit_expired_date": "2019-11-27", "work_permit_started_date": "2018-11-28"}}, {"date": "2019-03-13 13:34:50", "user": "207", "prev_value": {"reg_date": "-0001-11-30", "birth_date": "-0001-11-30", "entry_date": "-0001-11-30", "hired_date": "-0001-11-30", "cert_issued_date": "-0001-11-30", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_started_date": "-0001-11-30", "passport_issued_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30", "passport_expired_date": "-0001-11-30", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-13 13:38:57", "user": "207", "prev_value": {"reg_date": "2026-05-11", "birth_date": "2019-03-15", "entry_date": "2029-12-09", "hired_date": "2034-05-11", "cert_issued_date": "2007-12-31", "visa_issued_date": "2012-05-10", "visa_expired_date": "2033-05-11", "visa_started_date": "2035-05-11", "passport_issued_date": "2025-09-02", "migr_card_issued_date": "2029-12-09", "passport_expired_date": "2025-09-12", "work_permit_issued_date": "2007-05-11", "work_permit_expired_date": "2033-05-11", "work_permit_started_date": "2034-05-11"}}, {"date": "2019-03-13 13:46:14", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-05-07 14:53:36", "user": "209", "prev_value": {"status_id": "FURLOUGH", "entry_date": "2018-04-26", "departure_date": "2019-03-13", "migr_card_serie": "4618", "entry_checkpoint": "Шереметьево 566", "migr_card_number": "9275397", "migr_card_issued_date": "2018-04-26"}}, {"date": "2019-05-07 15:16:48", "user": "209", "prev_value": {"visa_issued_date": "2019-03-13"}}, {"date": "2019-05-21 14:36:56", "user": "207", "prev_value": {"entry_date": "2019-05-06"}}, {"date": "2019-05-21 14:37:14", "user": "207", "prev_value": {"entry_date": "2019-05-05"}}, {"date": "2019-10-14 10:51:8", "user": "209", "prev_value": {"passport_issuer": "МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ"}}, {"date": "2019-11-11 13:8:46", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-11 13:9:34", "user": "209", "prev_value": {"reg_date": "2018-11-20"}}, {"date": "2019-11-11 13:45:2", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1992-10-13	2012-03-20	2022-03-20	\N	\N	2018-11-01	2018-11-28	2019-11-27	\N	\N	2010-07-02	2018-11-06	2018-11-29	2019-11-27	2019-05-06	2019-05-06	2019-05-07	\N	232	27	0	1	2	2	0	2	0	\N	\N
72	B8761869	ДАНГ	ТХАНЬ НАМ	232	6	[3, 2, 5]	MALE						69	1800004750	202409494	004511	MULTI	WORK	12	1349198	4617	7797777		DANG	THANH NAM		шереметьево 627	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хайзыонгский профессиональный колледж	Тхайбинь		[{"date": "2018-11-15 13:0:58", "user": "209", "prev_value": {"reg_date": "2017-11-29"}}, {"date": "2019-11-14 13:52:11", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-14 13:52:50", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1996-05-10	2014-02-17	2024-02-17	\N	\N	2018-11-01	2018-11-28	2019-11-27	\N	\N	2014-07-02	2018-11-06	2018-11-29	2019-11-27	2017-01-31	2017-01-31	2018-11-20	\N	232	27	0	1	4	4	0	2	0	\N	\N
73	B9257917	ХОАНГ	ТХИ ИЭН	232	6	[3, 4, 2]	FEMALE							1700005341	202409483	007685			12	1017665	4617	7797760		HOANG	THI YEN		шереметьево 627	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хынгиенский промышленный колледж	БАКЖАНГ		[{"date": "2018-06-29 11:24:47", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "status_id": "FURLOUGH", "migr_card_issued_date": "-0001-11-30"}}]	1984-03-10	2014-05-26	2024-05-26	\N	\N	2017-11-20	2017-11-29	2018-11-28	\N	\N	2006-07-04	2017-11-24	2017-11-30	2018-11-28	2017-01-31	2017-01-31	2017-11-29	\N	232	9	0	1	2	2	0	2	0	\N	\N
74	B7153398	ХОАНГ	СУАН ЗУНГ	232	6	[2, 3, 4]	MALE						69	1800004983	202409660	007988 13/CDKTHY	MULTI	WORK	12	1349531	2806	0000678		HOANG	XUAN DUNG		Шереметьево 584	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хынгиенский промышленный колледж	ХАНОЙ		[{"date": "2019-01-25 13:57:12", "user": "209", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-04-22 11:33:22", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-04-22 11:34:13", "user": "209", "prev_value": {"departure_date": "2019-01-25"}}, {"date": "2019-04-22 11:34:54", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1993-08-20	2012-09-05	2022-09-05	\N	\N	2018-11-27	2018-12-07	2019-12-06	\N	\N	2013-07-03	2018-11-28	2018-12-08	2019-12-06	2017-03-25	2017-03-25	2018-12-07	\N	232	28	0	1	2	2	0	2	0	\N	\N
75	B7608906	ХОАНГ	ВАН КХОЙ	232	6	[3, 4, 2]	MALE						69	1800005017	202409659	007985 13/CDKTHY	MULTI	WORK	12	1017729	4617	7943515		HOANG	VAN KHOI		Шереметьево 817	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хынгиенский промышленный колледж	НГЕАН		[{"date": "2018-12-03 14:26:5", "user": "209", "prev_value": {"status_id": "FURLOUGH", "fired_date": "-0001-11-30"}}]	1993-05-05	2013-03-15	2023-03-15	\N	\N	2018-11-27	2018-12-07	2019-12-06	\N	\N	\N	2017-11-28	2017-12-08	2018-12-07	2017-02-24	2017-02-24	\N	2018-10-14	232	28	0	1	2	2	0	2	0	\N	\N
76	C2432026	ХОАНГ	ВАН ТИЕН	232	6	[3, 2, 4]	MALE						69	1900004779	202409656	008274 14/CDKTHY	MULTI	WORK	13	0053857	4617	7929503		HOANG	VAN TIEN		Шереметьево 801	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хынгиенский промышленный колледж	НГЕАН		[{"date": "2018-12-07 13:24:36", "user": "209", "prev_value": {"visa_number": "13495632"}}, {"date": "2019-11-26 11:59:42", "user": "209", "prev_value": {"employ_permit_id": "28", "work_permit_number": "1800005024", "work_permit_issued_date": "2018-11-27", "work_permit_expired_date": "2019-12-06", "work_permit_started_date": "2018-12-07"}}, {"date": "2019-11-26 12:0:53", "user": "209", "prev_value": {"visa_serie": "12", "visa_number": "1349532", "visa_issued_date": "2018-11-28", "visa_expired_date": "2019-12-06", "visa_started_date": "2018-12-08"}}, {"date": "2019-12-11 15:27:44", "user": "209", "prev_value": {"reg_date": "2018-12-07"}}, {"date": "2020-01-21 13:19:26", "user": "209", "prev_value": {"status_id": "WORKER", "departure_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-29 11:32:43", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-29 11:32:51", "user": "209", "prev_value": {"status_id": "FURLOUGH", "current_passport_number": ""}}, {"date": "2020-01-29 11:33:7", "user": "209", "prev_value": {"current_passport_number": ""}}]	1997-01-10	2016-10-21	2026-10-21	\N	\N	2019-11-12	2019-12-06	2020-12-05	\N	\N	2014-07-02	2019-11-13	2019-12-07	2020-12-05	2017-02-24	2017-02-24	2019-11-26	2020-01-21	232	40	0	1	2	2	0	2	0	\N	\N
77	C2250527	ХОАНГ	ЗОАН ТХАНГ	232	6	[3, 4, 2]	MALE						69	1800005031	202409654	008271 14/CDKTHY	MULTI	WORK	12	1349533	4617	7929502		HOANG	DOAN THANG		Шереметьево 801	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хынгиенский промышленный колледж	НГЕАН		[{"date": "2019-02-27 11:59:25", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1998-11-10	2016-09-12	2026-09-12	\N	\N	2018-11-27	2018-12-07	2019-12-06	\N	\N	2014-07-02	2018-11-28	2018-12-08	2019-12-06	2017-02-24	2017-02-24	2018-12-07	2019-02-19	232	28	0	1	2	2	0	2	0	\N	\N
78	B7233512	ДАНГ	ВАН ДОАН	232	6	[3, 2, 4]	MALE						69	1900004761	202409657	00084817 15/DHCNHN	MULTI	WORK	13	0053858	4619	7895931		DANG	VAN DOAN		Шереметьево 589	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	НГЕАН		[{"date": "2018-12-07 10:19:24", "user": "209", "prev_value": {"reg_date": "2017-12-07", "visa_number": "1017732", "visa_issued_date": "2017-11-28", "visa_expired_date": "2018-12-07", "visa_started_date": "2017-12-08"}}, {"date": "2019-11-26 11:53:19", "user": "209", "prev_value": {"occupation_id": "8", "employ_permit_id": "28", "work_permit_number": "1800004990", "work_permit_issued_date": "2018-11-27", "work_permit_expired_date": "2019-12-06", "work_permit_started_date": "2018-12-07"}}, {"date": "2019-11-26 11:55:14", "user": "209", "prev_value": {"visa_serie": "12", "visa_number": "1349530", "visa_issued_date": "2018-11-28", "visa_expired_date": "2019-12-06", "visa_started_date": "2018-12-08"}}, {"date": "2019-12-02 17:2:7", "user": "209", "prev_value": {"reg_date": "2018-12-07"}}, {"date": "2019-12-04 21:39:20", "user": "209", "prev_value": {"citizenship_id": "232"}}, {"date": "2019-12-11 15:43:10", "user": "209", "prev_value": {"citizenship_id": "177", "current_passport_number": ""}}, {"date": "2019-12-11 15:43:31", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-01-21 13:12:42", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}, {"date": "2020-01-30 16:6:21", "user": "209", "prev_value": {"status_id": "FURLOUGH", "entry_date": "2017-02-24", "migr_card_serie": "4617", "entry_checkpoint": "Шереметьево 817", "migr_card_number": "7943514", "migr_card_issued_date": "2017-02-24", "current_passport_number": ""}}, {"date": "2020-01-30 16:32:2", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-01-31 12:9:23", "user": "209", "prev_value": {"reg_date": "2019-11-26", "current_passport_number": ""}}, {"date": "2020-12-02 13:41:21", "user": "209", "prev_value": {"fired_date": null}}, {"date": "2020-12-02 13:51:59", "user": "209", "prev_value": {"reg_date": "2020-01-31", "departure_date": null, "work_address_id": ""}}, {"date": "2020-12-02 13:52:12", "user": "209", "prev_value": {"status_id": "WORKER"}}]	1992-12-17	2012-10-04	2022-10-04	\N	\N	2019-11-12	2019-12-06	2020-12-05	\N	\N	2015-07-02	2019-11-13	2019-12-07	2020-12-05	2020-01-29	2020-01-29	2020-01-30	2020-12-04	232	40	0	1	2	2	0	2	0	\N	\N
79	C2317122	ТА	ТХИ ЛИЕН	232	6	[3, 4, 2]	FEMALE						69	1800005000	202409653	00070117 00/DHCNHN	MULTI	WORK	12	1349529	4617	7943513		TA	THI LIEN		Шереметьево 817	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойский университет индустрии	ХАНОЙ		[{"date": "2019-02-25 14:3:57", "user": "209", "prev_value": {"status_id": "FURLOUGH", "fired_date": "-0001-11-30"}}]	1964-01-28	2016-09-28	2026-09-28	\N	\N	2018-11-27	2018-12-07	2019-12-06	\N	\N	2000-07-03	2018-11-28	2018-12-08	2019-12-06	2017-02-24	2017-02-24	2018-12-07	2019-01-25	232	28	0	1	2	2	0	2	0	\N	\N
80	C3373260	НГУЕН	ВАН ФЫОНГ	232	6	[3, 2, 5]	MALE						69	1800004976	202401877	004135 10/CDNHD	MULTI	WORK	12	1349534	4617	9053102		NGUYEN	VAN PHUONG		шереметьево 651	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хайзыонгский профессиональный колледж	ТХАНЬХОА		[{"date": "2018-12-07 10:24:29", "user": "209", "prev_value": {"reg_date": "2018-01-12", "visa_number": "1107639", "visa_issued_date": "2018-01-10", "visa_expired_date": "2019-01-10", "visa_started_date": "2018-01-11"}}, {"date": "2019-11-29 13:12:47", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}]	1982-06-01	2017-05-17	2027-05-17	\N	\N	2018-11-27	2019-10-10	2020-01-09	\N	\N	2010-07-02	2018-11-28	2019-01-11	2020-01-09	2017-11-07	2017-11-07	2018-12-07	\N	232	29	0	1	4	4	0	2	0	\N	\N
81	C4117730	ХОАНГ	ДЫК МАНЬ	232	6	[3, 2, 4]	MALE						69	1900002436	202400891	007991	MULTI	WORK	12	1349981	4618	9375881		HOANG	DUC MANH		Шереметьево 564	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Хынгиенский промышленный колледж	ХАНОЙ		[{"date": "2019-02-15 15:44:17", "user": "209", "prev_value": {"reg_date": "2018-07-18", "visa_number": "1348521", "visa_issued_date": "2018-08-31", "visa_expired_date": "2019-02-18", "visa_started_date": "2018-08-31"}}, {"date": "2019-10-21 12:32:28", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-10-21 12:32:41", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1999-07-13	2017-11-07	2027-11-07	\N	\N	2019-02-04	2019-02-18	2020-02-17	\N	\N	2013-07-03	2019-02-13	2019-02-19	2020-02-17	2018-07-17	2018-07-17	2019-02-15	\N	232	32	0	4	2	2	0	2	0	\N	\N
82	C4893943	АН	ВИЕТ ТИНЬ	232	6	[3, 2, 4]	MALE						69	2000004601	202401355	003125542/LDTBXH-DN	MULTI	WORK	12	1770607	4618	9827726		AN	VIET TINH		Шереметьево 800	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ТХАНЬХОА		[{"date": "2018-10-19 12:22:7", "user": "209", "prev_value": {"visa_serie": "23", "visa_number": "8261727", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2018-09-10", "visa_expired_date": "2018-11-22", "visa_started_date": "2018-09-10", "work_permit_serie": ""}}, {"date": "2019-05-21 12:22:45", "user": "207", "prev_value": {"entry_date": "2018-09-13"}}, {"date": "2019-05-21 12:23:1", "user": "207", "prev_value": {"entry_date": "2018-09-14"}}, {"date": "2019-06-24 10:51:15", "user": "209", "prev_value": {"employ_permit_id": "26", "work_permit_serie": "69", "work_permit_number": "1800003852", "work_permit_issued_date": "2018-08-27", "work_permit_expired_date": "2019-07-11", "work_permit_started_date": "2018-08-27"}}, {"date": "2019-06-24 10:51:29", "user": "209", "prev_value": {"visa_number": "1348818", "visa_issued_date": "2018-10-05", "visa_expired_date": "2019-07-11", "visa_started_date": "2018-11-23"}}, {"date": "2019-07-10 12:26:38", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 12:27:45", "user": "209", "prev_value": {"reg_date": "2018-09-14", "visa_number": "", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2019-12-19 14:56:8", "user": "207", "prev_value": {"work_address_id": "", "current_passport_number": ""}}, {"date": "2020-05-13 15:29:46", "user": "209", "prev_value": []}, {"date": "2020-06-23 12:44:50", "user": "209", "prev_value": {"employ_permit_id": "35", "work_permit_number": "1900003824", "work_permit_issued_date": "2019-06-28", "work_permit_expired_date": "2020-07-10", "work_permit_started_date": "2019-07-11"}}, {"date": "2020-06-23 12:50:40", "user": "209", "prev_value": {"reg_date": "2018-10-19", "visa_number": "1560797", "visa_issued_date": "2019-07-04", "visa_expired_date": "2020-07-10", "visa_started_date": "2019-07-12"}}, {"date": "2020-12-23 12:56:52", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2020-12-24 11:16:43", "user": "209", "prev_value": {"work_permit_started_date": "2020-07-10"}}]	1985-07-11	2018-04-02	2028-04-02	\N	\N	2020-06-17	2020-07-01	2021-06-30	\N	\N	2011-06-01	2020-06-18	2020-07-11	2021-06-30	2018-09-13	2018-09-13	2020-06-26	\N	232	49	0	1	2	2	0	2	0	\N	\N
83	C2960819	НГУЕН	ТХИ ТХАНЬ ХЫОНГ	232	6	[3, 2, 4]	FEMALE						69	2100006264	202400816		MULTI	WORK	12	2030556	4619	7541467		NGUYEN	THI THANH HUONG		Шереметьево 584	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАНОЙ		[{"date": "2018-11-19 11:45:58", "user": "209", "prev_value": {"passport_issuer": "миграционным департаментом"}}, {"date": "2019-09-27 11:22:7", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-10-04 11:27:11", "user": "209", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-10-14 11:37:33", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-10-14 11:43:58", "user": "209", "prev_value": {"reg_date": "2018-11-20", "entry_date": "2018-07-17", "departure_date": "2019-09-26", "migr_card_serie": "4618", "entry_checkpoint": "Шереметьево 564", "migr_card_number": "9375876", "migr_card_issued_date": "2018-07-17"}}, {"date": "2019-11-26 12:34:41", "user": "209", "prev_value": {"employ_permit_id": "27", "work_permit_number": "1800004790", "work_permit_issued_date": "2018-11-01", "work_permit_expired_date": "2019-11-27", "work_permit_started_date": "2018-11-28"}}, {"date": "2019-11-26 12:36:2", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "visa_serie": "12", "visa_number": "1349197", "visa_issued_date": "2018-11-08", "visa_expired_date": "2019-11-27", "visa_started_date": "2018-12-01"}}, {"date": "2019-11-28 17:36:25", "user": "209", "prev_value": {"hired_date": "2018-11-28"}}, {"date": "2019-11-28 17:36:44", "user": "209", "prev_value": {"reg_date": "2019-10-15"}}, {"date": "2020-09-15 14:41:27", "user": "209", "prev_value": {"occupation_id": "4"}}, {"date": "2020-11-16 17:20:48", "user": "209", "prev_value": {"hired_date": "2019-11-27", "work_address_id": "", "employ_permit_id": "41", "work_permit_number": "1900004754", "work_permit_issued_date": "2019-11-12", "work_permit_expired_date": "2020-11-26", "work_permit_started_date": "2019-11-27"}}, {"date": "2020-11-16 17:22:39", "user": "209", "prev_value": {"visa_serie": "13", "visa_number": "0053853", "visa_issued_date": "2019-11-13", "visa_expired_date": "2020-11-26", "visa_started_date": "2019-11-28"}}, {"date": "2020-11-16 17:33:17", "user": "209", "prev_value": {"reg_date": "2019-11-26"}}, {"date": "2020-11-19 12:39:13", "user": "209", "prev_value": {"reg_date": null}}, {"date": "2021-11-16 9:40:1", "user": "209", "prev_value": {"reg_date": "2020-11-18", "visa_number": "1771270", "visa_issued_date": "2020-11-03", "visa_expired_date": "2021-11-25", "visa_started_date": "2020-11-27"}}, {"date": "2021-11-16 9:43:33", "user": "209", "prev_value": {"work_permit_number": "2000005002", "work_permit_issued_date": "2020-10-21", "work_permit_expired_date": "2021-11-25", "work_permit_started_date": "2020-11-26"}}, {"date": "2021-11-16 10:36:22", "user": "209", "prev_value": {"employ_permit_id": "52"}}, {"date": "2022-06-14 13:33:46", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1974-03-20	2017-03-30	2027-03-30	\N	\N	2021-10-28	2021-11-25	2022-11-24	\N	\N	\N	2021-11-09	2021-11-26	2022-11-24	2019-10-12	2019-10-12	2021-11-16	\N	232	61	0	1	2	2	0	2	0	\N	\N
84	C4638103	ХО	ВИЕТ ХОАНГ	232	6	[3, 4, 2]	MALE						69	1800003972	202401430		MULTI	WORK	12	1349071	4618	9878207		HO	VIET HOANG		Шереметьев 830	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХЫАТХИЕН-ХЮЭ		[{"date": "2019-02-27 12:0:42", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1996-11-03	2018-03-14	2028-03-14	\N	\N	2018-09-11	2018-09-11	2019-07-14	\N	\N	\N	2018-10-26	2018-12-03	2019-07-14	2018-09-17	2018-09-17	2018-11-08	2019-02-19	232	25	0	4	2	2	0	2	0	\N	\N
85	C5033951	ТА	ВАН ВУ	232	6	[3, 2, 4]	MALE						69	2000004506	202401353	003137253/LDTBXH-DN	MULTI	WORK	12	1770601	4618	9820820		TA	VAN VU		шереметьево 700	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	Тхайбинь		[{"date": "2018-10-19 12:37:13", "user": "209", "prev_value": {"visa_serie": "23", "visa_number": "8260608", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2018-09-03", "visa_expired_date": "2018-11-22", "visa_started_date": "2018-09-03"}}, {"date": "2019-07-10 17:31:1", "user": "209", "prev_value": {"employ_permit_id": "25", "work_permit_serie": "", "work_permit_number": "1800003940", "work_permit_issued_date": "2018-09-10", "work_permit_expired_date": "2019-07-14", "work_permit_started_date": "2018-09-10"}}, {"date": "2019-07-10 17:32:34", "user": "209", "prev_value": {"reg_date": "2018-09-14", "visa_number": "1348821", "visa_issued_date": "2018-10-05", "visa_expired_date": "2019-07-14", "visa_started_date": "2018-11-23"}}, {"date": "2019-07-10 17:36:42", "user": "209", "prev_value": {"work_permit_expired_date": "2020-07-14", "work_permit_started_date": "2019-07-13"}}, {"date": "2020-05-15 12:53:53", "user": "209", "prev_value": {"employ_permit_id": "36"}}, {"date": "2020-05-15 12:54:23", "user": "209", "prev_value": {"reg_date": "2018-10-19"}}, {"date": "2020-05-15 12:55:55", "user": "209", "prev_value": {"occupation_id": "2", "work_address_id": ""}}, {"date": "2020-06-23 14:37:21", "user": "209", "prev_value": {"work_permit_number": "1900003849", "work_permit_issued_date": "2019-06-28", "work_permit_expired_date": "2020-07-13", "work_permit_started_date": "2019-07-14"}}, {"date": "2020-06-23 14:38:54", "user": "209", "prev_value": {"reg_date": "2019-07-12", "visa_number": "1560792", "visa_issued_date": "2019-07-04", "visa_expired_date": "2020-07-13", "visa_started_date": "2019-07-15"}}, {"date": "2020-12-02 13:54:6", "user": "209", "prev_value": {"fired_date": null, "departure_date": null}}, {"date": "2020-12-02 14:4:13", "user": "209", "prev_value": {"status_id": "WORKER"}}]	1990-03-22	2018-04-19	2028-04-19	\N	\N	2020-06-08	2020-07-13	2021-01-26	\N	\N	2014-06-03	2020-06-11	2020-07-14	2021-01-26	2018-09-12	2018-09-12	2020-06-26	2020-12-04	232	45	0	4	2	2	0	2	0	\N	\N
134	402214817	ТОИРОВ	ЖАХОНГИР	209	6	[2, 3, 4]	MALE						69	1900006455							4618	6303386	НОЗИМЧОНОВИЧ				РАМЕНСКОЕ 034	ОВД МВД  ЁВА					[{"date": "2019-02-07 15:7:55", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-04-01 17:4:24", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-24 11:38:7", "user": "209", "prev_value": {"reg_date": "2019-01-15"}}, {"date": "2019-06-03 13:29:15", "user": "209", "prev_value": {"birth_place": "ТАДЖИКИСТАН", "passport_issuer": ""}}, {"date": "2019-06-03 13:31:7", "user": "209", "prev_value": {"reg_date": "2019-04-09", "visa_expired_date": "2019-04-10"}}, {"date": "2019-06-07 10:6:50", "user": "209", "prev_value": {"visa_expired_date": "2019-06-06"}}, {"date": "2019-07-16 10:58:37", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-07-16 10:58:55", "user": "209", "prev_value": {"reg_date": "2019-04-30", "visa_expired_date": "2019-07-06"}}, {"date": "2019-07-31 13:0:3", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-06"}}, {"date": "2019-07-31 13:0:24", "user": "209", "prev_value": {"visa_expired_date": "2019-08-06"}}, {"date": "2019-08-05 10:34:11", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-08-05 10:35:10", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-08-05 10:40:9", "user": "209", "prev_value": {"reg_date": "2019-07-03"}}, {"date": "2019-08-05 11:41:17", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-10"}}]	1998-04-19	2018-07-26	2028-07-25	\N	\N	2019-02-06	2019-02-06	2020-02-06	2019-09-06	\N	\N	\N	\N	2019-09-06	2019-01-11	2019-01-11	2019-08-01	\N	209	0	0	7	2	2	0	2	0	\N	\N
86	C4781904	ЧАН	ТХИ МИЕН	232	6	[3, 2, 4]	FEMALE						69	1900003870	202401427		MULTI	WORK	12	1560789	4618	9882025		TRAN 	THI MIEN		Шереметьево 800	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			НИНЬБИНЬ		[{"date": "2018-11-07 15:3:47", "user": "209", "prev_value": {"visa_serie": "23", "visa_number": "8261920", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2018-09-11", "visa_expired_date": "2018-12-02", "visa_started_date": "2018-09-11"}}, {"date": "2019-06-24 11:3:27", "user": "209", "prev_value": {"employ_permit_id": "25", "work_permit_number": "1800003980", "work_permit_issued_date": "2018-09-11", "work_permit_expired_date": "2019-07-14", "work_permit_started_date": "2018-09-11"}}, {"date": "2019-06-24 11:3:44", "user": "209", "prev_value": {"visa_number": "1349068", "visa_issued_date": "2018-10-26", "visa_expired_date": "2019-07-14", "visa_started_date": "2018-12-03"}}, {"date": "2019-07-10 19:10:54", "user": "209", "prev_value": {"work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 19:11:58", "user": "209", "prev_value": {"reg_date": "2018-09-19", "visa_number": "", "visa_issued_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2019-09-18 13:23:49", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-09-18 13:24:14", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-09-18 13:24:56", "user": "209", "prev_value": {"reg_date": "2018-11-08"}}]	1980-10-05	2018-03-17	2028-03-17	\N	\N	2018-06-28	2019-07-14	2020-07-13	\N	\N	\N	2019-07-04	2019-07-15	2020-07-13	2018-09-17	2018-09-17	2019-07-12	\N	232	36	0	4	2	2	0	2	0	\N	\N
87	C4869023	НГУЕН	ТХИ НЯН	232	6	[3, 2, 4]	FEMALE						69	1900003817		003121239/LDTBXH-DN	MULTI	WORK	12	1560793	4618	9827674		NGUYEN	THI NHAN		шереметьево 747	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	Тхайбинь		[{"date": "2018-10-19 12:50:50", "user": "209", "prev_value": {"visa_serie": "23", "visa_number": "8260609", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "contract_number": "", "visa_issued_date": "2018-09-03", "visa_expired_date": "2018-11-22", "visa_started_date": "2018-09-03"}}, {"date": "2019-06-24 10:52:42", "user": "209", "prev_value": {"employ_permit_id": "26", "work_permit_serie": "", "work_permit_number": "1800003933", "work_permit_issued_date": "2018-09-10", "work_permit_expired_date": "2019-07-11", "work_permit_started_date": "2018-09-10"}}, {"date": "2019-06-24 10:57:14", "user": "209", "prev_value": {"visa_number": "1348817", "visa_issued_date": "2018-10-05", "visa_expired_date": "2019-07-11", "visa_started_date": "2018-11-23"}}, {"date": "2019-07-10 13:17:8", "user": "209", "prev_value": {"work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 13:18:3", "user": "209", "prev_value": {"reg_date": "2018-09-14", "visa_number": "", "visa_issued_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2019-12-06 13:46:53", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-12-06 13:47:7", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-12-06 13:47:35", "user": "209", "prev_value": {"reg_date": "2018-10-19"}}]	1979-03-27	2018-04-04	2028-04-04	\N	\N	2019-06-28	2019-07-11	2019-07-10	\N	\N	2007-09-04	2019-07-04	2019-07-11	2020-07-10	2018-09-12	2018-09-12	2019-07-10	\N	232	35	0	1	2	2	0	2	0	\N	\N
88	C4858457	ЛЕ	ВАН ТХАНЬ	232	6	[3, 2, 4]	MALE						69	1900003888	202401431		MULTI	WORK	12	1560790	4618	9882027		LE	VAN THANH		Шереметьево 800	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			БАРИА-ВУНГТАУ		[{"date": "2018-11-07 14:35:17", "user": "209", "prev_value": {"visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ"}}, {"date": "2019-06-24 11:0:37", "user": "209", "prev_value": {"employ_permit_id": "25", "work_permit_number": "1800003965", "work_permit_issued_date": "2018-09-11", "work_permit_expired_date": "2019-07-14", "work_permit_started_date": "2018-09-11"}}, {"date": "2019-06-24 11:1:19", "user": "209", "prev_value": {"visa_number": "1349070", "visa_issued_date": "2018-10-26", "visa_expired_date": "2019-07-14", "visa_started_date": "2018-12-03"}}, {"date": "2019-07-10 14:43:36", "user": "209", "prev_value": {"work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "2020-11-11", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 14:44:39", "user": "209", "prev_value": {"reg_date": "2018-09-19", "visa_number": "", "visa_issued_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2019-12-06 12:48:47", "user": "209", "prev_value": {"reg_date": "2018-11-08"}}, {"date": "2019-12-06 12:53:1", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-12-06 12:53:47", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1994-02-01	2018-04-04	2028-04-04	\N	\N	2019-06-28	2019-07-14	2020-07-13	\N	\N	\N	2019-07-04	2019-07-15	2020-07-13	2018-09-17	2018-09-17	2019-07-12	\N	232	36	0	4	2	2	0	2	0	\N	\N
89	C5256765	НГУЕН	ДИНЬ КИЕН	232	6	[3, 2, 4]	MALE						69	2100005180	202401428		MULTI	WORK	12	1946379	4618	9827725		NGUYEN	DINH KIEN		Шереметьево 800	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			БАКНИНЬ		[{"date": "2018-11-07 14:30:25", "user": "209", "prev_value": {"visa_serie": "23", "visa_number": "8261572", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2018-09-10", "visa_expired_date": "2018-12-02", "visa_started_date": "2018-09-10"}}, {"date": "2019-06-24 11:2:43", "user": "209", "prev_value": {"employ_permit_id": "25", "work_permit_number": "1800003860", "work_permit_issued_date": "2018-09-18", "work_permit_expired_date": "2019-07-14", "work_permit_started_date": "2018-09-18"}}, {"date": "2019-06-24 11:2:58", "user": "209", "prev_value": {"visa_number": "1349072", "visa_issued_date": "2018-10-26", "visa_expired_date": "2019-07-14", "visa_started_date": "2018-12-03"}}, {"date": "2019-07-10 16:26:17", "user": "209", "prev_value": {"work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 16:27:17", "user": "209", "prev_value": {"reg_date": "2018-09-14", "visa_number": "", "visa_issued_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2020-05-15 12:24:54", "user": "209", "prev_value": {"employ_permit_id": "36"}}, {"date": "2020-05-15 12:25:20", "user": "209", "prev_value": {"reg_date": "2018-11-08"}}, {"date": "2020-06-23 14:21:49", "user": "209", "prev_value": {"work_permit_number": "1900003895", "work_permit_issued_date": "2019-06-28", "work_permit_expired_date": "2020-07-13", "work_permit_started_date": "2019-07-14"}}, {"date": "2020-06-23 14:22:56", "user": "209", "prev_value": {"reg_date": "2019-07-12", "visa_number": "1560787", "visa_issued_date": "2019-07-04", "visa_expired_date": "2020-07-13", "visa_started_date": "2019-07-15"}}, {"date": "2021-02-15 11:25:57", "user": "209", "prev_value": {"employ_permit_id": "46", "work_permit_number": "2000004513", "work_permit_issued_date": "2020-06-08", "work_permit_expired_date": "2021-02-16", "work_permit_started_date": "2020-07-13"}}, {"date": "2021-02-15 11:27:24", "user": "209", "prev_value": {"reg_date": "2020-06-26", "visa_number": "1770602", "visa_issued_date": "2020-06-11", "visa_expired_date": "2021-02-16", "visa_started_date": "2020-07-14"}}, {"date": "2021-12-20 16:26:32", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2021-12-20 16:33:47", "user": "209", "prev_value": {"fired_date": "2021-12-18"}}]	1989-11-28	2018-05-23	2028-05-23	\N	\N	2021-02-05	2021-02-16	2022-02-15	\N	\N	\N	2021-02-12	2021-02-17	2022-02-15	2018-09-13	2018-09-13	2021-02-16	\N	232	55	0	4	2	2	0	2	0	\N	\N
90	C1282750	НГУЕН	ТХИ НГОК АНЬ	232	6	[3, 4, 2]	FEMALE						69	1800003556	202401290				23	8259530	4618	9748265		NGUYEN	THI NGOC ANH		Шереметьево 564	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАНОЙ		[{"date": "2018-09-28 23:48:58", "user": "208", "prev_value": {"departure_date": "2018-09-27"}}]	1983-07-28	2016-01-15	2026-01-15	\N	\N	2018-07-31	2018-07-31	2019-02-18	\N	\N	\N	2018-08-24	2018-08-24	2018-11-11	2018-08-26	2018-08-26	2018-08-28	2018-09-28	232	20	0	4	2	2	0	2	0	\N	\N
135	401927161	ХОЧАЕВА	МАМЛАКАТ	209	6	[2, 3, 4]	FEMALE						69	1900006487							4618	6304855	ИКРОМЧОНОВНА				РАМЕНСКОЕ 059				ТАДЖИКИСТАН		[{"date": "2019-02-07 15:0:48", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-04-01 17:5:6", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-24 11:22:39", "user": "209", "prev_value": {"reg_date": "2019-01-15"}}, {"date": "2019-04-29 14:34:59", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-04-29 14:35:39", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1975-07-25	2018-02-01	2028-01-31	\N	\N	2019-02-06	2019-02-06	2019-04-10	2019-04-04	\N	\N	\N	\N	\N	2019-01-11	2019-01-11	2019-04-09	\N	209	0	0	7	2	2	0	2	0	\N	\N
91	C5414628	НГУЕН	ВАН ФУК	232	6	[3, 2, 4]	MALE						69	2200006571	202401426		MULTI	WORK	12	1947250	4618	9827727		NGUYEN	VAN PHUC		Шереметьево 800	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			БАКНИНЬ		[{"date": "2018-11-19 10:3:48", "user": "209", "prev_value": {"visa_serie": "23", "visa_number": "8261247", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2018-09-06", "visa_expired_date": "2018-12-02", "visa_multiplicity": "SINGLE", "visa_started_date": "2018-09-06"}}, {"date": "2019-06-24 11:1:58", "user": "209", "prev_value": {"employ_permit_id": "25", "work_permit_number": "1800004373", "work_permit_issued_date": "2018-09-26", "work_permit_expired_date": "2019-07-14", "work_permit_started_date": "2018-09-26"}}, {"date": "2019-06-24 11:2:16", "user": "209", "prev_value": {"visa_number": "1349255", "visa_issued_date": "2018-11-15", "visa_expired_date": "2019-07-14", "visa_started_date": "2018-12-03"}}, {"date": "2019-07-10 15:0:43", "user": "209", "prev_value": {"work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 15:2:14", "user": "209", "prev_value": {"reg_date": "2018-09-14", "visa_number": "", "visa_issued_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2020-05-15 12:5:12", "user": "209", "prev_value": {"occupation_id": "5", "employ_permit_id": "36"}}, {"date": "2020-05-15 12:8:0", "user": "209", "prev_value": {"reg_date": "2018-11-20"}}, {"date": "2020-05-20 12:34:31", "user": "209", "prev_value": {"work_permit_started_date": "2019-07-14"}}, {"date": "2020-06-23 14:5:3", "user": "209", "prev_value": {"work_permit_number": "1900003856", "work_permit_issued_date": "2019-06-28", "work_permit_expired_date": "2020-07-13", "work_permit_started_date": "2019-07-15"}}, {"date": "2020-06-23 14:14:58", "user": "209", "prev_value": {"reg_date": "2019-07-12", "visa_number": "1560791", "visa_issued_date": "2019-07-04", "visa_expired_date": "2020-07-13", "visa_started_date": "2019-07-14"}}, {"date": "2021-01-20 17:23:22", "user": "209", "prev_value": {"hired_date": "2018-10-03", "employ_permit_id": "45", "work_permit_number": "2000004496", "work_permit_issued_date": "2019-06-08", "work_permit_expired_date": "2021-01-26"}}, {"date": "2021-01-20 17:28:36", "user": "209", "prev_value": {"hired_date": null}}, {"date": "2021-01-20 17:30:57", "user": "209", "prev_value": {"visa_number": "1770603"}}, {"date": "2021-01-20 17:31:43", "user": "209", "prev_value": {"visa_issued_date": "2020-06-11", "visa_expired_date": "2021-01-26", "visa_started_date": "2020-07-14"}}, {"date": "2021-01-21 11:38:35", "user": "209", "prev_value": {"work_permit_started_date": "2020-07-15"}}, {"date": "2022-01-24 13:17:35", "user": "209", "prev_value": {"employ_permit_id": "54", "work_permit_number": "2000005122", "work_permit_issued_date": "2020-12-28", "work_permit_expired_date": "2022-01-25", "work_permit_started_date": "2021-01-26"}}, {"date": "2022-01-24 13:19:40", "user": "209", "prev_value": {"reg_date": "2020-06-26", "visa_number": "1946287", "visa_issued_date": "2021-01-14", "visa_expired_date": "2022-01-25", "visa_started_date": "2021-01-27"}}, {"date": "2022-01-27 9:43:17", "user": "209", "prev_value": {"visa_expired_date": "2023-01-24"}}, {"date": "2022-04-05 13:58:9", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1995-01-22	2018-07-11	2028-07-11	\N	\N	2022-01-17	2022-01-25	2023-01-24	\N	\N	\N	2022-01-21	2022-01-26	2022-06-30	2018-09-13	2018-09-13	2022-01-25	\N	232	66	0	4	2	2	0	2	0	\N	\N
92	ID1026323	САИТКАСИМОВ	ЗАЙЛОБИДИН	115	6	[3, 2, 4]	MALE														2019	0078114	ЛАЧИНОВИЧ				ДОМОДЕВО 387	МКК 214041			КЫРГЫЗСКАЯ РЕСПУБЛИКА		[{"date": "2019-02-18 14:38:6", "user": "209", "prev_value": {"entry_date": "2018-08-12", "migr_card_serie": "5317", "entry_checkpoint": "МАШТАКОВО 87", "migr_card_number": "1818708"}}, {"date": "2019-03-28 11:25:55", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-04-23 10:30:10", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-04-23 10:30:34", "user": "209", "prev_value": {"visa_expired_date": "2019-05-13"}}, {"date": "2019-08-16 11:26:23", "user": "209", "prev_value": {"hired_date": "2018-08-22"}}, {"date": "2019-08-16 11:27:3", "user": "209", "prev_value": {"reg_date": "2019-02-19", "visa_expired_date": "2019-08-21"}}, {"date": "2019-08-19 11:6:44", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-08-19 12:11:5", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-08-19 12:11:42", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-08-19 14:26:58", "user": "209", "prev_value": {"status_id": "FIRED"}}, {"date": "2019-08-19 14:27:8", "user": "209", "prev_value": {"fired_date": "2019-08-20"}}, {"date": "2019-08-19 14:27:33", "user": "209", "prev_value": {"visa_expired_date": "2020-08-20"}}, {"date": "2019-08-20 12:7:36", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-08-20 12:7:49", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-08-26 15:17:0", "user": "209", "prev_value": {"hired_date": "2019-08-21"}}, {"date": "2020-01-14 14:18:5", "user": "209", "prev_value": {"work_address_id": "", "current_passport_number": ""}}, {"date": "2020-01-14 14:19:51", "user": "209", "prev_value": {"host_id": "4", "reg_date": "2019-04-26", "entry_date": "2019-02-13", "migr_card_serie": "4618", "migr_card_number": "02596490", "visa_expired_date": "2019-08-21", "migr_card_issued_date": "2019-02-13", "current_passport_number": ""}}, {"date": "2020-01-14 14:20:21", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-14 14:20:26", "user": "209", "prev_value": {"status_id": "FIRED", "current_passport_number": ""}}, {"date": "2020-01-14 14:20:41", "user": "209", "prev_value": {"employer_id": "4", "current_passport_number": ""}}, {"date": "2020-01-16 13:15:40", "user": "209", "prev_value": {"hired_date": "2020-01-14", "current_passport_number": ""}}, {"date": "2020-01-16 13:15:52", "user": "209", "prev_value": {"reg_date": "2020-01-10", "current_passport_number": ""}}, {"date": "2020-03-04 10:30:5", "user": "209", "prev_value": {"fired_date": "2019-08-20", "contract_number": "3", "current_passport_number": "", "work_permit_paid_till_date": null}}, {"date": "2020-03-04 12:38:53", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null, "current_passport_number": "", "work_permit_paid_till_date": null}}, {"date": "2020-03-04 13:17:37", "user": "209", "prev_value": {"status_id": "FIRED", "fired_date": "2020-03-04", "hired_date": "2020-01-16", "current_passport_number": ""}}, {"date": "2020-04-07 12:44:22", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1990-02-25	2019-01-16	2029-01-16	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-12-14	2019-12-14	2020-01-16	\N	115	0	0	7	2	2	0	0	0	\N	\N
93	AA1541728	АЗИЗОВ	РУСТАМХОН	229	2	[3, 4, 2]	MALE														5317	1933741	МУХТ0РОВИЧ					ОВД КАСАНСАЙСКОГО РАЙОНА НАМАГАНСКОЙ ОБЛАСТИ			КАСАНСАЙСКИЙ РАЙОН		[{"date": "2018-11-07 11:8:34", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1972-09-30	2013-05-19	2023-05-18	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2018-09-03	2018-09-03	\N	\N	229	0	0	7	2	2	0	0	0	\N	\N
94	C5931785	ДИНЬ	ТХИ ЗЫОНГ	232	6	[3, 2, 4]	FEMALE						69	2200006719	202401819		MULTI	WORK	12	1947320	4619	6015715		DINH	THI DUONG		шереметьево 799	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			БАКНИНЬ		[{"date": "2018-12-20 11:20:16", "user": "209", "prev_value": {"visa_serie": "23", "visa_number": "8995124", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2018-10-29", "visa_expired_date": "2019-01-18", "visa_multiplicity": "SINGLE", "visa_started_date": "2018-10-29"}}, {"date": "2019-06-10 10:52:25", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-06-10 11:48:12", "user": "209", "prev_value": {"work_permit_number": "1800004856", "work_permit_expired_date": "2019-07-14", "work_permit_started_date": "2018-11-16"}}, {"date": "2019-06-24 10:59:38", "user": "209", "prev_value": {"employ_permit_id": "25", "work_permit_issued_date": "2018-11-16", "work_permit_started_date": "2019-07-14"}}, {"date": "2019-06-24 11:0:5", "user": "209", "prev_value": {"visa_number": "1349715", "visa_issued_date": "2018-12-11", "visa_expired_date": "2019-07-14", "visa_started_date": "2019-01-19"}}, {"date": "2019-07-10 14:16:41", "user": "209", "prev_value": {"work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-07-10 14:17:40", "user": "209", "prev_value": {"visa_number": "", "visa_issued_date": "-0001-11-30", "visa_started_date": "-0001-11-30"}}, {"date": "2020-05-13 16:2:25", "user": "209", "prev_value": {"reg_date": "2018-12-20"}}, {"date": "2020-05-13 16:2:55", "user": "209", "prev_value": {"employ_permit_id": "36"}}, {"date": "2020-05-15 11:39:14", "user": "209", "prev_value": {"occupation_id": "3", "work_address_id": ""}}, {"date": "2020-05-15 13:34:9", "user": "209", "prev_value": {"visa_started_date": "2019-07-14"}}, {"date": "2020-06-23 13:56:31", "user": "209", "prev_value": {"work_permit_number": "1900003863", "work_permit_issued_date": "2019-06-28", "work_permit_expired_date": "2020-07-13", "work_permit_started_date": "2019-07-14"}}, {"date": "2020-06-23 13:57:55", "user": "209", "prev_value": {"reg_date": "2019-07-12", "visa_number": "1560788", "visa_issued_date": "2019-07-04", "visa_expired_date": "2020-07-13", "visa_started_date": "2019-07-15"}}, {"date": "2021-02-15 12:9:47", "user": "209", "prev_value": {"employ_permit_id": "46", "work_permit_number": "2000004520", "work_permit_issued_date": "2020-06-08", "work_permit_expired_date": "2021-02-16", "work_permit_started_date": "2020-07-13"}}, {"date": "2021-02-15 12:11:11", "user": "209", "prev_value": {"reg_date": "2020-06-26", "visa_number": "1770604", "visa_issued_date": "2020-06-11", "visa_expired_date": "2021-02-16", "visa_started_date": "2020-07-14"}}, {"date": "2022-02-15 13:8:58", "user": "209", "prev_value": {"employ_permit_id": "55", "work_permit_number": "2100005197", "work_permit_issued_date": "2021-02-05", "work_permit_expired_date": "2022-02-15", "work_permit_started_date": "2021-02-16"}}, {"date": "2022-02-15 13:10:26", "user": "209", "prev_value": {"reg_date": "2021-02-16", "visa_number": "1946380", "visa_issued_date": "2021-02-12", "visa_expired_date": "2022-02-15", "visa_started_date": "2021-02-17"}}, {"date": "2022-02-16 15:2:30", "user": "209", "prev_value": {"visa_expired_date": "2023-02-14"}}, {"date": "2022-02-16 15:3:39", "user": "209", "prev_value": {"visa_expired_date": "2022-06-30"}}, {"date": "2022-02-16 15:7:9", "user": "209", "prev_value": {"visa_expired_date": "2023-02-14"}}, {"date": "2022-04-05 13:52:0", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1966-01-01	2018-08-27	2028-08-27	\N	\N	2022-02-07	2022-02-15	2023-02-14	\N	\N	\N	2022-02-10	2022-02-16	2022-06-30	2018-10-31	2018-10-31	2022-02-15	\N	232	68	0	4	2	2	0	2	0	\N	\N
95	#3	Мейссер	Наталья	0	9	[3, 2]	FEMALE																Александровна										[{"date": "2018-10-01 22:20:27", "user": "208", "prev_value": []}, {"date": "2018-10-01 22:25:5", "user": "207", "prev_value": []}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
96	ID1342012	САИТКАСИМОВ	ХУСАН	115	6	[3, 2, 4]	MALE														4620	0259014	ЛАЧИНОВИЧ				домодедово 1007	МКК 214041			КЫРГЫЗСТАН		[{"date": "2019-01-09 13:48:28", "user": "209", "prev_value": {"citizenship_id": "229"}}, {"date": "2019-07-16 11:19:7", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-09-05 11:7:47", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-09-05 11:7:59", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-09-05 12:31:18", "user": "209", "prev_value": {"reg_date": "2018-10-15"}}, {"date": "2020-02-26 12:29:55", "user": "209", "prev_value": {"status_id": "FIRED", "entry_date": "2018-10-03", "entry_checkpoint": "РОССИЯ КПП", "current_passport_number": ""}}, {"date": "2020-02-26 12:31:50", "user": "209", "prev_value": {"passport_issuer": "МКК 50-32", "passport_number": "AN4510565", "passport_issued_date": "2016-05-18", "passport_expired_date": "2026-05-18", "current_passport_number": ""}}, {"date": "2020-02-26 12:33:4", "user": "209", "prev_value": {"reg_date": "2018-10-19", "migr_card_serie": "5318", "migr_card_number": "0621978", "migr_card_issued_date": "2018-10-03", "current_passport_number": ""}}, {"date": "2020-02-27 11:21:30", "user": "209", "prev_value": {"fired_date": "2019-09-05", "hired_date": "2018-10-19", "employer_id": "4", "contract_number": "13", "work_address_id": "", "current_passport_number": ""}}, {"date": "2020-02-27 11:22:20", "user": "209", "prev_value": {"host_id": "4", "reg_date": "2020-02-26", "migr_card_serie": "46 20", "visa_expired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-03-02 12:5:14", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": "-0001-11-30", "contract_number": "", "current_passport_number": ""}}, {"date": "2020-03-02 12:6:4", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-04-07 12:49:34", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1986-08-18	2019-08-08	2029-08-08	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2020-05-22	2020-02-23	2020-02-23	2020-02-27	\N	115	0	0	7	2	2	0	0	0	\N	\N
160	401311548	ДАДАБАЕВА	МАНЗУРА	209	8	[3, 4, 2]	FEMALE														4618	6416947	МАХСУДБОЕВНА				РАМЕНСКОЕ 057						[{"date": "2019-04-29 12:33:36", "user": "209", "prev_value": []}, {"date": "2019-04-29 12:33:57", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-04-29 12:35:46", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "visa_expired_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-05-13 11:1:55", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-05-13 11:2:9", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1972-04-13	2017-01-12	2027-01-11	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-04-25	2019-04-25	2019-04-29	\N	209	0	0	7	2	2	0	0	0	\N	\N
97	401023937	МАХМУДОВ	НЕЪМАТШЕХ	209	6	[3, 2, 4]	MALE						69	1800103617							4618	6304854	МУХАМАДШЕХОВИЧ					ОМВД В Б.ГАФУРОВ					[{"date": "2019-01-15 13:29:31", "user": "209", "prev_value": {"reg_date": "2018-11-06", "migr_card_serie": "4118"}}, {"date": "2019-03-28 11:28:2", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-03-29 12:38:16", "user": "209", "prev_value": {"visa_expired_date": "2008-04-19"}}, {"date": "2019-04-01 17:3:26", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-25 11:38:2", "user": "209", "prev_value": {"reg_date": "2019-01-15"}}, {"date": "2019-04-25 12:25:14", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "birth_place": "ТАДЖИКИСТАН", "visa_expired_date": "2019-04-08"}}, {"date": "2019-07-03 14:16:52", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-07-03 14:21:46", "user": "209", "prev_value": {"reg_date": "2019-04-04"}}, {"date": "2019-07-03 14:22:8", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-16 11:1:8", "user": "209", "prev_value": {"reg_date": "2019-06-05"}}, {"date": "2019-07-31 13:28:5", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-06"}}, {"date": "2019-07-31 13:28:14", "user": "209", "prev_value": {"visa_expired_date": "2019-08-06"}}, {"date": "2019-08-27 13:49:38", "user": "209", "prev_value": {"reg_date": "2019-07-03"}}, {"date": "2019-09-03 11:47:53", "user": "209", "prev_value": {"work_permit_issued_date": "2018-09-06", "work_permit_expired_date": "2019-09-06", "work_permit_started_date": "2018-09-06", "work_permit_paid_till_date": "2019-09-06"}}, {"date": "2019-09-03 11:48:29", "user": "209", "prev_value": {"visa_expired_date": "2019-09-06"}}, {"date": "2019-09-10 13:26:25", "user": "209", "prev_value": {"reg_date": "2019-07-31"}}, {"date": "2019-10-04 12:23:29", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-10-07"}}, {"date": "2019-10-04 12:23:43", "user": "209", "prev_value": {"reg_date": "2019-09-03"}}, {"date": "2019-10-29 13:47:22", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-11-07"}}, {"date": "2019-10-29 13:47:32", "user": "209", "prev_value": {"visa_expired_date": "2019-10-07"}}, {"date": "2019-12-04 15:5:6", "user": "209", "prev_value": {"reg_date": "2019-09-25"}}, {"date": "2019-12-04 15:6:54", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-12-07"}}, {"date": "2019-12-04 15:7:7", "user": "209", "prev_value": {"visa_expired_date": "2019-12-07"}}, {"date": "2019-12-24 9:54:53", "user": "209", "prev_value": {"reg_date": "2019-10-29", "visa_expired_date": "2019-01-07", "current_passport_number": "", "work_permit_paid_till_date": "2019-01-07"}}, {"date": "2020-02-25 10:44:59", "user": "209", "prev_value": {"current_passport_number": "", "work_permit_paid_till_date": "2019-02-07"}}, {"date": "2020-02-25 10:45:16", "user": "209", "prev_value": {"visa_expired_date": "2020-02-07", "current_passport_number": ""}}, {"date": "2020-03-18 13:30:21", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-03-07"}}, {"date": "2020-03-18 13:30:51", "user": "209", "prev_value": {"reg_date": "2019-12-05", "visa_expired_date": "2020-03-07"}}, {"date": "2020-04-07 12:19:56", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2020-04-07 12:20:55", "user": "209", "prev_value": {"reg_address_id": "2", "work_address_id": ""}}, {"date": "2020-04-07 12:21:28", "user": "209", "prev_value": {"real_address_id": "2"}}]	1981-10-28	2016-03-30	2026-03-29	\N	\N	2019-09-07	2019-09-07	2020-09-07	2020-04-07	\N	\N	\N	\N	2020-04-07	2019-01-11	2019-01-11	2020-03-03	\N	209	0	0	4	7	7	0	2	0	\N	\N
98	C5578666	ДАО	ВАН ШИНЬ	232	6	[3, 2, 4]	MALE						69	2000004930	202402319	011583	MULTI	WORK	12	1771282	4619	6142287		DAO	VAN SINH		шереметьево 615	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		ЧАСТНОЕ ПТУ "ЗУИТАН"	ХАЙЗЫОНГ		[{"date": "2019-01-25 12:13:58", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-13 11:47:25", "user": "209", "prev_value": {"visa_serie": "23", "visa_number": "8998244", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2018-12-25", "visa_expired_date": "2019-03-23", "visa_multiplicity": "SINGLE", "visa_started_date": "2018-12-25"}}, {"date": "2019-09-23 11:24:52", "user": "209", "prev_value": []}, {"date": "2019-09-23 11:25:35", "user": "209", "prev_value": {"reg_date": "2018-12-29"}}, {"date": "2019-11-01 10:47:51", "user": "209", "prev_value": {"hired_date": "2019-01-25", "work_permit_number": "1900002299", "work_permit_issued_date": "2019-01-18", "work_permit_expired_date": "2019-11-18", "work_permit_started_date": "2019-01-18"}}, {"date": "2019-11-01 10:50:7", "user": "209", "prev_value": {"visa_serie": "12", "visa_number": "1560081", "visa_issued_date": "2019-03-04", "visa_expired_date": "2019-11-18", "visa_started_date": "2019-03-24"}}, {"date": "2019-11-13 15:41:26", "user": "209", "prev_value": {"employ_permit_id": "30"}}, {"date": "2019-11-18 11:4:51", "user": "209", "prev_value": {"reg_date": "2019-03-13"}}, {"date": "2020-11-16 17:42:32", "user": "209", "prev_value": {"reg_date": "2019-11-15", "visa_serie": "13", "visa_number": "0053633", "visa_issued_date": "2019-10-28", "visa_expired_date": "2020-11-17", "visa_started_date": "2019-11-19"}}, {"date": "2020-11-17 10:50:26", "user": "209", "prev_value": {"hired_date": "2019-11-18", "work_address_id": "", "employ_permit_id": "39", "work_permit_number": "1900004627", "work_permit_issued_date": "2019-10-23", "work_permit_expired_date": "2020-11-17", "work_permit_started_date": "2019-11-18"}}, {"date": "2020-11-17 10:51:2", "user": "209", "prev_value": {"reg_date": null}}, {"date": "2021-04-12 13:4:50", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1974-05-08	2018-07-13	2028-07-13	\N	\N	2020-10-13	2020-11-17	2021-11-16	\N	\N	2016-07-04	2020-11-05	2020-11-18	2021-11-16	2018-12-28	2018-12-28	2020-11-17	\N	232	53	0	4	2	2	0	2	0	\N	\N
99	C5891217	НГУЕН	ТХИ АНЬ	232	6	[3, 2, 4]	FEMALE						69	2100006225		011590	MULTI	WORK	12	2030553	4619	6142288		NGUYEN	THI ANH		шереметьево 615	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		ЧАСТНОЕ ПТУ "ЗУИТАН"	ХАТИНЬ		[{"date": "2019-01-25 12:9:20", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-13 11:33:55", "user": "209", "prev_value": {"visa_serie": "23", "visa_number": "8998243", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2018-12-25", "visa_expired_date": "2019-03-23", "visa_multiplicity": "SINGLE", "visa_started_date": "2018-12-25"}}, {"date": "2019-09-23 12:7:37", "user": "209", "prev_value": {"reg_date": "2018-12-29"}}, {"date": "2019-10-09 12:31:8", "user": "209", "prev_value": {"occupation_id": "1"}}, {"date": "2019-11-13 15:46:21", "user": "209", "prev_value": {"hired_date": "2019-01-25", "employ_permit_id": "30", "work_permit_number": "1900002309", "work_permit_issued_date": "2019-01-18", "work_permit_expired_date": "2019-11-18", "work_permit_started_date": "2019-01-18"}}, {"date": "2019-11-13 15:48:2", "user": "209", "prev_value": {"visa_serie": "12", "visa_number": "1560080", "visa_issued_date": "2019-03-04", "visa_expired_date": "2019-11-18", "visa_started_date": "2019-03-24"}}, {"date": "2019-11-14 13:50:45", "user": "209", "prev_value": {"visa_expired_date": "2020-11-11"}}, {"date": "2019-11-18 11:16:58", "user": "209", "prev_value": {"reg_date": "2019-03-13"}}, {"date": "2020-11-16 17:40:31", "user": "209", "prev_value": {"reg_date": "2019-11-15", "visa_serie": "13", "visa_number": "0053632", "visa_issued_date": "2019-10-28", "visa_expired_date": "2020-11-17", "visa_started_date": "2019-11-19"}}, {"date": "2020-11-17 10:13:51", "user": "209", "prev_value": {"hired_date": "2019-11-18", "work_address_id": "", "employ_permit_id": "39", "work_permit_number": "1900004634", "work_permit_issued_date": "2019-10-23", "work_permit_expired_date": "2020-11-17", "work_permit_started_date": "2019-11-18"}}, {"date": "2020-11-17 10:15:46", "user": "209", "prev_value": {"reg_date": null}}, {"date": "2021-11-16 9:23:24", "user": "209", "prev_value": {"reg_date": "2020-11-17", "visa_number": "1771283", "visa_issued_date": "2020-11-05", "visa_expired_date": "2021-11-16", "visa_started_date": "2020-11-18"}}, {"date": "2021-11-16 9:27:27", "user": "209", "prev_value": {"work_permit_number": "2000004947", "work_permit_issued_date": "2020-10-13", "work_permit_expired_date": "2021-11-16", "work_permit_started_date": "2020-11-17"}}, {"date": "2021-11-16 10:16:7", "user": "209", "prev_value": {"employ_permit_id": "53"}}, {"date": "2022-04-05 14:5:30", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1982-01-20	2018-08-16	2028-08-16	\N	\N	2021-10-28	2021-11-16	2022-11-15	\N	\N	2016-07-04	2021-11-09	2021-11-17	2022-11-15	2018-12-28	2018-12-28	2021-11-16	\N	232	62	0	4	2	2	0	2	0	\N	\N
100	C5984381	ХОАНГ	НГОК КИМ	232	2	[3, 2, 4]	MALE									011594								HOANG	NGOC KIM			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		ЧАСТНОЕ ПТУ "ЗУИТАН"	ИЕНБАЙ		[{"date": "2018-11-19 12:45:21", "user": "209", "prev_value": []}, {"date": "2019-09-11 14:31:22", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1982-06-10	2018-08-28	2028-08-28	\N	\N	\N	\N	\N	\N	\N	2016-07-04	\N	\N	\N	\N	\N	\N	\N	232	30	0	4	2	2	0	0	0	\N	\N
101	750733	РЕПИНА	АЛЕКСАНДРА	177	6	[2, 3, 4]	FEMALE	97 09															ВИТАЛЬЕВНА					ОТДЕЛОМ УФМС РОССИИ ПО ЧУВАШСКОЙ РЕСПУБЛИКЕ В КАЛИНИНСКОМ РАЙОНЕ ГОР.ЧЕБОКСАРЫ			С.АМАНБУКТЕР САРКАНДСКОГО Р-НА ТАЛДЫ-КУРГАНСКОЙ ОБЛ. КАЗАХСКОЙ ССР	Тверская обл.,Кимрский р-он ,пос.Белый городок ,ул.Главная д.22,кв.3	[{"date": "2018-12-13 13:28:52", "user": "208", "prev_value": {"reg_address_id": ""}}, {"date": "2019-08-14 11:45:25", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-08-14 11:45:40", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-08-14 12:3:24", "user": "209", "prev_value": {"fired_date": "2019-08-02"}}]	1975-03-21	2009-09-09	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	423101000750	0	12	0	0	0	0	\N	\N
102	621829	КОЗЛОВ	АЛЕКСАНДР	177	6	[3, 2, 4, 5]	MALE	28 02															ИВАНОВИЧ					ОВД КИМРСКОГО РАЙОНА ТВЕРСКОЙ ОБЛАСТИ			ДЕР.ФИЛИППОВО КИМРСКОГО Р-НА ТВЕРСКОЙ ОБЛАСТИ	г.Кимры ,ул.50 Лет ВЛКСМ д.28,кв.87	[{"date": "2018-11-21 11:34:31", "user": "209", "prev_value": {"address": ""}}, {"date": "2022-12-21 17:43:0", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null, "contract_number": ""}}]	1951-02-12	2002-05-22	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
103	229995	НИКОНОВ	ВЛАДИМИР	177	6	[3, 2, 4, 5]	MALE	28 00															МИХАЙЛОВИЧ					ОВД КИМРСКОГО РАЙОНА ТВЕРСКОЙ ОБЛАСТИ			ГОР.КИМРЫ	гор.Кимры,ул.Ульяновская д.22а	[{"date": "2018-11-21 11:35:26", "user": "209", "prev_value": {"address": ""}}, {"date": "2022-12-21 17:43:26", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null, "contract_number": ""}}]	1952-09-03	2000-12-30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	1	0	0	0	0	0	\N	\N
104	400802416	ХОШИМОВА	МАНЗУРА	209	6	[2, 3, 4]	FEMALE						69	1800126808							46 18	2013962	ГАФОРОВНА				ДОМОДЕВО 1400	ПРС В ХУДЖАНД			ТАДЖИКИСТАН		[{"date": "2019-02-25 11:17:36", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-03-19 10:47:3", "user": "209", "prev_value": {"reg_date": "2019-01-15", "visa_expired_date": "2019-03-23"}}, {"date": "2019-04-19 11:0:10", "user": "209", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-19 11:0:42", "user": "209", "prev_value": {"reg_date": "2019-02-22", "visa_expired_date": "2019-04-23"}}, {"date": "2019-05-20 13:26:39", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-23"}}, {"date": "2019-05-20 13:27:18", "user": "209", "prev_value": {"reg_date": "2019-03-19"}}, {"date": "2019-06-07 10:29:15", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-06-07 10:29:40", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-06-07 10:31:20", "user": "209", "prev_value": {"reg_date": "2019-04-19"}}]	1986-10-06	2015-09-17	2025-09-16	\N	\N	2018-11-23	2018-11-23	2019-11-23	2019-06-23	2018-11-13	\N	\N	\N	\N	2018-10-17	2018-10-17	2019-05-22	\N	209	0	692701670057	4	2	2	0	2	0	\N	\N
106	AN4101442	ТОХТАМИРЗАЕВ	ИСМАИЛХОДЖА	115	6	[2, 3, 4]	MALE														4118	0183642	РОЗУБАЕВИЧ					МКК 50-43			КЫРГЫЗСТАН		[{"date": "2019-01-09 11:55:50", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-06-13 10:58:10", "user": "209", "prev_value": {"status_id": "FIRED"}}, {"date": "2019-06-13 10:58:53", "user": "209", "prev_value": {"status_id": "WORKER"}}]	1998-07-21	2015-03-02	2025-03-02	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2018-11-24	2018-11-24	2018-11-30	\N	0	0	0	4	12	2	0	0	0	\N	\N
107	AC2649184	ЗАЙНАБИДИНОВ	ИСОМИДДИН	115	6	[2, 3, 4]	MALE														5318	0520366						ГОСУДАРСТВЕННАЯ РЕГИСТРАЦИОННАЯ СЛУЖБА			КЫРГЫЗСКАЯ РЕСПУБЛИКА		[{"date": "2019-01-09 12:11:26", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-04-16 9:18:0", "user": "207", "prev_value": {"citizenship_id": ""}}]	1998-06-25	2015-12-09	2025-12-09	\N	\N	\N	\N	2019-12-06	\N	\N	\N	\N	\N	\N	2018-11-27	2018-11-27	\N	\N	0	0	0	4	2	2	0	0	0	\N	\N
108	AA5744125	БУРХАНОВА	ГУЛАСАРХОН	229	6	[3, 2, 4]	FEMALE						69	1900001707							4618	3095943	ПУЛАТБОЕВНА				ДОМОДЕВО 347	1-отдел милиции города Андижан Андижанской области			ГОРОД АНДИЖАН		[{"date": "2019-01-22 14:50:24", "user": "209", "prev_value": {"work_permit_expired_date": "2019-01-15"}}, {"date": "2019-03-12 13:17:37", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-03-12 13:18:49", "user": "209", "prev_value": {"reg_date": "2018-12-11"}}, {"date": "2019-03-24 20:59:51", "user": "214", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-03-25 12:50:19", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-03-25 12:50:28", "user": "209", "prev_value": {"departure_date": "2019-03-22"}}, {"date": "2019-06-05 12:28:31", "user": "209", "prev_value": {"work_permit_expired_date": "2020-01-15", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-06-05 12:28:40", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-06-05 12:31:58", "user": "209", "prev_value": {"reg_date": "2019-03-05", "status_id": "WORKER", "entry_date": "2018-12-08", "departure_date": "2019-03-24", "migr_card_serie": "4518", "entry_checkpoint": "", "migr_card_number": "1074156", "visa_expired_date": "2019-04-16", "migr_card_issued_date": "2018-12-08"}}, {"date": "2019-06-05 12:38:28", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-06-17 10:44:29", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-16"}}, {"date": "2019-06-17 10:44:48", "user": "209", "prev_value": {"visa_expired_date": "2019-08-13"}}, {"date": "2019-06-28 11:7:38", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-07-16 10:36:27", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-16"}}, {"date": "2019-07-16 10:36:38", "user": "209", "prev_value": {"visa_expired_date": "2019-07-16"}}, {"date": "2019-08-07 13:31:20", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-16"}}, {"date": "2019-08-07 13:31:37", "user": "209", "prev_value": {"reg_date": "2019-06-13"}}, {"date": "2019-08-07 14:0:56", "user": "209", "prev_value": {"visa_expired_date": "2019-08-16"}}, {"date": "2019-08-26 11:8:0", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-08-26 11:8:15", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-08-26 11:8:36", "user": "209", "prev_value": {"reg_date": "2019-07-09", "visa_expired_date": "2019-09-16"}}]	1970-02-20	2014-06-13	2024-06-12	\N	\N	2019-01-16	2019-01-16	2020-01-16	2019-09-16	2017-02-03	\N	\N	\N	\N	2019-05-16	2019-05-16	2019-08-08	\N	229	0	331604730009	7	2	2	0	2	0	\N	\N
109	AB4356912	УМУРЗАКОВА	САИДАХОН	229	2	[3, 4, 2]	FEMALE														4518	1074160											[{"date": "2019-01-14 13:42:52", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1991-06-06	2016-07-05	2026-07-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2018-12-08	2018-12-08	\N	2018-12-28	229	0	0	7	2	2	0	0	0	\N	\N
110	AA1199223	СОДИКОВА	ЖАМИЛАХОН	229	6	[2, 3, 4]	FEMALE						69	1900001841							4518	1074153	ТУРСУНОВНА					ОВД Алтынкульского района Андижанской области			АНДИЖАН		[{"date": "2019-01-22 14:8:43", "user": "209", "prev_value": {"work_permit_expired_date": "2020-01-16"}}, {"date": "2019-03-12 13:16:48", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-04-11 10:14:34", "user": "209", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-11 10:15:17", "user": "209", "prev_value": {"reg_date": "2018-12-11"}}, {"date": "2019-04-15 10:5:26", "user": "209", "prev_value": {"visa_expired_date": "2019-04-16"}}, {"date": "2019-06-07 12:26:46", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-16"}}, {"date": "2019-06-07 12:27:44", "user": "209", "prev_value": {"reg_date": "2019-04-12"}}, {"date": "2019-06-17 10:46:56", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-16"}}, {"date": "2019-06-17 10:47:8", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-02 11:27:48", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-02 11:28:17", "user": "209", "prev_value": {"reg_date": "2019-04-26"}}, {"date": "2019-07-02 11:28:34", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1988-06-04	2013-04-09	2023-04-08	\N	\N	2019-01-16	2019-01-16	2020-01-15	2019-07-16	\N	\N	\N	\N	2019-07-16	2018-12-08	2018-12-08	2019-06-13	\N	229	0	0	7	2	2	0	2	0	\N	\N
111	AA0703876	БУРХОНОВ	АДХАМЖОН	229	6	[2, 3, 4]	MALE						69	1900001714							4518	1075606	СУЛТОНОВИЧ				ВНУКОВО 228	Андижанский 1-городской отдел милиции Андижанской области			ГОРОД АНДИЖАН		[{"date": "2019-01-22 14:44:54", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-03-12 13:32:27", "user": "209", "prev_value": {"reg_date": "2018-12-11", "visa_expired_date": "-0001-11-30"}}, {"date": "2019-04-11 11:14:19", "user": "209", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-11 11:15:27", "user": "209", "prev_value": {"reg_date": "2019-03-05", "entry_checkpoint": "", "visa_expired_date": "2019-04-16"}}, {"date": "2019-06-07 11:40:2", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-06-07 11:40:44", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-16"}}, {"date": "2019-06-07 11:41:27", "user": "209", "prev_value": {"reg_date": "2019-04-12"}}, {"date": "2019-07-09 14:7:5", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1968-02-03	2013-01-19	2023-01-18	\N	\N	2019-01-16	2019-01-16	2020-01-15	2019-06-16	2018-12-18	\N	\N	\N	\N	2018-12-08	2018-12-08	2019-06-26	\N	229	0	692701671406	7	2	2	0	2	0	\N	\N
112	C6397660	НГУЕН 	ТОАН ЧУНГ	232	6	[3, 4, 2]	MALE						69	1900002490	202402326	003124835	SINGLE	WORK	23	8999413	4619	6323384		NGUYEN	TOAN TRUNG		Шереметьево 825	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ХАНОЙ		[{"date": "2019-02-19 12:54:28", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-12 22:46:54", "user": "214", "prev_value": {"reg_date": "2019-01-29", "birth_date": "1990-06-28", "entry_date": "2019-01-28", "hired_date": "2019-02-19", "departure_date": "-0001-11-30", "cert_issued_date": "2010-06-30", "visa_issued_date": "2019-01-24", "visa_expired_date": "2019-04-17", "visa_started_date": "2019-01-24", "passport_issued_date": "2018-11-22", "migr_card_issued_date": "2019-01-28", "passport_expired_date": "2028-11-22", "work_permit_issued_date": "2019-02-08", "work_permit_expired_date": "2019-04-17", "work_permit_started_date": "2019-02-08"}}, {"date": "2019-03-13 13:25:12", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "visa_issued_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-13 13:28:19", "user": "209", "prev_value": {"birth_date": "-0001-11-30", "passport_issued_date": "-0001-11-30", "passport_expired_date": "-0001-11-30"}}, {"date": "2019-03-13 13:30:48", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "hired_date": "-0001-11-30", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-13 13:31:1", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-03-13 13:37:50", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "departure_date": "2019-03-13", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-13 16:13:55", "user": "214", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-03-13 16:30:0", "user": "208", "prev_value": {"cert_issued_date": "-0001-11-30"}}, {"date": "2019-03-13 16:34:24", "user": "214", "prev_value": {"departure_date": "2019-03-13"}}, {"date": "2019-03-13 16:35:4", "user": "214", "prev_value": {"departure_date": "-0001-11-30"}}]	1990-06-28	2018-11-22	2028-11-22	\N	\N	2019-02-08	2019-02-08	2019-12-01	\N	\N	2010-06-30	2019-01-24	2019-01-24	2019-04-17	2019-01-28	2019-01-28	2019-01-29	2019-03-13	232	31	0	4	2	2	0	2	0	\N	\N
113	C5972751	ВУ	ХЫУ ХУАН	232	6	[2, 3, 4]	MALE						69	1900002475	202402324	011484	SINGLE	WORK	12	1560238	4619	6323383		VU	HUU HUAN		Шереметьево 825	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		ЧАСТНОЕ ПТУ "ЗУИТУАН"	БАКНИНЬ		[{"date": "2019-02-19 12:48:35", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-04-11 12:32:53", "user": "209", "prev_value": {"reg_date": "2019-01-29", "visa_serie": "23", "visa_number": "8999224", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2019-01-24", "visa_expired_date": "2019-04-17", "visa_started_date": "2019-01-24"}}, {"date": "2019-11-06 13:12:44", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-06 13:13:41", "user": "209", "prev_value": {"reg_date": "2019-04-12"}}, {"date": "2019-12-03 23:52:56", "user": "207", "prev_value": {"fired_date": "-0001-11-30"}}]	1998-11-02	2018-09-14	2028-09-14	\N	\N	2019-02-08	2019-02-08	2019-12-01	\N	\N	2016-07-04	2019-03-26	2019-04-18	2019-12-01	2019-01-28	2019-01-28	2019-04-17	\N	232	31	0	4	2	2	0	2	0	\N	\N
114	B9603571	НГУЕН	ВАН ШОН	232	8	[3, 4, 2]	MALE								202402325	003125022	SINGLE	WORK	23	8999225	4619	6323385		NGUYEN	VAN SON		Шереметьево 825	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	НГЕАН		[{"date": "2019-02-19 12:44:4", "user": "209", "prev_value": {"departure_date": "-0001-11-30"}}]	1983-10-22	2014-09-23	2024-09-23	\N	\N	\N	\N	2019-04-17	\N	\N	2011-06-30	2019-01-24	2019-01-24	2019-04-17	2019-01-28	2019-01-28	2019-01-29	2019-02-19	232	31	0	4	2	2	0	0	0	\N	\N
115	AA7438786	АБДУРАХМОНОВА	ОДИНАХОН	229	6	[3, 4, 2]	FEMALE						69	1900001601							4518	1081209						ОВД Булакбашинского района Андижанской области			ГОРОД АНДИЖАН		[{"date": "2019-01-22 14:56:46", "user": "209", "prev_value": {"work_permit_expired_date": "2019-01-15"}}, {"date": "2019-03-01 14:42:18", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-03-01 14:44:34", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1984-10-19	2014-11-03	2024-11-02	\N	\N	2019-01-16	2019-01-16	2020-01-15	\N	2018-12-19	\N	\N	\N	\N	2018-12-08	2018-12-08	2018-12-11	\N	229	0	692701671646	7	2	2	0	2	0	\N	\N
116	C6377062	ДО	ЧЫОНГ ЗАНГ	232	2	[3, 2, 4]	MALE									003124838								DO	TRUONG GIANG			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	НИНЬБИНЬ		[{"date": "2018-12-24 11:6:54", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-09-11 14:31:3", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1978-01-06	2018-11-28	2028-11-28	\N	\N	\N	\N	\N	\N	\N	2010-06-30	\N	\N	\N	\N	\N	\N	\N	232	31	0	4	2	2	0	0	0	\N	\N
117	C6377065	НГУЕН	ТХИ ТУ	232	2	[3, 2, 4]	FEMALE																	NGUYEN	THI TU			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			НИНЬБИНЬ		[{"date": "2018-12-24 11:7:22", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "employ_permit_id": ""}}, {"date": "2019-09-11 14:31:12", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1984-04-04	2018-11-28	2028-11-28	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	31	0	4	2	2	0	0	0	\N	\N
118	AA2539987	ХАМДАМХУЖАЕВ	АХМАДУЛЛО	229	6	[3, 2, 4]	MALE						69	1900008082							4519	0143134					ВНУКОВО 241	Государственный центр персонализации			Андижанская область		[{"date": "2019-02-14 17:4:38", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-14"}}, {"date": "2019-04-01 17:8:54", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-09 10:33:13", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-04", "work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-04-09 10:33:26", "user": "209", "prev_value": {"reg_date": "2019-01-06"}}, {"date": "2019-06-07 12:46:29", "user": "209", "prev_value": {"reg_date": "2019-04-03"}}, {"date": "2019-06-13 9:33:24", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-12"}}, {"date": "2019-06-13 9:33:36", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-16 10:37:43", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-12"}}, {"date": "2019-07-16 10:37:52", "user": "209", "prev_value": {"visa_expired_date": "2019-07-12"}}, {"date": "2019-08-09 9:12:52", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-08-09 9:13:9", "user": "209", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-09-10 13:10:29", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-12"}}, {"date": "2019-09-17 15:0:36", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-09-17 15:0:54", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-09-17 15:1:40", "user": "209", "prev_value": {"reg_date": "2019-04-26", "visa_expired_date": "2019-08-12"}}]	1996-11-14	2013-08-10	2023-08-09	\N	\N	2019-02-12	2019-02-12	2020-02-12	2019-09-12	\N	\N	\N	\N	\N	2019-01-05	2019-01-05	2019-07-10	2019-08-09	229	0	0	7	2	2	0	2	0	\N	\N
119	AA4166311	ТОШМАТОВА	ОКИТАХОН	229	6	[2, 3, 4]	FEMALE						69	1900009167							4519	0123649					ВНУКОВО 254	Государственный центр персонализации			Андижанская область		[{"date": "2019-02-19 14:1:34", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-04-01 17:8:38", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-09 10:53:33", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-04-09 10:53:43", "user": "209", "prev_value": {"reg_date": "2019-01-06"}}, {"date": "2019-06-07 12:43:45", "user": "209", "prev_value": {"reg_date": "2019-04-03"}}, {"date": "2019-06-17 10:46:11", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-14"}}, {"date": "2019-06-17 10:46:27", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-16 11:23:42", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-16 11:25:30", "user": "209", "prev_value": {"reg_date": "2019-04-26", "visa_expired_date": "2019-07-14"}}, {"date": "2019-07-16 11:26:28", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1966-08-16	2014-02-05	2024-02-04	\N	\N	2019-02-14	2019-02-14	2020-02-14	2019-07-14	\N	\N	\N	\N	\N	2019-01-05	2019-01-05	2019-06-13	\N	229	0	0	7	2	2	0	2	0	\N	\N
120	AB7935777	АШУРАЛИЕВ	АЛИШЕР	229	6	[3, 4, 2]	MALE						69	1900007890							4519	0143130					ВНУКОВО 241	Государственный центр персонализации			УЗБЕКИСТАН		[{"date": "2019-02-14 16:38:40", "user": "209", "prev_value": {"work_permit_expired_date": "2020-02-12"}}, {"date": "2019-03-12 11:59:15", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}]	1999-04-14	2017-10-20	2027-10-19	\N	\N	2019-02-12	2019-02-12	2019-04-04	\N	\N	\N	\N	\N	\N	2019-01-05	2019-01-05	2019-01-06	\N	229	0	0	7	2	2	0	2	0	\N	\N
121	AB4226252	БЕГИЖОНОВА	МАВЛУДА	229	6	[3, 2, 4]	FEMALE						69	1900007924							4519	0111489					ВНУКОВО 237	Государственный центр персонализации			Андижанская область		[{"date": "2019-02-14 16:57:17", "user": "209", "prev_value": {"work_permit_expired_date": "2019-02-12"}}, {"date": "2019-04-01 17:6:9", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-09 10:23:8", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-04", "work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-04-09 10:23:35", "user": "209", "prev_value": {"migr_card_issued_date": "2019-01-05"}}, {"date": "2019-04-25 11:3:35", "user": "209", "prev_value": {"reg_date": "2019-01-06"}}, {"date": "2019-06-07 12:33:50", "user": "209", "prev_value": {"reg_date": "2019-04-03"}}, {"date": "2019-06-13 9:28:0", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-12"}}, {"date": "2019-06-13 9:28:16", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-06-13 9:29:12", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-12"}}, {"date": "2019-06-13 9:29:21", "user": "209", "prev_value": {"visa_expired_date": "2019-06-12"}}, {"date": "2019-07-16 10:37:1", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-12"}}, {"date": "2019-07-16 10:37:8", "user": "209", "prev_value": {"visa_expired_date": "2019-07-12"}}, {"date": "2019-08-07 14:1:8", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-12"}}, {"date": "2019-08-07 14:1:40", "user": "209", "prev_value": {"reg_date": "2019-04-26", "visa_expired_date": "2019-08-12"}}, {"date": "2019-08-26 10:43:29", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-08-26 10:43:45", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-08-26 10:44:23", "user": "209", "prev_value": {"reg_date": "2019-07-09", "visa_expired_date": "2019-09-12"}}, {"date": "2019-08-26 11:45:15", "user": "209", "prev_value": {"migr_card_issued_date": "2019-04-03"}}]	1998-07-28	2016-06-22	2026-06-21	\N	\N	2019-02-12	2019-02-12	2020-02-12	2019-09-12	\N	\N	\N	\N	\N	2019-01-05	2019-01-05	2019-08-08	\N	229	0	0	7	2	2	0	2	0	\N	\N
122	AB6790709	НОМОЗОВА	НАРГИЗАХОН	229	6	[3, 2, 4]	FEMALE						69	1900009142							4519	0111490	СОЛИЕВНА				ВНУКОВО 237	ОВД Андижанского района Андижанской области 			Андижанский район		[{"date": "2019-02-19 13:47:59", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-04-01 17:7:2", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-09 10:52:24", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-04-09 10:52:35", "user": "209", "prev_value": {"reg_date": "2019-01-06"}}, {"date": "2019-04-09 10:52:57", "user": "209", "prev_value": {"hired_date": "2019-02-19"}}, {"date": "2019-04-12 14:35:6", "user": "209", "prev_value": {"hired_date": "2019-05-19"}}, {"date": "2019-06-07 12:42:14", "user": "209", "prev_value": {"reg_date": "2019-04-03"}}, {"date": "2019-06-10 10:45:55", "user": "209", "prev_value": {"birth_place": "УЗБЕКИСТАН"}}, {"date": "2019-06-13 11:16:37", "user": "209", "prev_value": {"birth_place": "Андижанская район"}}, {"date": "2019-06-17 10:47:41", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-02-14"}}, {"date": "2019-06-17 10:48:6", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-16 10:33:37", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-14"}}, {"date": "2019-07-16 10:34:7", "user": "209", "prev_value": {"reg_date": "2019-04-26", "visa_expired_date": "2019-07-14"}}, {"date": "2019-08-07 16:15:22", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-14"}}, {"date": "2019-08-07 16:15:38", "user": "209", "prev_value": {"visa_expired_date": "2019-08-14"}}, {"date": "2019-08-26 11:21:55", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-08-26 11:22:8", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-08-26 11:22:53", "user": "209", "prev_value": {"reg_date": "2019-07-09", "visa_expired_date": "2019-09-14"}}]	1975-08-13	2017-05-25	2027-05-25	\N	\N	2019-02-14	2019-02-14	2020-02-14	2019-09-14	\N	\N	\N	\N	\N	2019-01-05	2019-01-05	2019-08-08	\N	229	0	0	7	2	2	0	2	0	\N	\N
123	AB3834393	БАЗАРОВА	ХУРИЯТХОН	229	6	[3, 2, 4]	FEMALE						69	1900007917							4519	0143129					ВНУКОВО 241	Государственный центр персонализации			Андижанская область		[{"date": "2019-02-14 16:56:48", "user": "209", "prev_value": {"work_permit_expired_date": "2020-02-12", "work_permit_started_date": "2019-04-04"}}, {"date": "2019-04-01 17:5:57", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-09 10:20:6", "user": "209", "prev_value": {"work_permit_started_date": "2019-02-12", "work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-04-09 10:20:55", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-04"}}, {"date": "2019-04-09 10:22:26", "user": "209", "prev_value": {"reg_date": "2019-01-06"}}, {"date": "2019-06-07 12:31:36", "user": "209", "prev_value": {"reg_date": "2019-04-03"}}, {"date": "2019-06-13 9:30:4", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-12"}}, {"date": "2019-06-13 9:30:16", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-16 10:35:49", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-12"}}, {"date": "2019-07-16 10:36:9", "user": "209", "prev_value": {"reg_date": "2019-05-08", "visa_expired_date": "2019-07-12"}}, {"date": "2019-08-07 15:38:29", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-12"}}, {"date": "2019-08-07 15:38:50", "user": "209", "prev_value": {"visa_expired_date": "2019-08-12"}}, {"date": "2019-09-10 13:7:0", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-12"}}, {"date": "2019-09-10 13:7:25", "user": "209", "prev_value": {"reg_date": "2019-07-09", "visa_expired_date": "2019-09-12"}}, {"date": "2019-10-04 12:9:19", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-10-12"}}, {"date": "2019-10-04 12:9:37", "user": "209", "prev_value": {"reg_date": "2019-09-05"}}, {"date": "2019-10-07 12:52:18", "user": "209", "prev_value": {"visa_expired_date": "2019-10-12"}}, {"date": "2019-10-29 14:15:22", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-11-12"}}, {"date": "2019-10-29 14:15:30", "user": "209", "prev_value": {"visa_expired_date": "2019-11-12"}}, {"date": "2019-12-04 16:8:59", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-12-12"}}, {"date": "2019-12-04 16:9:30", "user": "209", "prev_value": {"reg_date": "2019-10-03", "visa_expired_date": "2019-12-12"}}, {"date": "2019-12-04 16:9:41", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-01-12"}}, {"date": "2019-12-24 16:9:8", "user": "209", "prev_value": {"visa_expired_date": "2020-01-12", "current_passport_number": "", "work_permit_paid_till_date": "2020-01-12"}}, {"date": "2020-02-11 15:29:2", "user": "209", "prev_value": {"work_address_id": "", "current_passport_number": "", "work_permit_issued_date": "2019-02-12", "work_permit_expired_date": "2020-02-12", "work_permit_started_date": "2019-04-04", "work_permit_paid_till_date": "2020-02-12"}}, {"date": "2020-02-11 15:30:46", "user": "209", "prev_value": {"reg_date": "2019-10-29", "visa_expired_date": "2020-02-12", "current_passport_number": ""}}, {"date": "2020-02-11 15:32:25", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-03-18 12:54:45", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-03-13"}}, {"date": "2020-03-18 12:55:8", "user": "209", "prev_value": {"reg_date": "2020-02-11", "visa_expired_date": "2020-03-12"}}, {"date": "2020-04-07 11:53:57", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-04-12"}}, {"date": "2020-04-07 13:23:2", "user": "209", "prev_value": {"visa_expired_date": "2020-04-12"}}, {"date": "2020-04-27 13:43:33", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-05-12"}}, {"date": "2020-04-27 13:43:58", "user": "209", "prev_value": {"reg_date": "2020-03-04", "visa_expired_date": "2020-05-12"}}, {"date": "2020-06-01 11:14:1", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-06-12"}}, {"date": "2020-06-01 11:14:55", "user": "209", "prev_value": {"reg_date": "2020-04-09", "visa_expired_date": "2020-06-12"}}, {"date": "2020-07-08 14:28:2", "user": "209", "prev_value": {"reg_date": "2020-04-28"}}, {"date": "2020-07-08 14:29:58", "user": "209", "prev_value": {"fired_date": null}}, {"date": "2020-07-08 14:30:10", "user": "209", "prev_value": {"status_id": "WORKER"}}]	1988-09-01	2016-05-04	2026-05-03	\N	\N	2020-02-13	2020-02-13	2021-02-13	2020-07-13	\N	\N	\N	\N	2020-07-13	2019-01-05	2019-01-05	2020-06-10	\N	229	0	0	7	2	2	0	2	0	\N	\N
124	AB9449631	БАЗАРОВА	МИНГАЙИМХОН	229	6	[2, 3, 4]	FEMALE						69	1900007900							4519	0111487					ВНУКОВО 237	Государственный центр персонализации			Андижанская область		[{"date": "2019-02-14 16:39:27", "user": "209", "prev_value": {"work_permit_expired_date": "2020-02-12"}}, {"date": "2019-04-01 17:5:27", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-03 12:54:9", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-04-08 12:14:56", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-04-08 12:15:15", "user": "209", "prev_value": {"fired_date": "2019-04-03"}}]	1983-11-19	2018-05-01	2028-04-30	\N	\N	2019-02-12	2019-02-12	2019-04-04	2019-04-04	\N	\N	\N	\N	\N	2019-01-05	2019-01-05	2019-01-06	\N	229	0	0	7	2	2	0	2	0	\N	\N
125	AC3189470	ТОКТАМИРЗАЕВ	АДИЛЖАН	115	6	[3, 2, 4]	MALE														4618	6459115					РАМЕНСКОЕ 097	ГОСУДАРСТВЕННАЯ РЕГИСТРАЦИОННАЯ СЛУЖБА			КЫРГЫЗСКАЯ РЕСПУБЛИКА		[{"date": "2019-01-14 13:50:41", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-05-16 14:6:0", "user": "209", "prev_value": {"status_id": "WORKER", "departure_date": "-0001-11-30"}}, {"date": "2019-06-13 10:3:17", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-06-13 10:57:56", "user": "209", "prev_value": {"reg_date": "2019-01-06", "entry_date": "2019-01-05", "departure_date": "2019-05-17", "entry_checkpoint": "ДОМОДЕВО 1446", "migr_card_number": "2417589", "migr_card_issued_date": "2019-01-05"}}, {"date": "2020-01-21 14:29:40", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-21 14:29:48", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}, {"date": "2020-01-21 14:30:15", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-21 15:5:17", "user": "209", "prev_value": {"passport_issuer": "", "current_passport_number": ""}}]	1989-12-21	2018-02-20	2028-02-20	\N	\N	\N	\N	2020-01-13	\N	\N	\N	\N	\N	\N	2019-06-11	2019-06-11	2019-06-13	\N	115	0	0	7	2	2	0	0	0	\N	\N
126	AA7715349	КАМАЛОВА	ШАХНОЗАХОН	229	6	[3, 2, 4]	FEMALE						69	1900007995							4519	0123653	КАХРАМАНЖАНОВНА				ВНУКОВО 254	Андижанский 2-городской отдел милиции Андижанской области			УЗБЕКИСТАН		[{"date": "2019-02-14 16:58:29", "user": "209", "prev_value": {"work_permit_expired_date": "2020-02-12"}}, {"date": "2019-04-01 17:6:28", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-09 10:24:49", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-04", "work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-04-09 10:25:18", "user": "209", "prev_value": {"reg_date": "2019-01-09"}}, {"date": "2019-06-07 12:21:46", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-12"}}, {"date": "2019-06-07 12:22:7", "user": "209", "prev_value": {"reg_date": "2019-04-03"}}, {"date": "2019-06-10 10:36:54", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-06-13 9:36:22", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-12"}}, {"date": "2019-07-02 11:32:37", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-02 11:32:49", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-07-02 11:33:13", "user": "209", "prev_value": {"reg_date": "2019-04-26"}}, {"date": "2019-09-06 12:33:19", "user": "209", "prev_value": {"visa_expired_date": "2019-07-12"}}]	1982-11-04	2014-11-26	2024-11-25	\N	\N	2019-02-12	2019-02-12	2020-02-12	2019-07-12	\N	\N	\N	\N	\N	2019-01-05	2019-01-05	2019-06-11	\N	229	0	0	7	2	2	0	2	0	\N	\N
127	AA7084618	КАМБАРОВА	ШАХНОЗАХОН	229	6	[3, 2, 4]	FEMALE						69	1900008004							4519	0143132					ВНУКОВО 241	Государственный центр персонализации			Андижанская область		[{"date": "2019-02-14 16:59:36", "user": "209", "prev_value": {"work_permit_expired_date": "2020-02-12"}}, {"date": "2019-04-01 17:6:38", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-09 10:27:17", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-04", "work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-04-09 10:27:54", "user": "209", "prev_value": {"reg_date": "2019-01-09"}}, {"date": "2019-04-25 11:7:14", "user": "209", "prev_value": {"birth_place": "УЗБЕКИСТАН"}}, {"date": "2019-06-07 12:36:20", "user": "209", "prev_value": {"reg_date": "2019-04-03"}}, {"date": "2019-06-13 9:28:36", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-12"}}, {"date": "2019-06-13 9:28:56", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-06-13 9:29:38", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-12"}}, {"date": "2019-07-16 10:35:12", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-12"}}, {"date": "2019-07-16 10:35:30", "user": "209", "prev_value": {"reg_date": "2019-04-26", "visa_expired_date": "2019-07-12"}}, {"date": "2019-08-07 14:45:58", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-12"}}, {"date": "2019-08-07 14:46:5", "user": "209", "prev_value": {"visa_expired_date": "2019-08-12"}}, {"date": "2019-09-10 13:8:30", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-12"}}, {"date": "2019-09-10 13:8:50", "user": "209", "prev_value": {"reg_date": "2019-07-09", "visa_expired_date": "2019-09-12"}}, {"date": "2019-10-04 12:7:48", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-10-12"}}, {"date": "2019-10-04 12:8:10", "user": "209", "prev_value": {"reg_date": "2019-09-05"}}, {"date": "2019-10-04 13:17:13", "user": "209", "prev_value": {"visa_expired_date": "2019-10-12"}}, {"date": "2019-10-29 14:16:48", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-11-12"}}, {"date": "2019-10-29 14:16:58", "user": "209", "prev_value": {"visa_expired_date": "2019-11-12"}}, {"date": "2019-12-04 16:6:22", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-12-12"}}, {"date": "2019-12-04 16:6:43", "user": "209", "prev_value": {"reg_date": "2019-10-03", "visa_expired_date": "2019-12-12"}}, {"date": "2019-12-04 16:11:27", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-01-12"}}, {"date": "2019-12-04 16:15:51", "user": "209", "prev_value": {"visa_expired_date": "2019-01-12"}}, {"date": "2019-12-24 16:23:27", "user": "209", "prev_value": {"current_passport_number": "", "work_permit_paid_till_date": "2020-01-12"}}, {"date": "2020-01-09 20:0:20", "user": "209", "prev_value": {"visa_expired_date": "2020-01-12", "current_passport_number": ""}}, {"date": "2020-02-11 15:33:38", "user": "209", "prev_value": {"work_address_id": "", "current_passport_number": "", "work_permit_issued_date": "2019-02-12", "work_permit_expired_date": "2020-02-12", "work_permit_started_date": "2019-02-12", "work_permit_paid_till_date": "2020-02-12"}}, {"date": "2020-02-11 15:34:17", "user": "209", "prev_value": {"reg_date": "2019-10-29", "current_passport_number": ""}}, {"date": "2020-02-25 11:2:4", "user": "209", "prev_value": {"current_passport_number": "", "work_permit_issued_date": "2020-02-13"}}, {"date": "2020-02-25 11:3:52", "user": "209", "prev_value": {"visa_expired_date": "2020-02-12", "current_passport_number": ""}}, {"date": "2020-03-18 12:52:57", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-03-13"}}, {"date": "2020-03-18 12:53:59", "user": "209", "prev_value": {"reg_date": "2020-02-11", "visa_expired_date": "2020-03-12"}}, {"date": "2020-04-07 13:23:32", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-04-12"}}, {"date": "2020-04-07 13:23:46", "user": "209", "prev_value": {"visa_expired_date": "2020-04-12"}}, {"date": "2020-04-27 13:38:11", "user": "209", "prev_value": {"reg_date": "2020-03-04"}}, {"date": "2020-06-01 11:19:1", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-05-12"}}, {"date": "2020-06-01 11:19:45", "user": "209", "prev_value": {"reg_date": "2020-04-09", "visa_expired_date": "2020-05-12"}}, {"date": "2020-07-08 15:4:56", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2020-07-08 15:5:19", "user": "209", "prev_value": {"reg_date": "2020-04-28"}}]	1987-11-30	2014-09-26	2024-09-25	\N	\N	2020-03-13	2020-02-13	2021-02-13	2020-07-13	\N	\N	\N	\N	2020-07-13	2019-01-05	2019-01-05	2020-06-10	\N	229	0	0	7	2	2	0	2	0	\N	\N
128	AC0653435	САМСАКОВА	ФЕРУЗАХОН	229	6	[2, 3, 4]	FEMALE						69	1900008043							4519	0143133					ВНУКОВО 241	Государственный центр персонализации			Андижанская область		[{"date": "2019-02-14 17:3:26", "user": "209", "prev_value": {"work_permit_expired_date": "2020-02-12"}}, {"date": "2019-04-01 17:7:13", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-09 10:31:36", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-04", "work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-04-09 10:31:50", "user": "209", "prev_value": {"reg_date": "2018-01-09"}}, {"date": "2019-06-07 12:40:10", "user": "209", "prev_value": {"reg_date": "2019-04-03"}}, {"date": "2019-06-13 9:33:55", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-12"}}, {"date": "2019-06-13 9:34:11", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-03 12:5:13", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-03 12:5:28", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-07-03 13:40:44", "user": "209", "prev_value": {"reg_date": "2019-04-26"}}, {"date": "2019-07-08 11:35:42", "user": "209", "prev_value": {"status_id": "FIRED"}}, {"date": "2019-07-08 11:35:52", "user": "209", "prev_value": {"fired_date": "2019-07-04"}}, {"date": "2019-07-31 10:20:20", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-31 10:20:33", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1974-12-11	2018-08-11	2028-08-10	\N	\N	2019-02-12	2019-02-12	2020-02-12	2019-07-12	\N	\N	\N	\N	2019-07-12	2019-01-05	2019-01-05	2019-06-11	\N	229	0	0	7	2	2	0	2	0	\N	\N
129	AB7833993	МАТЯКУБОВА	МУКАДДАСХОН	229	6	[2, 3, 4]	FEMALE						69	1900008029							4519	0123654					ВНУКОВО 254	Государственный центр персонализации			Андижанская область		[{"date": "2019-02-14 17:0:50", "user": "209", "prev_value": {"work_permit_expired_date": "2020-02-12"}}, {"date": "2019-04-01 17:6:50", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-09 10:29:56", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-04", "work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-04-09 10:30:10", "user": "209", "prev_value": {"reg_date": "2019-01-09"}}, {"date": "2019-06-07 12:38:25", "user": "209", "prev_value": {"reg_date": "2019-04-03", "work_permit_paid_till_date": "2019-05-12"}}, {"date": "2019-06-13 9:35:45", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-12"}}, {"date": "2019-06-13 9:36:1", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-02 11:20:23", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-02 11:22:31", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-07-03 13:47:5", "user": "209", "prev_value": {"work_permit_issued_date": "2018-02-12", "work_permit_started_date": "2018-02-12"}}]	1976-08-01	2017-10-03	2027-10-02	\N	\N	2019-02-12	2019-02-12	2020-02-12	2019-07-12	\N	\N	\N	\N	2019-07-12	2019-01-05	2019-01-05	2019-04-26	\N	229	0	0	7	2	2	0	2	0	\N	\N
130	402034502	СОБИРОВА	ЗАМИРА 	209	6	[3, 2, 4]	FEMALE						69	1900007530							4618	6573094	ЧУРАЕВНА				РАМЕНСКОЕ 042	ОВД В ХУДЖАНДЕ					[{"date": "2019-02-13 12:56:47", "user": "209", "prev_value": {"contract_number": ""}}, {"date": "2019-04-24 12:5:41", "user": "209", "prev_value": {"reg_date": "2019-01-15"}}, {"date": "2019-06-03 14:3:57", "user": "209", "prev_value": {"birth_place": "ТАДЖИКИСТАН"}}, {"date": "2019-06-03 14:4:46", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-10", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-06-03 14:5:15", "user": "209", "prev_value": {"reg_date": "2019-04-09", "visa_expired_date": "2019-04-10"}}, {"date": "2019-06-07 10:8:16", "user": "209", "prev_value": {"visa_expired_date": "2019-06-11"}}, {"date": "2019-07-03 14:55:57", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-11"}}, {"date": "2019-07-03 15:13:27", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-11"}}, {"date": "2019-07-03 15:15:7", "user": "209", "prev_value": {"reg_date": "2019-05-07", "visa_expired_date": "2019-07-11"}}, {"date": "2019-07-16 10:47:15", "user": "209", "prev_value": {"reg_date": "2019-06-05"}}, {"date": "2019-07-31 12:50:58", "user": "209", "prev_value": {"visa_expired_date": "2019-08-11"}}, {"date": "2019-07-31 12:51:15", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-11"}}, {"date": "2019-08-27 12:42:57", "user": "209", "prev_value": {"reg_date": "2019-07-04"}}, {"date": "2019-09-10 13:27:28", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-11"}}, {"date": "2019-09-10 13:28:21", "user": "209", "prev_value": {"reg_date": "2019-07-31", "visa_expired_date": "2019-09-11"}}, {"date": "2019-10-04 11:53:13", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-10-11"}}, {"date": "2019-10-04 11:53:32", "user": "209", "prev_value": {"reg_date": "2019-09-03"}}, {"date": "2019-10-07 11:1:35", "user": "209", "prev_value": {"visa_expired_date": "2019-10-11"}}, {"date": "2019-10-14 12:36:51", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-10-14 12:37:10", "user": "209", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-10-23 11:8:38", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-10-23 11:10:40", "user": "209", "prev_value": {"reg_date": "2019-09-25", "entry_date": "2019-01-11", "departure_date": "2019-10-11", "entry_checkpoint": "РАМЕНСКОЕ 059", "migr_card_number": "6304853", "migr_card_issued_date": "2019-01-11"}}, {"date": "2019-10-29 13:53:36", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-11-11"}}, {"date": "2019-10-29 13:54:0", "user": "209", "prev_value": {"visa_expired_date": "2019-11-11"}}, {"date": "2019-12-04 15:41:41", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-12-11"}}, {"date": "2019-12-04 15:42:15", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "visa_expired_date": "2019-12-11"}}, {"date": "2019-12-04 16:13:51", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-01-11"}}, {"date": "2019-12-04 16:13:59", "user": "209", "prev_value": {"visa_expired_date": "2019-01-11"}}, {"date": "2019-12-24 16:35:28", "user": "209", "prev_value": {"current_passport_number": "", "work_permit_paid_till_date": "2020-01-11"}}, {"date": "2019-12-24 16:35:47", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-01-09 20:1:5", "user": "209", "prev_value": {"visa_expired_date": "2020-01-11", "current_passport_number": ""}}, {"date": "2020-02-10 12:21:20", "user": "209", "prev_value": {"work_address_id": "", "current_passport_number": "", "work_permit_issued_date": "2019-02-11", "work_permit_expired_date": "2020-02-11", "work_permit_started_date": "2019-02-11", "work_permit_paid_till_date": "2020-02-11"}}, {"date": "2020-02-10 12:23:44", "user": "209", "prev_value": {"reg_date": "2019-10-29", "visa_expired_date": "2020-02-11", "current_passport_number": ""}}, {"date": "2020-02-11 15:24:48", "user": "209", "prev_value": {"reg_date": "2019-12-25", "current_passport_number": ""}}, {"date": "2020-03-18 13:27:33", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-02-12"}}, {"date": "2020-03-18 13:27:59", "user": "209", "prev_value": {"reg_date": "2020-02-11", "visa_expired_date": "2020-03-12"}}, {"date": "2020-04-07 12:11:15", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2020-04-07 12:34:48", "user": "209", "prev_value": {"reg_address_id": "2", "real_address_id": "2"}}]	1986-12-03	2018-05-31	2028-05-30	\N	\N	2020-02-12	2020-02-12	2021-02-12	2020-04-12	\N	\N	\N	\N	2020-04-12	2019-10-20	2019-10-20	2020-03-03	\N	209	0	0	7	7	7	0	2	0	\N	\N
131	402348702	ДОДОБОЕВА	МАХСУДА	209	6	[3, 2, 4]	FEMALE						69	1900006670							4618	6304421	САИДМУРОДОВНА				РАМЕНСКОЕ 033	ОВД В ХУДЖАНДЕ					[{"date": "2019-02-11 10:11:18", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-04-01 17:3:4", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-24 11:57:14", "user": "209", "prev_value": {"reg_date": "2019-01-15"}}, {"date": "2019-06-03 13:44:48", "user": "209", "prev_value": {"birth_place": "ТАДЖИКИСТАН", "passport_issuer": ""}}, {"date": "2019-06-03 13:51:8", "user": "209", "prev_value": {"reg_date": "2019-04-09", "visa_expired_date": "-0001-11-30", "work_permit_expired_date": "2019-04-10"}}, {"date": "2019-06-07 10:5:58", "user": "209", "prev_value": {"visa_expired_date": "2019-06-07"}}, {"date": "2019-07-03 14:56:40", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-07-03 14:57:45", "user": "209", "prev_value": {"reg_date": "2019-05-07", "visa_expired_date": "2019-07-07"}}, {"date": "2019-07-16 11:0:8", "user": "209", "prev_value": {"reg_date": "2019-06-05"}}, {"date": "2019-07-31 12:35:17", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-07"}}, {"date": "2019-07-31 12:52:37", "user": "209", "prev_value": {"visa_expired_date": "2019-08-07"}}, {"date": "2019-08-26 12:7:11", "user": "209", "prev_value": {"reg_date": "2019-07-03"}}, {"date": "2019-09-10 13:17:21", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-07"}}, {"date": "2019-09-10 13:18:8", "user": "209", "prev_value": {"reg_date": "2019-08-01", "visa_expired_date": "2019-09-07"}}, {"date": "2019-10-04 11:49:41", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-10-07"}}, {"date": "2019-10-04 11:52:27", "user": "209", "prev_value": {"reg_date": "2019-08-29", "visa_expired_date": "2019-10-07"}}, {"date": "2019-10-29 13:40:3", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-11-07"}}, {"date": "2019-10-29 13:40:22", "user": "209", "prev_value": {"visa_expired_date": "2019-11-07"}}, {"date": "2019-12-04 15:45:8", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-12-07"}}, {"date": "2019-12-04 15:45:43", "user": "209", "prev_value": {"reg_date": "2019-09-25"}}, {"date": "2019-12-04 15:46:0", "user": "209", "prev_value": {"visa_expired_date": "2019-12-07"}}, {"date": "2019-12-04 16:18:20", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-01-07"}}, {"date": "2019-12-04 16:18:33", "user": "209", "prev_value": {"visa_expired_date": "2019-01-07"}}, {"date": "2020-01-09 13:25:17", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}, {"date": "2020-01-09 13:25:30", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-09 13:26:31", "user": "209", "prev_value": {"reg_date": "2019-10-29", "visa_expired_date": "2020-01-07", "current_passport_number": ""}}]	1972-03-15	2018-10-29	2028-10-28	\N	\N	2019-02-07	2019-02-07	2020-02-07	2020-01-07	\N	\N	\N	\N	\N	2019-01-11	2019-01-11	2019-12-05	\N	209	0	0	7	2	2	0	2	0	\N	\N
132	401118569	МУРОДБОЕВА	МУХАЙЁ	209	6	[2, 3, 4]	FEMALE						69	1900006021							2808	0000723	АБДУВОХИДОВНА				РАМЕНСКОЕ 034	ОВД В ХУДЖАНДЕ			ТАДЖИКИСТАН		[{"date": "2019-02-07 14:45:25", "user": "209", "prev_value": {"migr_card_serie": "4618", "migr_card_number": "6305364", "migr_card_issued_date": "2019-01-11"}}, {"date": "2019-04-01 17:3:41", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-24 10:41:50", "user": "209", "prev_value": {"reg_date": "2019-01-15"}}, {"date": "2019-04-24 13:7:42", "user": "209", "prev_value": {"work_permit_expired_date": "2019-04-10"}}, {"date": "2019-04-29 14:20:33", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-04-29 14:20:51", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1972-09-04	2016-06-22	2026-06-21	\N	\N	2019-02-05	2019-02-05	2020-02-05	2019-04-04	\N	\N	\N	\N	\N	2019-01-11	2019-02-01	2019-04-09	\N	209	0	0	7	2	2	0	2	0	\N	\N
133	402081606	АЛИЖОНОВА	ДИЛБАР	209	6	[2, 3, 4]	FEMALE						69	1900005959							4618	6306730	АХАТОВНА				РАМЕНСКОЕ 086	ОВД В ХУДЖАНДЕ					[{"date": "2019-02-07 14:54:45", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-04-01 17:2:49", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-24 11:2:16", "user": "209", "prev_value": {"reg_date": "2019-01-15"}}, {"date": "2019-06-03 13:12:7", "user": "209", "prev_value": {"reg_date": "2019-04-09", "birth_place": "ТАДЖИКИСТАН", "visa_expired_date": "-0001-11-30", "work_permit_expired_date": "2019-04-10", "work_permit_paid_till_date": "2019-04-04"}}, {"date": "2019-07-03 11:27:7", "user": "209", "prev_value": {"reg_date": "2019-04-30"}}, {"date": "2019-07-16 10:59:9", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-05"}}, {"date": "2019-07-16 10:59:30", "user": "209", "prev_value": {"reg_date": "2019-06-04", "visa_expired_date": "2019-07-05"}}, {"date": "2019-07-22 16:48:51", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-23 11:20:11", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-07-23 11:20:47", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-07-23 11:22:36", "user": "209", "prev_value": {"visa_expired_date": "2019-08-05"}}]	1980-06-17	2018-05-04	2028-05-03	\N	\N	2019-02-05	2019-02-05	2020-02-05	2019-08-05	\N	\N	\N	\N	\N	2019-01-11	2019-01-11	2019-07-03	\N	209	0	0	7	2	2	0	2	0	\N	\N
136	402241421	ХАЛИМОВ	ДАВРОН	209	6	[3, 2, 4]	MALE						69	1900018806							4618	2492737	ХАСАНОВИЧ				ДОМОДЕВО 321	ОМВД В Б.ГАФУРОВЕ					[{"date": "2019-01-23 12:29:57", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "employer_id": "", "occupation_id": "", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-11 13:17:17", "user": "209", "prev_value": {"status_id": "SEEKER", "birth_place": "", "passport_issuer": ""}}, {"date": "2019-03-11 13:18:51", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-11 13:19:30", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-04-01 17:1:0", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-24 12:14:25", "user": "209", "prev_value": {"reg_date": "2019-01-23"}}, {"date": "2019-06-03 14:26:36", "user": "209", "prev_value": {"birth_place": "ТАДЖИКИСТАН"}}, {"date": "2019-06-03 14:28:24", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-04-05"}}, {"date": "2019-06-03 14:28:55", "user": "209", "prev_value": {"reg_date": "2019-04-09", "visa_expired_date": "-0001-11-30"}}, {"date": "2019-06-07 10:3:29", "user": "209", "prev_value": {"visa_expired_date": "2019-06-07"}}, {"date": "2019-07-03 11:4:42", "user": "209", "prev_value": {"reg_date": "2019-04-30"}}, {"date": "2019-07-03 11:7:4", "user": "209", "prev_value": {"reg_date": "2019-06-04"}}, {"date": "2019-07-16 10:57:17", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-07"}}, {"date": "2019-07-16 10:57:34", "user": "209", "prev_value": {"reg_date": "2019-06-05", "visa_expired_date": "2019-07-07"}}, {"date": "2019-07-31 13:3:0", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-07"}}, {"date": "2019-07-31 13:3:20", "user": "209", "prev_value": {"visa_expired_date": "2019-08-07"}}, {"date": "2019-08-27 13:5:15", "user": "209", "prev_value": {"reg_date": "2019-07-03"}}, {"date": "2019-09-10 13:22:45", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-07"}}, {"date": "2019-09-10 13:23:2", "user": "209", "prev_value": {"reg_date": "2019-08-01", "visa_expired_date": "2019-09-07"}}, {"date": "2019-10-04 12:1:37", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-10-07"}}, {"date": "2019-10-04 12:2:11", "user": "209", "prev_value": {"reg_date": "2019-08-29"}}, {"date": "2019-10-29 13:57:18", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-11-07"}}, {"date": "2019-10-29 13:57:29", "user": "209", "prev_value": {"visa_expired_date": "2019-10-07"}}, {"date": "2019-12-04 15:49:4", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-12-07"}}, {"date": "2019-12-04 15:49:28", "user": "209", "prev_value": {"reg_date": "2019-09-25", "visa_expired_date": "2019-12-07"}}, {"date": "2019-12-04 16:20:32", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-01-07"}}, {"date": "2019-12-04 16:20:42", "user": "209", "prev_value": {"visa_expired_date": "2019-01-07"}}, {"date": "2020-01-09 16:48:1", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-01-09 16:48:14", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-09 16:49:8", "user": "209", "prev_value": {"reg_date": "2019-10-29", "current_passport_number": ""}}, {"date": "2020-01-13 11:38:5", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}]	1984-04-13	2018-08-22	2028-08-21	\N	\N	2019-03-07	2019-03-07	2020-03-07	2020-01-07	\N	\N	\N	\N	2020-01-07	2019-01-23	2019-01-23	2019-12-05	\N	209	0	0	7	2	2	0	2	0	\N	\N
137	402445961	ХАЛИМОВА	МУКАДДАС	209	6	[3, 2, 4]	FEMALE						69	1900017898							4618	2479883	АБДУАХАДОВНА				ДОМОДЕВО 342	ОВД УМВД в СУГДЕ					[{"date": "2019-01-23 12:35:51", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-11 13:40:21", "user": "209", "prev_value": {"status_id": "SEEKER", "passport_issuer": ""}}, {"date": "2019-03-11 13:41:28", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-11 13:41:45", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-04-01 17:1:26", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-24 12:41:4", "user": "209", "prev_value": {"reg_date": "2019-01-23"}}, {"date": "2019-06-03 15:7:6", "user": "209", "prev_value": {"birth_place": "ТАДЖИКИСТАН", "work_permit_paid_till_date": "2019-04-05"}}, {"date": "2019-06-03 15:7:51", "user": "209", "prev_value": {"reg_date": "2019-04-09", "visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-03 13:27:36", "user": "209", "prev_value": {"reg_date": "2019-04-30"}}, {"date": "2019-07-16 10:47:40", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-06"}}, {"date": "2019-07-16 10:48:1", "user": "209", "prev_value": {"reg_date": "2019-06-04", "visa_expired_date": "2019-07-06"}}, {"date": "2019-07-31 13:11:39", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-06"}}, {"date": "2019-07-31 13:12:34", "user": "209", "prev_value": {"reg_date": "2019-07-05", "visa_expired_date": "2019-08-06"}}, {"date": "2019-08-27 13:14:36", "user": "209", "prev_value": {"reg_date": "2019-07-03"}}, {"date": "2019-09-10 13:23:22", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-06"}}, {"date": "2019-09-10 13:23:38", "user": "209", "prev_value": {"reg_date": "2019-08-01", "visa_expired_date": "2019-09-06"}}, {"date": "2019-10-04 12:2:35", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-10-06"}}, {"date": "2019-10-04 12:2:55", "user": "209", "prev_value": {"reg_date": "2019-08-19"}}, {"date": "2019-10-29 14:8:17", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-11-06"}}, {"date": "2019-10-29 14:8:36", "user": "209", "prev_value": {"visa_expired_date": "2019-10-06"}}, {"date": "2019-12-04 15:51:18", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-12-06"}}, {"date": "2019-12-04 15:51:45", "user": "209", "prev_value": {"reg_date": "2019-09-25", "visa_expired_date": "2019-12-06"}}, {"date": "2019-12-04 16:22:16", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-01-06"}}, {"date": "2019-12-04 16:22:34", "user": "209", "prev_value": {"visa_expired_date": "2019-01-06"}}, {"date": "2020-01-09 17:5:41", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}, {"date": "2020-01-09 17:5:54", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-09 17:6:37", "user": "209", "prev_value": {"reg_date": "2019-10-29", "current_passport_number": ""}}]	1986-06-07	2019-01-09	2029-01-08	\N	\N	2019-03-06	2019-03-06	2020-03-06	2020-01-06	\N	\N	\N	\N	2020-01-06	2019-01-23	2019-01-23	2019-12-05	\N	209	0	0	7	2	2	0	2	0	\N	\N
138	402448991	ХАЛИМОВА	ИСТАДЧОН	209	6	[2, 3, 4]	FEMALE						69	1900018813							4618	2495381	ХАСАНОВНА				ДОМОДЕВО 614	ОВД УМВД в СУГДЕ					[{"date": "2019-01-23 14:24:32", "user": "209", "prev_value": {"birth_date": "1977-02-22"}}, {"date": "2019-03-11 13:35:41", "user": "209", "prev_value": {"status_id": "SEEKER", "passport_issuer": ""}}, {"date": "2019-03-11 13:36:50", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-11 13:37:23", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-03-11 13:39:40", "user": "209", "prev_value": {"hired_date": "2019-03-07"}}, {"date": "2019-04-01 17:1:15", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-24 12:33:0", "user": "209", "prev_value": {"reg_date": "2019-01-23"}}, {"date": "2019-06-03 15:16:24", "user": "209", "prev_value": {"birth_place": "ТАДЖИКИСТАН"}}, {"date": "2019-06-03 15:17:9", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-04-05"}}, {"date": "2019-06-03 15:17:26", "user": "209", "prev_value": {"reg_date": "2019-04-09"}}, {"date": "2019-06-05 13:13:58", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-06-05 13:24:9", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1977-02-20	2019-01-10	2029-01-09	\N	\N	2019-03-07	2019-03-07	2020-03-07	2019-06-07	\N	\N	\N	\N	\N	2019-01-23	2019-01-23	2019-04-30	\N	209	0	0	7	2	2	0	2	0	\N	\N
139	402448851	ХОЛИКОВ	ИНОМЧОН	209	6	[2, 3, 4]	MALE						69	1900018468							4618	2495382	ИСОБОЕВИЧ				ДОМОДЕВО 614	ОВД УМВД в СУГДЕ					[{"date": "2019-01-23 12:53:41", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-11 13:30:38", "user": "209", "prev_value": {"status_id": "SEEKER", "birth_place": "", "passport_issuer": ""}}, {"date": "2019-03-11 13:32:5", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-03-11 13:32:31", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-04-01 17:1:56", "user": "207", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-24 12:24:9", "user": "209", "prev_value": {"reg_date": "2019-01-23"}}, {"date": "2019-06-03 14:43:5", "user": "209", "prev_value": {"birth_place": "ТАДЖИКИСТАН"}}, {"date": "2019-06-03 14:43:56", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-04-05"}}, {"date": "2019-06-03 14:44:18", "user": "209", "prev_value": {"reg_date": "2019-04-09", "visa_expired_date": "-0001-11-30"}}, {"date": "2019-06-05 12:55:29", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}]	1975-12-31	2019-01-10	2029-01-09	\N	\N	2019-03-06	2019-03-06	2020-03-06	2019-06-06	\N	\N	\N	\N	2019-06-06	2019-01-23	2019-01-23	2019-04-30	\N	209	0	0	7	2	2	0	2	0	\N	\N
161	402196748	ШАРИПОВА	МАВЗУНА	209	8	[3, 4, 2]	FEMALE														4618	6416949	КОСИМЧОНОВНА				РАМЕНСКОЕ 057						[{"date": "2019-04-29 12:47:2", "user": "209", "prev_value": []}, {"date": "2019-04-29 12:47:33", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-04-29 12:50:7", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-05-13 10:57:35", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-05-13 10:57:51", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1979-10-22	2018-07-25	2028-07-24	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-04-25	2019-03-25	2019-04-25	\N	209	0	0	7	2	2	0	0	0	\N	\N
140	401577599	УСМОНОВ	УСМОН	209	6	[2, 3, 4]	MALE						69	1900015139							4618	6314534	ИСОБОЕВИЧ				РАМЕНСКОЕ 062	ОМВД В Б.ГАФУРОВЕ					[{"date": "2019-01-25 11:20:1", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-04 15:10:43", "user": "209", "prev_value": {"status_id": "SEEKER", "birth_place": "", "passport_issuer": ""}}, {"date": "2019-03-04 15:12:17", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-04-08 13:37:50", "user": "209", "prev_value": {"birth_place": "ТАДЖИКИСТАН"}}, {"date": "2019-04-24 12:49:48", "user": "209", "prev_value": {"reg_date": "2019-01-25"}}, {"date": "2019-06-03 12:43:35", "user": "209", "prev_value": {"work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-06-03 12:44:45", "user": "209", "prev_value": {"reg_date": "2019-04-09", "visa_expired_date": "-0001-11-30"}}, {"date": "2019-07-03 14:6:7", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-28"}}, {"date": "2019-07-03 14:6:15", "user": "209", "prev_value": {"visa_expired_date": "2019-06-28"}}, {"date": "2019-07-22 16:42:3", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-22 16:42:55", "user": "209", "prev_value": {"reg_date": "2019-05-28", "visa_expired_date": "2019-07-28"}}, {"date": "2019-07-23 11:19:35", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1978-06-28	2017-07-05	2027-07-04	\N	\N	2019-02-28	2019-02-28	2020-02-28	2019-07-28	\N	\N	\N	\N	\N	2019-01-17	2019-01-17	2019-06-26	\N	209	0	0	7	2	2	0	2	0	\N	\N
141	N2093988	НГУЕН	КОНГ ХАУ	232	8	[3, 2, 4]	MALE																					ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ			РОССИЯ		[{"date": "2019-01-28 12:32:28", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-11-14 11:17:46", "user": "209", "prev_value": {"whence_id": "", "passport_serie": "II-OH ", "passport_issuer": "Филиал №5 отдела записи актов гражданского состояния администрации города Твери Тверской области", "passport_number": "565763", "passport_issued_date": "2018-09-05", "passport_expired_date": "-0001-11-30"}}, {"date": "2019-12-04 17:4:52", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "visa_expired_date": "-0001-11-30"}}, {"date": "2019-12-04 17:10:14", "user": "209", "prev_value": {"visa_expired_date": "2019-11-27"}}, {"date": "2020-11-18 12:12:4", "user": "209", "prev_value": {"birth_place": "город Тверь Тверская область "}}, {"date": "2020-11-18 12:15:13", "user": "209", "prev_value": {"reg_date": "2019-11-15", "visa_expired_date": "2020-11-26"}}, {"date": "2020-11-19 12:35:38", "user": "209", "prev_value": {"reg_date": "2020-11-18"}}, {"date": "2020-11-19 12:38:30", "user": "209", "prev_value": {"reg_date": "2020-11-19"}}, {"date": "2021-11-19 13:24:50", "user": "209", "prev_value": {"work_address_id": ""}}, {"date": "2021-11-19 13:25:40", "user": "209", "prev_value": {"reg_date": "2020-11-18", "visa_expired_date": "2021-11-25"}}, {"date": "2021-11-25 9:57:54", "user": "209", "prev_value": {"visa_expired_date": null}}, {"date": "2021-12-20 17:43:48", "user": "209", "prev_value": {"status_id": "FAMILY", "fired_date": null}}]	2018-08-28	2019-10-15	2024-10-15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2022-02-14	\N	\N	2021-11-19	\N	232	0	0	1	2	2	0	0	0	\N	\N
142	401128769	ДОМЛОЧОНОВА	АЗИЗА	209	6	[3, 2, 4]	FEMALE						69	1900037319							4618	6497359	РАМОНХОЧАЕВНА				РАМЕНСКОЕ 103	ОВД В ХУДЖАНДЕ			ТАДЖИКИСТАН		[{"date": "2019-03-04 10:22:11", "user": "209", "prev_value": []}, {"date": "2019-03-04 10:22:31", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-03-04 10:24:4", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-04-16 13:8:39", "user": "209", "prev_value": {"status_id": "SEEKER", "passport_issuer": ""}}, {"date": "2019-04-16 14:1:34", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-04-16 14:2:12", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-04-16 14:39:35", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-04-16 14:39:50", "user": "209", "prev_value": {"hired_date": "2019-04-16", "contract_number": "29"}}, {"date": "2019-04-23 13:45:14", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-04-23 13:45:37", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": ""}}, {"date": "2019-06-03 12:47:11", "user": "209", "prev_value": {"reg_date": "2019-03-05"}}, {"date": "2019-06-03 13:6:51", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-06-07 10:2:59", "user": "209", "prev_value": {"visa_expired_date": "2019-06-10"}}, {"date": "2019-07-03 12:31:32", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-03 12:31:44", "user": "209", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-07-16 11:8:28", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-10"}}, {"date": "2019-07-31 12:12:47", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-07-31 12:13:8", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-10"}}, {"date": "2019-07-31 12:15:16", "user": "209", "prev_value": {"reg_date": "2019-05-07", "entry_date": "2019-03-03", "departure_date": "2019-07-03", "entry_checkpoint": "ДОМОДЕВО 1347", "migr_card_number": "02645806", "visa_expired_date": "2019-07-10", "migr_card_issued_date": "2019-03-03"}}, {"date": "2019-08-26 12:16:19", "user": "209", "prev_value": {"reg_date": "2019-06-05"}}, {"date": "2019-09-03 10:51:50", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-09-03 10:52:4", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-09-06 12:33:3", "user": "209", "prev_value": {"visa_expired_date": "2019-09-10"}}]	1986-05-25	2016-07-25	2026-07-24	\N	\N	2019-04-10	2019-04-10	2020-04-10	2019-09-10	\N	\N	\N	\N	\N	2019-07-27	2019-07-27	2019-08-01	\N	209	0	0	7	2	2	0	2	0	\N	\N
143	402053032	УСМОНОВА	БИСАБОАТ	209	8	[3, 4, 2]	FEMALE														4618	02641853	МУХАМАДАЛИЕВНА				ДОМОДЕВО 370				ТАДЖИКИСТАН		[{"date": "2019-03-04 10:28:38", "user": "209", "prev_value": []}, {"date": "2019-03-04 10:28:49", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-03-04 10:30:18", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-26 11:54:13", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-03-26 11:55:21", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-03-26 11:55:51", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1964-02-01	2018-04-20	2028-04-19	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-03-03	2019-03-03	2019-03-15	\N	209	0	0	7	2	2	0	0	0	\N	\N
144	402520296	МАХКАМОВА	ДИЛОРОМ	209	6	[2, 3, 4]	FEMALE						69	1900037414							4618	02641852	НЕЪМАТОВНА				ДОМОДЕВО 370	ОВД В ХУДЖАНДЕ			ТАДЖИКИСТАН		[{"date": "2019-03-04 10:34:29", "user": "209", "prev_value": []}, {"date": "2019-03-04 10:35:36", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-05-06 13:33:10", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-05-06 13:34:54", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "employer_id": "", "occupation_id": "", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-05-06 13:35:28", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-05-13 10:32:30", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-05-13 10:32:44", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-05-13 11:9:47", "user": "209", "prev_value": {"passport_issuer": ""}}]	1982-01-07	2019-02-14	2029-02-13	\N	\N	2019-04-10	2019-04-10	2020-04-10	2019-06-10	\N	\N	\N	\N	\N	2019-03-03	2019-03-03	2019-03-05	\N	209	0	0	7	2	2	0	2	0	\N	\N
151	402534491	ХОТАМОВ	МУСТАФО	209	8	[3, 2, 4]	MALE														4618	02772122	МУРОДЧОНОВИЧ				ДОМОДЕВО 611				ХУДЖАНД		[{"date": "2019-03-20 14:8:42", "user": "209", "prev_value": []}, {"date": "2019-03-20 14:9:8", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-03-20 14:10:42", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-07-03 14:11:42", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-09-10 13:24:5", "user": "209", "prev_value": {"work_permit_expired_date": "-0001-11-30"}}, {"date": "2019-09-10 13:24:23", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "visa_expired_date": "2019-07-30"}}, {"date": "2019-10-04 11:19:6", "user": "209", "prev_value": {"status_id": "FAMILY"}}, {"date": "2019-10-04 11:19:20", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	2010-01-29	2019-03-04	2023-03-03	\N	\N	\N	\N	2019-09-30	\N	\N	\N	\N	\N	2019-09-30	2019-03-18	2019-03-18	2019-08-29	\N	209	0	0	7	2	2	0	0	0	\N	\N
145	N1901192	НГУЕН	ЧУНГ ХИЕУ	232	6	[3, 2, 4]	MALE			82	0938366										4619	6134877		NGUYEN	TRUNG HIEU		Шереметьево 582	ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ	RESIDENT_CARD		ХАНОЙ		[{"date": "2019-03-11 15:2:13", "user": "209", "prev_value": []}, {"date": "2019-03-11 15:2:42", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "employer_id": "", "occupation_id": "", "contract_number": ""}}, {"date": "2019-03-11 15:2:56", "user": "209", "prev_value": {"host_id": ""}}, {"date": "2019-03-11 15:10:55", "user": "209", "prev_value": {"reg_address_id": ""}}, {"date": "2019-03-15 10:38:51", "user": "208", "prev_value": {"resident_document_serie": "", "resident_document_number": "", "resident_document_issuer_id": "", "resident_document_issued_date": "-0001-11-30", "resident_document_expired_date": "-0001-11-30"}}, {"date": "2019-03-20 11:45:26", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-29 12:56:31", "user": "209", "prev_value": {"migr_card_serie": "4618"}}, {"date": "2019-09-27 11:12:3", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-09-27 11:29:57", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-09-27 11:34:52", "user": "209", "prev_value": {"fired_date": "2019-09-27"}}]	1984-11-04	2017-12-20	2027-12-20	2016-10-05	2021-10-05	\N	\N	\N	\N	\N	\N	\N	\N	\N	2018-11-26	2018-11-26	\N	\N	232	0	0	7	14	2	0	0	0	\N	\N
146	402528514	ГАДОЙБОЕВА	МАЛОХАТЧОН	209	6	[2, 3, 4]	FEMALE						69	1900047476							4618	6369258	АБДУРАХМОНОВНА				РАМЕНСКОЕ 014	ОВД В ХУДЖАНДЕ			ТАДЖИКИСТАН		[{"date": "2019-03-14 12:54:40", "user": "209", "prev_value": []}, {"date": "2019-03-14 12:55:1", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-03-14 12:56:52", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "visa_expired_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-05-27 11:19:7", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-05-27 11:19:29", "user": "209", "prev_value": {"passport_issuer": ""}}, {"date": "2019-05-27 11:21:27", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-05-27 11:21:59", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-05-28 11:38:44", "user": "209", "prev_value": {"work_permit_number": "190004746"}}, {"date": "2019-05-28 11:43:20", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": ""}}, {"date": "2019-06-03 12:31:25", "user": "209", "prev_value": {"visa_expired_date": "2019-06-09"}}, {"date": "2019-07-03 12:32:7", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-03 12:32:19", "user": "209", "prev_value": {"departure_date": "-0001-11-30"}}, {"date": "2019-07-24 13:49:57", "user": "209", "prev_value": {"status_id": "FURLOUGH"}}, {"date": "2019-07-24 13:50:46", "user": "209", "prev_value": {"reg_date": "2019-03-14", "departure_date": "2019-07-03", "visa_expired_date": "2019-07-25"}}, {"date": "2019-07-24 13:51:14", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1976-03-31	2019-02-28	2029-02-27	\N	\N	2019-04-25	2019-04-25	2020-04-25	2019-06-24	\N	\N	\N	\N	\N	2019-03-12	2019-03-12	2019-06-04	\N	209	0	0	7	2	2	0	2	0	\N	\N
148	402528516	ИСМАТОВА	ХОСИЯТ	209	6	[3, 2, 4]	FEMALE						69	1900050479							4618	02772121	СОЛИЕВНА				ДОМОДЕВО 611	ОВД  ХУДЖАНДЕ					[{"date": "2019-03-20 12:27:25", "user": "209", "prev_value": []}, {"date": "2019-03-20 12:27:51", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-03-20 12:29:38", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "visa_expired_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-05-27 13:6:18", "user": "209", "prev_value": {"status_id": "SEEKER", "birth_place": "ТАДЖИКИСТАН", "passport_issuer": ""}}, {"date": "2019-05-27 13:7:42", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-05-27 13:8:25", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-05-28 12:0:17", "user": "209", "prev_value": {"passport_issuer": "ОВД В ХУДЖАНДЕ"}}, {"date": "2019-06-03 12:21:36", "user": "209", "prev_value": {"visa_expired_date": "2019-06-15"}}, {"date": "2019-06-03 12:25:25", "user": "209", "prev_value": {"reg_date": "2019-03-22", "work_permit_paid_till_date": "2019-05-30"}}, {"date": "2019-07-03 14:10:37", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-30"}}, {"date": "2019-07-03 14:10:45", "user": "209", "prev_value": {"visa_expired_date": "2019-06-30"}}, {"date": "2019-07-26 9:38:45", "user": "209", "prev_value": {"reg_date": "2019-05-28"}}, {"date": "2019-08-27 12:14:50", "user": "209", "prev_value": {"reg_date": "2019-06-26", "visa_expired_date": "2019-07-30"}}, {"date": "2019-09-10 13:21:24", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-30"}}, {"date": "2019-09-10 13:21:52", "user": "209", "prev_value": {"reg_date": "2019-07-30", "visa_expired_date": "2019-08-30"}}, {"date": "2019-10-04 11:17:35", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-10-04 11:17:58", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1985-05-13	2019-02-28	2029-02-27	\N	\N	2019-04-30	2019-04-30	2020-04-30	2019-09-30	\N	\N	\N	\N	2019-09-30	2019-03-18	2019-03-18	2019-08-29	\N	209	0	0	7	2	2	0	2	0	\N	\N
149	400420856	ИСМАТОВА	ЗАМИРА	209	6	[3, 2, 4]	FEMALE						69	1900050461							4618	02773086	СОЛИЕВНА				ДОМОДЕВО 1402	ОВД ХУДЖАНДЕ					[{"date": "2019-03-20 12:51:44", "user": "209", "prev_value": []}, {"date": "2019-03-20 12:52:21", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_permit_expired_date": "-0001-11-30"}}, {"date": "2019-03-20 12:53:50", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "visa_expired_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-05-27 14:57:3", "user": "209", "prev_value": {"status_id": "SEEKER", "passport_issuer": ""}}, {"date": "2019-05-27 15:0:4", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "2019-06-15", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-05-27 15:0:36", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "visa_expired_date": "-0001-11-30"}}, {"date": "2019-05-28 12:14:34", "user": "209", "prev_value": {"passport_issuer": "ОВД В ХУДЖАНДЕ"}}, {"date": "2019-06-03 12:14:48", "user": "209", "prev_value": {"visa_expired_date": "2019-06-15", "work_permit_paid_till_date": "2019-05-30"}}, {"date": "2019-06-03 12:22:42", "user": "209", "prev_value": {"reg_date": "2019-03-22", "departure_date": "-0001-11-30"}}, {"date": "2019-07-03 14:7:26", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-30"}}, {"date": "2019-07-03 14:8:10", "user": "209", "prev_value": {"visa_expired_date": "2019-06-30"}}, {"date": "2019-07-26 9:47:24", "user": "209", "prev_value": {"reg_date": "2019-05-28"}}, {"date": "2019-08-26 13:37:25", "user": "209", "prev_value": {"work_permit_issuer_id": ""}}, {"date": "2019-08-26 13:38:55", "user": "209", "prev_value": {"reg_date": "2019-06-26", "visa_expired_date": "2019-07-30"}}, {"date": "2019-09-10 13:20:26", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-30"}}, {"date": "2019-09-10 13:21:7", "user": "209", "prev_value": {"reg_date": "2019-07-30", "visa_expired_date": "2019-08-30"}}, {"date": "2019-10-04 11:18:15", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-10-04 11:18:26", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1990-02-08	2014-12-23	2024-12-22	\N	\N	2019-04-30	2019-04-30	2020-04-30	2019-09-30	\N	\N	\N	\N	2019-09-30	2019-03-18	2019-03-18	2019-08-29	\N	209	0	0	7	2	2	0	2	0	\N	\N
150	C6835952	ВУ	КУАНГ ВИНЬ	232	2	[3, 2, 4]	MALE									003125148								VU	QUANG VINH			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ВИНЬФУК		[{"date": "2019-03-20 13:31:21", "user": "209", "prev_value": []}, {"date": "2019-03-20 13:47:39", "user": "209", "prev_value": {"cert_issuer": "", "cert_number": "", "employer_id": "", "occupation_id": "", "cert_issued_date": "-0001-11-30", "employ_permit_id": ""}}, {"date": "2019-03-20 13:48:1", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-07-31 10:12:5", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2020-02-10 14:50:6", "user": "209", "prev_value": {"status_id": "CANCELLED", "occupation_id": "1", "work_address_id": "", "current_passport_number": ""}}, {"date": "2020-02-10 15:4:56", "user": "209", "prev_value": {"employer_id": "1", "current_passport_number": ""}}, {"date": "2020-03-11 11:4:22", "user": "209", "prev_value": {"employer_id": "4"}}, {"date": "2020-03-18 11:13:55", "user": "209", "prev_value": {"employ_permit_id": "33"}}, {"date": "2020-03-18 11:25:17", "user": "209", "prev_value": {"employ_permit_id": "43"}}, {"date": "2020-03-18 11:29:38", "user": "209", "prev_value": {"employer_id": "1"}}, {"date": "2020-03-18 11:29:45", "user": "209", "prev_value": {"host_id": "1"}}, {"date": "2020-03-18 11:30:21", "user": "209", "prev_value": {"employ_permit_id": "33"}}, {"date": "2020-04-16 14:10:8", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1980-10-12	2019-03-01	2029-03-01	\N	\N	\N	\N	\N	\N	\N	2009-09-04	\N	\N	\N	\N	\N	\N	\N	232	45	0	4	2	2	0	0	0	\N	\N
153	N1779822	БУЙ	НГОК КЫОНГ	232	6	[3, 2, 5]	MALE			82	0484224										4619	6545960		BUI	NGOC CUONG		шереметьево 626	ПОСОЛЬСТВО СРВ В РОССИЙСКОЙ ФЕДЕРАЦИИ	RESIDENT_CARD		Тхай бинь		[{"date": "2019-03-29 14:32:58", "user": "209", "prev_value": []}, {"date": "2019-03-29 14:33:56", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "employer_id": "", "occupation_id": "", "contract_number": ""}}, {"date": "2019-03-29 14:35:17", "user": "209", "prev_value": {"host_id": ""}}, {"date": "2019-03-29 14:35:35", "user": "209", "prev_value": {"reg_address_id": ""}}, {"date": "2019-03-29 14:36:38", "user": "209", "prev_value": {"reg_address_id": "11"}}, {"date": "2019-04-02 17:31:39", "user": "207", "prev_value": []}, {"date": "2019-12-09 14:8:28", "user": "209", "prev_value": {"real_address_id": "", "resident_document_serie": "", "resident_document_number": "", "resident_document_issuer_id": "", "resident_document_issued_date": "-0001-11-30", "resident_document_expired_date": "-0001-11-30"}}, {"date": "2019-12-09 14:9:48", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-12-09 14:10:12", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}, {"date": "2019-12-11 11:58:43", "user": "209", "prev_value": {"passport_issuer": "ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ"}}, {"date": "2019-12-11 11:59:1", "user": "209", "prev_value": {"passport_expired_date": "-0001-11-30"}}, {"date": "2019-12-11 11:59:37", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}]	1966-10-21	2016-04-20	2026-04-20	2016-12-05	2021-12-05	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-03-19	2019-03-19	2017-01-18	\N	232	0	0	1	15	15	0	0	0	\N	\N
154	N1747379	ХОАНГ	ТХИ ШЫ	232	6	[3, 2, 5]	FEMALE			82	0480888										4616	8028513		HOANG	THI SU		Шереметьево 829	ПОСОЛЬСТВО СРВ В РФ	RESIDENT_CARD		ХАНОЙ		[{"date": "2019-03-29 14:40:18", "user": "209", "prev_value": []}, {"date": "2019-03-29 14:40:57", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "employer_id": "", "occupation_id": "", "contract_number": ""}}, {"date": "2019-03-29 14:42:0", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-04-02 17:31:54", "user": "207", "prev_value": []}, {"date": "2019-12-09 15:35:16", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-12-09 15:35:25", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-12-09 15:35:41", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-12-09 15:36:47", "user": "209", "prev_value": {"resident_document_serie": "", "resident_document_number": "", "resident_document_issuer_id": "", "resident_document_issued_date": "-0001-11-30", "resident_document_expired_date": "-0001-11-30"}}]	1966-01-16	2015-05-20	2025-05-20	2016-02-25	2021-02-25	\N	\N	\N	\N	\N	\N	\N	\N	\N	2016-03-15	2016-03-15	2016-04-01	\N	232	0	0	1	15	15	0	0	0	\N	\N
155	401026930	ХОШИМОВ	ДИЛШОД	209	8	[2, 3, 4]	MALE						69	1900056826							4618	6387404	ТЕМУРОВИЧ				РАМЕНСКОЕ 068	ОВД В ХУДЖАНДЕ					[{"date": "2019-03-29 15:54:6", "user": "209", "prev_value": []}, {"date": "2019-03-29 15:55:8", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-03-29 16:2:48", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-03-29 16:3:53", "user": "209", "prev_value": {"occupation_id": ""}}, {"date": "2019-03-29 16:5:51", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-04-02 15:37:52", "user": "209", "prev_value": {"visa_started_date": "-0001-11-30"}}, {"date": "2019-04-02 15:38:27", "user": "209", "prev_value": {"visa_expired_date": "1970-01-01", "visa_started_date": "2019-06-25"}}, {"date": "2019-04-02 15:49:3", "user": "209", "prev_value": {"visa_expired_date": "2019-06-25"}}, {"date": "2019-04-02 16:28:0", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-05-27 12:50:17", "user": "209", "prev_value": {"status_id": "SEEKER", "whence_id": "", "passport_issuer": ""}}, {"date": "2019-05-27 12:52:28", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-05-27 12:53:17", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-05-27 13:2:35", "user": "209", "prev_value": {"work_permit_expired_date": "2014-05-20"}}, {"date": "2019-05-28 10:33:48", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-05-28 10:34:13", "user": "209", "prev_value": {"hired_date": "2019-05-27", "contract_number": "33"}}, {"date": "2019-06-07 10:22:53", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1980-09-27	2016-04-08	2026-04-07	\N	\N	2019-05-14	2019-05-14	2020-05-14	2019-06-14	\N	\N	\N	\N	2019-06-25	2019-03-28	2019-03-28	2019-04-02	\N	209	0	0	7	2	2	0	2	0	\N	\N
156	401525377	САДИКОВА	ФАРХУНДА	209	2	[2, 3]	FEMALE														4618	6388099	ТУРСУНОВНА				РАМЕНСКОЕ 061						[{"date": "2019-03-29 16:16:35", "user": "209", "prev_value": []}, {"date": "2019-03-29 16:16:55", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-03-29 16:18:33", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_expired_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-07-31 12:54:18", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1990-03-13	2017-06-01	2027-05-31	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-06-25	2019-03-28	2019-03-28	\N	\N	0	0	0	7	0	0	0	0	0	\N	\N
157	400853755	ИШОНОВА	МАСЪУДА	209	2	[2, 3, 4]	FEMALE														4618	6386474	УМАРОВНА				РАМЕНСКОЕ 095						[{"date": "2019-04-02 9:56:35", "user": "209", "prev_value": []}, {"date": "2019-04-02 9:57:24", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-04-02 10:0:39", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-04-02 10:1:45", "user": "209", "prev_value": {"birth_date": "-0001-11-30", "birth_place": "04.02.1984"}}, {"date": "2019-07-31 12:54:49", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1984-02-04	2015-11-16	2025-11-15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-03-28	2019-03-28	2019-04-02	\N	0	0	0	7	2	2	0	0	0	\N	\N
158	402193417	ИКРАМОВА	МАНЗУРА	209	8	[2, 3, 4]	FEMALE														4618	6388100	МУБИНОВНА				РАМЕНСКОЕ 061						[{"date": "2019-04-02 10:13:47", "user": "209", "prev_value": []}, {"date": "2019-04-02 10:14:16", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-04-02 10:15:38", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-04-08 14:28:9", "user": "209", "prev_value": {"reg_date": "2019-04-02", "status_id": "SEEKER", "departure_date": "-0001-11-30"}}]	1982-10-14	2018-07-19	2028-07-18	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-03-28	2019-03-28	\N	\N	0	0	0	7	2	2	0	0	0	\N	\N
159	331340	НГУЕН	ВАН ТЫОК	177	6	[3, 2, 4]	MALE	4515																				ОТДЕЛЕНИЕМ УФМС РОССИИ ПО ГОР.МОСКВЕ ПО РАЙОНУ МАРФИНО			ХАНОЙ		[{"date": "2019-04-16 10:40:19", "user": "209", "prev_value": []}, {"date": "2019-04-16 10:45:12", "user": "209", "prev_value": {"passport_issuer": "", "passport_issued_date": "-0001-11-30"}}, {"date": "2019-04-16 10:45:48", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "employer_id": "", "occupation_id": ""}}, {"date": "2019-04-16 10:47:23", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-04-16 10:47:30", "user": "209", "prev_value": {"contract_number": ""}}, {"date": "2019-04-16 11:54:13", "user": "207", "prev_value": []}, {"date": "2019-04-21 12:46:9", "user": "207", "prev_value": {"citizenship_id": ""}}, {"date": "2022-01-17 11:17:49", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	\N	2016-01-21	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	1	15	15	0	0	0	\N	\N
162	AB9640268	КУШАКОВА	ГУЛСАНАМ	229	6	[3, 2, 4]	FEMALE						69	1900084887							4618	3147111					ДОМОДЕВО 192	Государственный центр персонализации			Андижанская область		[{"date": "2019-05-20 13:53:53", "user": "209", "prev_value": []}, {"date": "2019-05-20 13:54:10", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-05-20 13:55:52", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-06-18 14:31:20", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-06-18 14:32:52", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-06-18 14:33:11", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-06-18 14:34:21", "user": "209", "prev_value": {"passport_issuer": "ОВД Булакбашинского района Андижанской области"}}, {"date": "2019-08-09 12:36:5", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-13"}}, {"date": "2019-08-09 12:36:31", "user": "209", "prev_value": {"reg_date": "2019-05-20", "visa_expired_date": "2019-08-13"}}, {"date": "2019-08-09 12:38:42", "user": "209", "prev_value": {"birth_place": ""}}, {"date": "2019-09-10 13:9:13", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-13"}}, {"date": "2019-09-10 13:9:29", "user": "209", "prev_value": {"reg_date": "2019-06-04", "visa_expired_date": "2019-09-13"}}, {"date": "2019-10-04 12:3:23", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-10-13"}}, {"date": "2019-10-04 12:7:14", "user": "209", "prev_value": {"reg_date": "2019-09-05"}}, {"date": "2019-10-07 12:53:24", "user": "209", "prev_value": {"visa_expired_date": "2019-10-13"}}, {"date": "2019-10-29 14:18:6", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-11-13"}}, {"date": "2019-10-29 14:18:18", "user": "209", "prev_value": {"visa_expired_date": "2019-11-13"}}, {"date": "2019-12-02 15:53:30", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}, {"date": "2019-12-02 15:53:56", "user": "209", "prev_value": {"reg_date": "2019-10-03"}}]	1985-12-10	2018-05-23	2028-05-22	\N	\N	2019-06-13	2019-06-13	2020-06-13	2019-12-13	\N	\N	\N	\N	2019-12-13	2019-05-16	2019-05-16	2019-10-29	\N	229	0	0	7	2	2	0	2	0	\N	\N
163	AA0916848	АБДУАЛИМОВА	СЕВАРАХОН	229	6	[3, 2, 4]	FEMALE						69	1900084485							4618	3147110					ДОМОДЕВО 192	Государственный центр персонализации			Андижанская область		[{"date": "2019-05-20 14:33:50", "user": "209", "prev_value": []}, {"date": "2019-05-20 14:34:2", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-05-20 14:36:51", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-06-18 14:53:29", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-06-18 14:55:17", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-06-18 14:56:26", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "visa_expired_date": "-0001-11-30"}}, {"date": "2019-06-19 11:51:47", "user": "209", "prev_value": {"passport_issuer": ""}}, {"date": "2019-06-19 11:53:15", "user": "209", "prev_value": {"birth_place": ""}}, {"date": "2019-08-09 12:10:16", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-13"}}, {"date": "2019-08-29 13:21:44", "user": "209", "prev_value": {"visa_expired_date": "2019-08-13"}}, {"date": "2019-09-05 10:42:24", "user": "209", "prev_value": {"reg_date": "2019-05-20", "visa_expired_date": "2019-09-13"}}, {"date": "2019-09-05 10:43:7", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-09-05 10:50:51", "user": "209", "prev_value": {"status_id": "WORKER"}}]	1980-07-17	2013-02-18	2023-02-17	\N	\N	2019-06-13	2019-06-13	2020-06-13	2019-09-13	\N	\N	\N	\N	\N	2019-05-16	2019-05-16	2019-08-09	\N	0	0	0	7	2	2	0	2	0	\N	\N
164	AA4264484	ОРЗУКУЛОВ	БАХТИЁРЖОН	229	6	[2, 3, 4]	MALE						69	1900084904							4618	3136262					ДОМОДЕВО 627	Государственный центр персонализации			Андижанская область		[{"date": "2019-05-20 14:48:19", "user": "209", "prev_value": []}, {"date": "2019-05-20 14:48:32", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-05-20 14:49:50", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-06-21 11:19:48", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-06-21 11:27:8", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-06-21 11:27:54", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-06-21 11:29:32", "user": "209", "prev_value": {"birth_place": "", "passport_issuer": ""}}, {"date": "2019-07-24 13:59:5", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-07-24 13:59:31", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-07-24 14:0:9", "user": "209", "prev_value": {"visa_expired_date": "2019-08-13"}}, {"date": "2019-07-24 14:30:2", "user": "209", "prev_value": {"reg_date": "2019-05-20"}}]	1973-05-02	2014-02-13	2024-02-12	\N	\N	2019-06-13	2019-06-13	2020-06-13	2019-07-13	\N	\N	\N	\N	\N	2019-05-16	2019-05-16	2019-06-04	\N	229	0	0	7	2	2	0	2	0	\N	\N
165	AA1312668	БОЗОРОВ	МУХАММАДСОДИК	229	6	[3, 2, 4]	MALE						69	1900098150							4619	8385696					Шереметьево 414	Государственный центр персонализации			Андижанская область		[{"date": "2019-06-04 10:24:50", "user": "209", "prev_value": []}, {"date": "2019-06-04 10:25:2", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-06-04 10:26:42", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-07-16 11:56:27", "user": "209", "prev_value": {"status_id": "SEEKER", "passport_issuer": ""}}, {"date": "2019-07-16 12:30:17", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "occupation_id": "", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-07-16 12:30:53", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-08-09 12:26:3", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-11"}}, {"date": "2019-08-09 12:26:28", "user": "209", "prev_value": {"visa_expired_date": "2019-08-29"}}, {"date": "2019-08-09 12:27:3", "user": "209", "prev_value": {"birth_place": ""}}, {"date": "2019-09-10 13:7:48", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-11"}}, {"date": "2019-09-10 13:8:10", "user": "209", "prev_value": {"reg_date": "2019-06-04", "visa_expired_date": "2019-09-11"}}, {"date": "2019-10-04 12:8:35", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-10-11"}}, {"date": "2019-10-04 12:8:54", "user": "209", "prev_value": {"reg_date": "2019-09-05"}}, {"date": "2019-10-04 13:18:7", "user": "209", "prev_value": {"hired_date": "2019-07-15"}}, {"date": "2019-10-07 12:52:49", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}, {"date": "2019-10-08 11:18:4", "user": "209", "prev_value": {"status_id": "FIRED"}}, {"date": "2019-10-08 11:18:22", "user": "209", "prev_value": {"hired_date": "2019-10-04"}}, {"date": "2019-10-08 11:18:34", "user": "209", "prev_value": {"fired_date": "2019-10-03"}}, {"date": "2019-10-08 11:18:53", "user": "209", "prev_value": {"reg_date": "2019-10-03"}}, {"date": "2019-10-10 11:25:22", "user": "209", "prev_value": {"visa_expired_date": "2019-10-11"}}, {"date": "2019-10-30 11:13:14", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-10-30 11:14:42", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	1995-12-12	2013-04-23	2023-04-22	\N	\N	2019-07-11	2019-07-11	2020-07-11	2019-11-11	\N	\N	\N	\N	2019-10-31	2019-06-01	2019-06-01	2019-10-08	\N	229	0	0	7	2	2	0	2	0	\N	\N
166	C7262293	НГУЕН	ХЫУ ДЫК	232	2	[3, 4, 2]	MALE																	NGUYEN	HUU DUC			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАЙЗЫОНГ		[{"date": "2019-06-10 15:18:30", "user": "209", "prev_value": []}, {"date": "2019-06-10 15:19:7", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "employ_permit_id": ""}}, {"date": "2019-06-10 15:19:27", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-08-12 14:30:11", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1982-03-15	2019-05-07	2029-05-07	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	34	0	1	2	2	0	0	0	\N	\N
167	AB3247577	ХАКИМОВ	АКМАЛЖОН	229	6	[3, 2, 4]	MALE						69	1900098311							5319	0003440	АНВАРЖОНОВИЧ				МАШТАКОВО 3	Государственный центр персонализации			Андижанская область		[{"date": "2019-06-13 11:32:41", "user": "209", "prev_value": []}, {"date": "2019-06-13 11:33:1", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-06-13 11:38:5", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "visa_expired_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-07-16 13:2:46", "user": "209", "prev_value": {"status_id": "SEEKER", "birth_place": "", "passport_issuer": ""}}, {"date": "2019-07-16 13:4:11", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "occupation_id": "", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-07-16 13:5:31", "user": "209", "prev_value": {"reg_date": "2019-06-13", "visa_expired_date": "2019-09-10"}}, {"date": "2019-08-09 12:0:48", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-11"}}, {"date": "2019-08-29 13:50:52", "user": "209", "prev_value": {"reg_date": "2019-06-14"}}, {"date": "2019-09-10 13:9:48", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-11"}}, {"date": "2019-09-10 13:10:9", "user": "209", "prev_value": {"reg_date": "2019-08-09", "visa_expired_date": "2019-09-07"}}, {"date": "2019-10-01 12:59:37", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-10-04 11:36:1", "user": "209", "prev_value": {"status_id": "WORKER"}}]	1986-02-23	2016-02-26	2026-02-25	\N	\N	2019-07-11	2019-07-11	2020-07-11	2019-10-11	\N	\N	\N	\N	2019-10-07	2019-06-10	2019-06-10	2019-09-05	\N	229	0	0	7	2	2	0	2	0	\N	\N
168	C6970836	НГУЕН	ХОАНГ НАМ	232	2	[3, 2, 4]	MALE									003126263								NGUYEN 	HOANG NAM			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		Ханойское ПТУ швейной технологии и моды	ХАНАМ		[{"date": "2019-06-27 11:37:18", "user": "209", "prev_value": []}, {"date": "2019-06-27 11:38:27", "user": "209", "prev_value": {"cert_issuer": "", "cert_number": "", "employer_id": "", "occupation_id": "", "cert_issued_date": "-0001-11-30"}}, {"date": "2019-06-27 11:38:48", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-08-05 12:32:20", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2019-09-19 12:4:58", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1997-03-17	2019-03-21	2029-03-21	\N	\N	\N	\N	\N	\N	\N	2015-06-26	\N	\N	\N	\N	\N	\N	\N	232	37	0	1	2	2	0	0	0	\N	\N
169	C6871511	ХОАНГ	ТХИ НЯН	232	2	[3, 2, 4]	FEMALE																	HOANG	THI NHAN			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			Тхайбинь		[{"date": "2019-06-27 11:56:10", "user": "209", "prev_value": []}, {"date": "2019-06-27 11:56:35", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-06-27 11:56:47", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-08-05 12:31:51", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2019-09-19 12:5:20", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1979-05-30	2019-03-12	2029-03-12	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	37	0	1	2	2	0	0	0	\N	\N
170	B8338663	ФАМ	ДЫК ТХАНГ	232	6	[3, 2, 4]	MALE						69	1900004190	202401189		MULTI	WORK	13	0053420	4619	7177390		PHAM	DUC THANG		Шереметьево 074	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХЫНГИЕН		[{"date": "2019-06-27 12:13:20", "user": "209", "prev_value": []}, {"date": "2019-06-27 12:13:36", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-06-27 12:13:50", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-08-05 12:32:44", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2019-08-14 12:36:34", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_category": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "invitation_number": "", "visa_expired_date": "-0001-11-30", "visa_multiplicity": "", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-09-05 13:54:56", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-09-05 14:9:31", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-09-05 14:9:54", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-10-17 12:2:25", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "0667079", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2019-08-12", "visa_expired_date": "2019-10-30", "visa_multiplicity": "SINGLE", "visa_started_date": "2019-08-12"}}, {"date": "2020-03-10 10:53:48", "user": "209", "prev_value": {"status_id": "WORKER", "work_permit_paid_till_date": null}}, {"date": "2020-03-10 10:55:10", "user": "209", "prev_value": {"work_address_id": ""}}, {"date": "2020-03-10 10:55:29", "user": "209", "prev_value": {"reg_date": "2019-08-14"}}, {"date": "2020-03-10 11:25:51", "user": "209", "prev_value": {"departure_date": null}}, {"date": "2020-03-27 11:31:24", "user": "209", "prev_value": {"departure_date": "2020-09-10"}}, {"date": "2020-04-07 11:42:35", "user": "209", "prev_value": {"status_id": "FURLOUGH", "fired_date": null}}]	1985-04-24	2013-09-07	2023-09-07	\N	\N	2019-08-28	2019-07-02	2020-07-01	\N	\N	\N	2019-10-15	2019-10-31	2020-07-01	2019-08-13	2019-08-13	2019-10-18	2020-03-10	232	37	0	1	2	2	0	2	0	\N	\N
171	ID0459883	ДИКАНОВ	ШОХАББОС	115	6	[3, 2, 4]	MALE														5319	0078020	УЛУГБЕКОВИЧ				САГАРЧИН 043	МКК 214041			КЫРГЫЗСКАЯ РЕСПУБЛИКА		[{"date": "2019-07-10 11:48:29", "user": "209", "prev_value": []}, {"date": "2019-07-10 11:48:43", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-07-10 11:50:29", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-07-10 12:8:25", "user": "209", "prev_value": {"passport_number": "ID459883"}}, {"date": "2019-07-24 14:38:56", "user": "209", "prev_value": {"status_id": "SEEKER", "birth_place": ""}}, {"date": "2019-07-24 14:39:14", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": ""}}, {"date": "2019-07-24 14:39:51", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-08-19 14:17:42", "user": "209", "prev_value": {"citizenship_id": ""}}, {"date": "2020-01-21 14:36:33", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-21 14:36:39", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}]	1999-11-03	2017-12-21	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-06-22	2019-06-22	2019-07-10	\N	115	0	0	7	2	2	0	0	0	\N	\N
172	AA0831771	СУЛТОНОВА	ФЕРУЗА	229	6	[3, 2, 4]	FEMALE						69	1900110255							5319	0245229	МУБИНОВНА				САГАРЧИН 042	Государственный центр персонализации			Бухарская область		[{"date": "2019-07-22 15:34:37", "user": "209", "prev_value": []}, {"date": "2019-07-22 15:34:48", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-07-22 15:37:2", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-07-22 16:0:27", "user": "209", "prev_value": {"last_name_ru": "СУЛТАНОВА"}}, {"date": "2019-07-22 16:25:54", "user": "209", "prev_value": {"birth_date": "2079-07-24"}}, {"date": "2019-08-23 14:5:43", "user": "209", "prev_value": {"status_id": "SEEKER", "birth_place": ""}}, {"date": "2019-08-23 14:5:51", "user": "209", "prev_value": {"passport_issuer": ""}}, {"date": "2019-08-23 14:6:55", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "occupation_id": "", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-08-23 14:7:20", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-09-05 10:57:0", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-09-05 10:57:21", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-09-05 10:57:37", "user": "209", "prev_value": {"visa_expired_date": "2019-10-15"}}]	1979-07-24	2013-02-08	2023-02-07	\N	\N	2019-08-22	2019-08-22	2020-08-22	2019-09-22	\N	\N	\N	\N	\N	2019-07-18	2019-07-18	2019-07-23	\N	229	0	0	7	2	2	0	2	0	\N	\N
173	AB7843159	ТУРГУНОВА	НАСИБАХОН	229	6	[3, 2, 4]	FEMALE						69	1900110262							5319	0245228	ТУЙЧИБАЕВНА				САГАРЧИН 042	Государственный центр персонализации			Андижанская область		[{"date": "2019-07-22 15:45:17", "user": "209", "prev_value": []}, {"date": "2019-07-22 15:45:27", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-07-22 15:47:15", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-07-22 16:32:23", "user": "209", "prev_value": {"middle_name_ru": "ТУЙГИБОЕВНА"}}, {"date": "2019-08-23 14:1:46", "user": "209", "prev_value": {"status_id": "SEEKER", "birth_place": "", "passport_issuer": ""}}, {"date": "2019-08-23 14:3:6", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "occupation_id": "", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-08-23 14:3:30", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-09-05 11:3:16", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-09-05 11:3:31", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-09-05 11:3:43", "user": "209", "prev_value": {"visa_expired_date": "2019-10-15"}}]	1987-01-12	2017-10-04	2027-10-03	\N	\N	2019-08-22	2019-08-22	2020-08-22	2019-09-22	\N	\N	\N	\N	\N	2019-07-18	2019-07-18	2019-07-23	\N	229	0	0	7	2	2	0	2	0	\N	\N
174	AB0660826	КУРБАНОВ	ФАРРУХБЕК	229	6	[3, 2, 4]	MALE						69	1900110230							5319	0245248	БАХРАМОВИЧ				САГАРЧИН 042	Государственный центр персонализации			Андижанская область		[{"date": "2019-07-22 16:11:11", "user": "209", "prev_value": []}, {"date": "2019-07-22 16:13:10", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-08-23 13:50:44", "user": "209", "prev_value": {"status_id": "SEEKER", "birth_place": "", "passport_issuer": ""}}, {"date": "2019-08-23 13:52:46", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "employer_id": "", "occupation_id": "", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-08-23 13:53:22", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30"}}, {"date": "2019-09-05 10:52:48", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": "-0001-11-30"}}, {"date": "2019-09-06 12:33:33", "user": "209", "prev_value": {"visa_expired_date": "2019-10-15"}}, {"date": "2019-09-06 12:33:44", "user": "209", "prev_value": {"work_permit_expired_date": "2019-08-22"}}]	1984-02-17	2015-08-06	2025-08-05	\N	\N	2019-08-22	2019-08-22	2020-08-22	2019-09-22	\N	\N	\N	\N	\N	2019-07-18	2019-07-18	2019-07-23	\N	229	0	0	7	2	2	0	2	0	\N	\N
175	AA4013107	ИМЯМИНОВ	БАХОДИР	229	8	[3, 2, 4]	MALE														4618	3578901					ДОМОДЕВО 209						[{"date": "2019-07-26 9:21:42", "user": "209", "prev_value": []}, {"date": "2019-07-26 9:21:54", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-07-26 9:22:59", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-07-29 11:54:46", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1989-01-31	2014-01-20	2024-01-19	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-07-22	2019-07-22	\N	\N	0	0	0	7	2	2	0	0	0	\N	\N
176	402051168	РУСТАМОВ	РАХИМДЖОН	209	8	[3, 2, 4]	MALE														4618	6497358	РАВШАНОВИЧ				РАМЕНСКОЕ 103					КИМРСКИЙ РАЙОН, ПОС. ПРИВОЛЖСКИЙ, УЛ.ЛЕСНАЯ, ДОМ8	[{"date": "2019-07-30 10:41:10", "user": "209", "prev_value": []}, {"date": "2019-07-30 10:41:46", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-07-30 10:43:47", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-09-02 13:16:22", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-09-02 13:21:28", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}]	2000-05-27	2018-04-09	2028-04-08	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-07-27	2019-07-27	2019-07-30	\N	209	0	0	7	2	2	0	0	0	\N	\N
177	C7845183	ДОАН	ТХИ ХЫОНГ ЛАН	232	6	[3, 2, 4]	FEMALE						69	2000003990	202401577	011486	MULTI	WORK	13	0061692	4619	7396816		DOAN	THI HUONG LAN		Шереметьево 844	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		ЧАСТНОЕ ПТУ "ЗУИТАН"	ХАЙЗЫОНГ		[{"date": "2019-07-31 11:25:19", "user": "209", "prev_value": []}, {"date": "2019-07-31 11:27:37", "user": "209", "prev_value": {"cert_issuer": "", "cert_number": "", "employer_id": "", "occupation_id": "", "cert_issued_date": "-0001-11-30", "employ_permit_id": ""}}, {"date": "2019-07-31 11:28:49", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-09-17 14:37:19", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_category": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "invitation_number": "", "visa_expired_date": "-0001-11-30", "visa_multiplicity": "", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-10-07 13:0:22", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-10-07 13:1:32", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-10-07 13:1:57", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-10-07 14:2:55", "user": "209", "prev_value": {"work_permit_expired_date": "2019-03-25"}}, {"date": "2019-11-13 16:43:44", "user": "209", "prev_value": {"contract_number": ""}}, {"date": "2019-11-13 16:45:33", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "1096881", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2019-09-12", "visa_expired_date": "2019-12-11", "visa_multiplicity": "SINGLE", "visa_started_date": "2019-09-13"}}, {"date": "2020-03-20 13:2:3", "user": "209", "prev_value": {"employ_permit_id": "33", "work_permit_number": "1900004507", "work_permit_issued_date": "2019-10-04", "work_permit_expired_date": "2020-03-25", "work_permit_started_date": "2019-10-04"}}, {"date": "2020-03-20 13:3:26", "user": "209", "prev_value": {"reg_date": "2019-09-17", "visa_number": "0053840", "visa_issued_date": "2019-11-07", "visa_expired_date": "2020-03-25", "visa_started_date": "2019-12-12"}}, {"date": "2020-12-23 12:49:53", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1990-02-25	2019-07-19	2029-07-19	\N	\N	2020-03-13	2020-03-25	2021-03-24	\N	\N	2016-07-04	2020-03-16	2020-03-26	2021-03-24	2019-09-16	2019-09-16	2020-03-24	\N	232	48	0	7	2	2	0	2	0	\N	\N
178	C7256145	НГУЕН	ВАН МАНЬ	232	6	[3, 2, 4]	MALE						69	1900004641			MULTI	WORK	13	0061033	4619	7541469		NGUYEN	VAN MANH		Шереметьево 584	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАЙЗЫОНГ		[{"date": "2019-08-05 12:10:48", "user": "209", "prev_value": []}, {"date": "2019-08-05 12:11:20", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-08-05 12:11:32", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-08-05 13:14:40", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2019-08-09 9:30:40", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-08-14 11:47:56", "user": "209", "prev_value": {"status_id": "CANCELLED"}}, {"date": "2019-08-29 12:37:36", "user": "209", "prev_value": {"employ_permit_id": "35"}}, {"date": "2019-10-14 12:13:45", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_category": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_multiplicity": "", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-10-30 11:47:27", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-11-01 10:20:40", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-01 10:22:0", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-12-16 12:52:23", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "1100730", "visa_issuer_id": "", "visa_issued_date": "2019-10-04", "visa_expired_date": "2019-12-29", "visa_started_date": "2019-10-04", "current_passport_number": ""}}, {"date": "2020-03-04 10:50:44", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null, "current_passport_number": "", "work_permit_paid_till_date": null}}, {"date": "2020-03-04 10:51:6", "user": "209", "prev_value": {"work_address_id": "", "current_passport_number": ""}}, {"date": "2020-03-04 10:52:8", "user": "209", "prev_value": {"reg_date": "2019-10-15", "visa_multiplicity": "SINGLE", "current_passport_number": ""}}]	1988-08-20	2019-04-26	2029-04-26	\N	\N	2019-10-29	2019-10-29	2020-09-11	\N	\N	\N	2019-11-25	2019-11-25	2020-09-11	2019-10-12	2019-10-12	2019-12-18	\N	232	38	0	1	2	2	0	2	0	\N	\N
179	C6289749	НГУЕН	ВАН ЗУНГ	232	4	[2, 3, 4]	MALE																	NGUYEN	VAN DUNG			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			Тхайбинь		[{"date": "2019-08-09 9:37:18", "user": "209", "prev_value": []}, {"date": "2019-08-09 9:37:31", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-08-09 9:37:44", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-08-29 12:36:52", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2019-10-30 11:38:57", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2020-01-17 11:42:34", "user": "207", "prev_value": {"status_id": "CANCELLED", "current_passport_number": ""}}]	1990-04-21	2018-10-31	2028-10-31	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	38	0	1	2	2	0	0	0	\N	\N
180	C1924533	ФАМ	ТХИ ХИЕН	232	6	[3, 2, 4]	FEMALE						69	1900004497	202401578		MULTI	WORK	13	0053839	4619	7396815		PHAM 	THI HIEN		Шереметьево 844	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			БАКЗАНГ		[{"date": "2019-08-09 9:51:56", "user": "209", "prev_value": []}, {"date": "2019-08-09 9:52:19", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "employ_permit_id": ""}}, {"date": "2019-08-09 9:52:34", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-09-17 14:24:24", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_category": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_multiplicity": "", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-09-17 14:45:41", "user": "209", "prev_value": {"visa_serie": "21"}}, {"date": "2019-09-17 14:45:59", "user": "209", "prev_value": {"invitation_number": ""}}, {"date": "2019-10-07 12:54:0", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-10-07 12:55:10", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-10-07 12:55:36", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-10-07 13:57:13", "user": "209", "prev_value": {"work_permit_expired_date": "2019-07-10"}}, {"date": "2019-11-13 18:8:21", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "1096880", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2019-09-12", "visa_expired_date": "2019-12-11", "visa_multiplicity": "SINGLE", "visa_started_date": "2019-09-13"}}, {"date": "2019-12-11 12:12:3", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-12-11 12:14:34", "user": "209", "prev_value": {"fired_date": "-0001-11-30"}}, {"date": "2019-12-11 12:17:13", "user": "209", "prev_value": {"reg_date": "2019-09-17"}}, {"date": "2019-12-11 12:25:21", "user": "209", "prev_value": {"reg_date": "2019-09-15"}}]	1975-11-02	2016-06-30	2026-06-30	\N	\N	2019-10-04	2019-10-04	2020-07-10	\N	\N	\N	2019-11-07	2019-12-12	2020-07-10	2019-09-16	2019-09-16	2019-11-15	\N	232	35	0	1	2	2	0	2	0	\N	\N
181	C7855138	НГУЕН	ТХИ НГАН	232	4	[2, 3, 4]	FEMALE																	NGUYEN	THI NGAN			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			Тхайбинь		[{"date": "2019-08-09 10:22:58", "user": "209", "prev_value": []}, {"date": "2019-08-09 10:23:16", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-08-09 10:23:29", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-08-09 11:10:28", "user": "209", "prev_value": {"passport_issued_date": "-0001-11-30", "passport_expired_date": "-0001-11-30"}}, {"date": "2019-08-29 12:37:14", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2019-10-30 11:39:11", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2020-01-17 11:42:43", "user": "207", "prev_value": {"status_id": "CANCELLED", "current_passport_number": ""}}]	1990-11-15	2019-07-12	2029-07-12	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	38	0	1	2	2	0	0	0	\N	\N
182	N2093037	НГУЕН	ТХАНЬ ЛУАН	232	6	[3, 2, 4]	MALE						69	2200007085	202401868	00031905	MULTI	WORK	12	1947469	2808	0000728		NGUYEN 	THANH LUAN		Шереметьево 685	ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ		Хынгиенский промышленный колледж	БАКЖАНГ		[{"date": "2019-09-19 14:30:57", "user": "209", "prev_value": []}, {"date": "2019-09-19 14:32:26", "user": "209", "prev_value": {"cert_issuer": "", "cert_number": "", "employer_id": "", "occupation_id": "", "cert_issued_date": "-0001-11-30", "employ_permit_id": ""}}, {"date": "2019-09-19 14:32:41", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-09-23 13:3:26", "user": "209", "prev_value": {"occupation_id": "1"}}, {"date": "2019-11-11 22:34:46", "user": "207", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-11 22:35:15", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2019-11-25 17:23:45", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_category": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_multiplicity": "", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-12-10 14:59:50", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-12-10 15:1:39", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-12-10 15:3:12", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": ""}}, {"date": "2019-12-10 15:4:14", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-12-10 15:21:7", "user": "209", "prev_value": {"migr_card_serie": "4619", "migr_card_number": "7646541"}}, {"date": "2019-12-26 18:38:37", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "1628704", "visa_issued_date": "2019-11-11", "visa_expired_date": "2020-01-22", "visa_started_date": "2019-11-11", "current_passport_number": ""}}, {"date": "2019-12-26 18:43:46", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-03-20 13:29:6", "user": "209", "prev_value": {"employ_permit_id": "34", "work_permit_number": "1900004962", "work_permit_issued_date": "2019-12-10", "work_permit_expired_date": "2020-04-04", "work_permit_started_date": "2019-12-10"}}, {"date": "2020-03-20 13:30:24", "user": "209", "prev_value": {"reg_date": "2019-11-26", "visa_number": "0061424", "visa_issued_date": "2019-12-23", "visa_expired_date": "2020-04-04", "visa_started_date": "2019-12-23"}}, {"date": "2020-05-13 16:31:11", "user": "209", "prev_value": {"work_permit_expired_date": "2021-03-24", "work_permit_started_date": "2020-03-25"}}, {"date": "2021-03-18 16:24:18", "user": "209", "prev_value": {"employ_permit_id": "47", "work_permit_number": "2000003968", "work_permit_issued_date": "2020-03-13", "work_permit_expired_date": "2021-04-03", "work_permit_started_date": "2020-03-13"}}, {"date": "2021-03-18 16:28:54", "user": "209", "prev_value": {"reg_date": "2020-03-24", "visa_serie": "13", "visa_number": "0061689", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2020-03-16", "visa_expired_date": "2021-04-03", "visa_multiplicity": "SINGLE", "visa_started_date": "2020-04-05"}}, {"date": "2021-03-22 13:26:54", "user": "209", "prev_value": {"work_permit_started_date": null}}, {"date": "2022-03-30 11:26:2", "user": "209", "prev_value": {"work_address_id": "", "work_permit_number": "2100005285", "work_permit_issued_date": "2021-03-15", "work_permit_expired_date": "2022-03-31", "work_permit_started_date": "2021-04-03"}}, {"date": "2022-03-30 11:31:0", "user": "209", "prev_value": {"visa_number": "1946498", "visa_issued_date": "2021-03-15", "invitation_number": "", "visa_expired_date": "2022-03-31", "visa_started_date": "2021-04-04"}}, {"date": "2022-03-31 11:29:1", "user": "209", "prev_value": {"employ_permit_id": "57"}}, {"date": "2022-09-01 13:4:0", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1984-08-15	2019-05-06	2029-05-06	\N	\N	2022-03-28	2022-03-31	2023-03-30	\N	\N	2009-07-02	2022-03-28	2022-04-01	2023-03-30	2019-11-20	2019-11-20	2021-03-23	\N	232	77	0	1	2	2	0	2	0	\N	\N
183	C8094297	ВУ	ВАН ДИЕП	232	6	[3, 2, 4]	MALE						69	1900004698		00312205	MULTI	WORK	13	0061425	4619	7579601		VU	VAN DIEP		Шереметьево 677	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ		ЧАСТНОЕ ПТУ "ЗУИТАН"	ХАЙЗЫОНГ		[{"date": "2019-09-19 15:41:58", "user": "209", "prev_value": []}, {"date": "2019-09-19 15:43:27", "user": "209", "prev_value": {"cert_issuer": "", "cert_number": "", "employer_id": "", "occupation_id": "", "cert_issued_date": "-0001-11-30", "employ_permit_id": ""}}, {"date": "2019-09-19 15:43:38", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-09-19 15:48:21", "user": "209", "prev_value": {"passport_issued_date": "-0001-11-30", "passport_expired_date": "-0001-11-30"}}, {"date": "2019-09-23 12:53:19", "user": "209", "prev_value": {"passport_issued_date": "2019-05-06", "passport_expired_date": "2029-05-06"}}, {"date": "2019-10-29 13:18:51", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_category": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "visa_multiplicity": "", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-10-29 14:50:24", "user": "209", "prev_value": {"visa_number": "1627632"}}, {"date": "2019-11-25 15:38:16", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-25 15:40:43", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-11-25 15:40:59", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2020-01-09 17:38:16", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "1627756", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2019-10-24", "visa_expired_date": "2020-01-22", "visa_multiplicity": "SINGLE", "visa_started_date": "2019-10-25", "current_passport_number": ""}}, {"date": "2020-03-04 10:32:55", "user": "209", "prev_value": {"current_passport_number": "", "work_permit_paid_till_date": null}}, {"date": "2020-03-04 10:33:8", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": "", "work_permit_paid_till_date": null}}, {"date": "2020-03-04 10:40:27", "user": "209", "prev_value": {"work_address_id": "", "current_passport_number": ""}}, {"date": "2020-03-04 10:40:56", "user": "209", "prev_value": {"fired_date": null, "current_passport_number": ""}}, {"date": "2020-03-04 10:42:40", "user": "209", "prev_value": {"reg_date": "2019-10-29", "current_passport_number": ""}}, {"date": "2020-03-04 10:46:57", "user": "209", "prev_value": {"fired_date": "2020-03-04", "current_passport_number": ""}}, {"date": "2020-03-04 10:47:4", "user": "209", "prev_value": {"current_passport_number": ""}}]	1988-11-25	2019-08-27	2029-08-27	\N	\N	2019-11-12	2019-11-12	2020-07-01	\N	\N	2008-09-05	2019-12-23	2020-01-23	2020-07-01	2019-10-27	2019-10-27	2020-01-10	\N	232	37	0	1	2	2	0	2	0	\N	\N
184	C1546070	ДИНЬ	ХЫУ КХЫОНГ	232	6	[3, 2, 4]	MALE						69	2200007776	202401866		MULTI	WORK	12	2163798	4619	7579602		DINH	HUU KHUONG		Шереметьево 677	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ИЕНБАЙ		[{"date": "2019-09-19 15:46:54", "user": "209", "prev_value": []}, {"date": "2019-09-19 15:47:8", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "employ_permit_id": ""}}, {"date": "2019-09-19 15:47:29", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-10-29 13:33:8", "user": "209", "prev_value": {"entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_category": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "invitation_number": "", "visa_expired_date": "-0001-11-30", "visa_multiplicity": "", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-11-25 14:44:9", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-11-25 14:45:27", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2019-11-25 14:45:55", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2020-01-09 18:15:23", "user": "209", "prev_value": {"contract_number": "", "current_passport_number": ""}}, {"date": "2020-01-09 18:17:31", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "1627632", "visa_issued_date": "2019-10-24", "visa_expired_date": "2020-01-22", "visa_multiplicity": "SINGLE", "visa_started_date": "2019-10-25", "current_passport_number": ""}}, {"date": "2020-05-13 15:5:25", "user": "209", "prev_value": {"work_address_id": ""}}, {"date": "2020-05-13 15:6:32", "user": "209", "prev_value": {"reg_date": "2019-10-29"}}, {"date": "2020-06-23 13:46:39", "user": "209", "prev_value": {"employ_permit_id": "37", "work_permit_number": "1900004708", "work_permit_issued_date": "2019-11-12", "work_permit_expired_date": "2019-07-01", "work_permit_started_date": "2019-11-12"}}, {"date": "2020-06-23 13:48:49", "user": "209", "prev_value": {"reg_date": "2020-07-10", "visa_serie": "13", "visa_number": "0061426", "visa_issued_date": "2019-12-23", "visa_expired_date": "2020-07-01", "visa_started_date": "2020-01-23"}}, {"date": "2021-06-03 19:40:25", "user": "209", "prev_value": {"employ_permit_id": "49", "work_permit_number": "2000004619", "work_permit_issued_date": "2020-06-17", "work_permit_expired_date": "2021-06-30", "work_permit_started_date": "2020-07-01"}}, {"date": "2021-06-03 19:43:16", "user": "209", "prev_value": {"reg_date": "2020-06-26", "visa_number": "1770608", "visa_issued_date": "2020-06-18", "visa_expired_date": "2021-06-30", "visa_started_date": "2020-07-02"}}, {"date": "2022-06-29 10:50:20", "user": "209", "prev_value": {"employ_permit_id": "58", "work_permit_number": "2100005662", "work_permit_issued_date": "2021-05-31", "work_permit_expired_date": "2022-06-29", "work_permit_started_date": "2021-06-30"}}, {"date": "2022-06-29 11:6:57", "user": "209", "prev_value": {"reg_date": "2021-06-04", "visa_number": "1946774", "visa_issued_date": "2021-06-02", "visa_expired_date": "2022-06-29", "visa_started_date": "2021-07-01"}}, {"date": "2022-08-26 14:3:41", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2022-10-17 12:8:44", "user": "209", "prev_value": {"status_id": "FURLOUGH", "fired_date": null}}, {"date": "2022-10-17 12:9:29", "user": "209", "prev_value": {"reg_date": "2021-06-16"}}]	1985-02-10	2016-03-24	2026-03-24	\N	\N	2022-06-14	2022-06-29	2023-06-28	\N	\N	\N	2022-06-22	2022-06-30	2023-06-28	2019-10-27	2019-10-27	2022-06-29	\N	232	78	0	1	2	2	0	2	0	\N	\N
185	C8081367	НГУЕН	ВАН ДЫК	232	6	[3, 2, 4]	MALE						69	2000004922	202402234		MULTI	WORK	12	1771217	4619	7818272		NGUYEN	VAN DUC		шереметьево 646	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			Тхайбинь		[{"date": "2019-09-19 15:55:2", "user": "209", "prev_value": []}, {"date": "2019-09-19 15:56:36", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-09-19 15:56:52", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-09-19 15:57:0", "user": "209", "prev_value": {"employer_id": "1"}}, {"date": "2019-11-20 13:59:28", "user": "209", "prev_value": {"occupation_id": ""}}, {"date": "2019-11-20 14:0:41", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2019-12-04 10:5:15", "user": "207", "prev_value": {"status_id": "SEEKER", "hired_date": "-0001-11-30"}}, {"date": "2019-12-04 10:5:59", "user": "207", "prev_value": {"status_id": "WORKER", "hired_date": "2019-12-04"}}, {"date": "2019-12-28 10:31:36", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_category": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "invitation_number": "", "visa_expired_date": "-0001-11-30", "visa_multiplicity": "", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-21 12:54:54", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "current_passport_number": ""}}, {"date": "2020-01-21 12:55:1", "user": "209", "prev_value": {"status_id": "SEEKER", "current_passport_number": ""}}, {"date": "2020-01-21 12:56:2", "user": "209", "prev_value": {"work_address_id": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "current_passport_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2020-01-21 12:57:35", "user": "209", "prev_value": {"work_permit_number": "1000003703", "current_passport_number": ""}}, {"date": "2020-03-17 10:42:51", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "1630761", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2019-12-23", "visa_expired_date": "2020-03-21", "visa_multiplicity": "SINGLE", "visa_started_date": "2019-12-23"}}, {"date": "2020-10-22 12:22:37", "user": "209", "prev_value": {"work_permit_number": "2000003703", "work_permit_issued_date": "2020-01-20", "work_permit_expired_date": "2020-10-23", "work_permit_started_date": "2020-01-20", "work_permit_paid_till_date": null}}, {"date": "2020-10-22 12:25:33", "user": "209", "prev_value": {"employ_permit_id": "42"}}, {"date": "2020-10-22 12:27:18", "user": "209", "prev_value": {"visa_serie": "13", "visa_number": "0061631", "visa_issued_date": "2020-03-10", "visa_expired_date": "2020-10-23", "visa_started_date": "2020-03-22"}}, {"date": "2021-04-12 13:5:24", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2021-04-12 13:6:6", "user": "209", "prev_value": {"reg_date": "2019-12-28"}}]	1994-10-20	2019-08-28	2029-08-28	\N	\N	2020-10-13	2020-10-23	2021-10-22	\N	\N	\N	2020-10-20	2020-10-24	2021-10-22	2019-12-26	2019-12-26	2020-10-23	\N	232	50	0	4	2	2	0	2	0	\N	\N
186	400989903	МАХМУДОВ	ТОХИРШЕХ	209	8	[3, 2, 4]	MALE														4618	6560457	НЕЪМАТШЕХОВИЧ				РАМЕНСКОЕ 048	УМВД В Б.ГАФУРОВЕ					[{"date": "2019-10-10 11:36:49", "user": "209", "prev_value": []}, {"date": "2019-10-10 11:37:37", "user": "209", "prev_value": {"passport_issued_date": "-0001-11-30", "passport_expired_date": "-0001-11-30"}}, {"date": "2019-10-10 11:39:34", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "employer_id": "", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-12-16 12:41:1", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-03-04 11:46:50", "user": "209", "prev_value": {"status_id": "FAMILY", "current_passport_number": "", "work_permit_paid_till_date": null}}]	2006-11-13	2016-03-31	2020-03-30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2020-01-03	2019-10-06	2019-10-06	\N	\N	209	0	0	4	2	2	0	0	0	\N	\N
187	400989905	МАХМУДОВА	БИРОБИЯ	209	8	[3, 2, 4]	FEMALE														4618	6560456	НЕЪМАТШЕХОВНА				ДОМОДЕВО 583	УМВД В Б.ГАФУРОВЕ					[{"date": "2019-10-10 12:16:19", "user": "209", "prev_value": []}, {"date": "2019-10-10 12:16:28", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2019-10-10 12:17:55", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-12-16 12:41:25", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-03-04 11:47:7", "user": "209", "prev_value": {"status_id": "FAMILY", "current_passport_number": "", "work_permit_paid_till_date": null}}]	2007-12-07	2016-03-31	2020-03-30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-01-03	2019-10-06	2019-10-06	\N	\N	209	0	0	4	2	2	0	0	0	\N	\N
188	401935860	ФОЗИЛОВА	ФИРУЗА	209	6	[3, 2, 4]	FEMALE						69	1900136768							4618	6585820	АБДУМАВЛОНОВНА				РАМЕНСКОЕ 097	ОМВД В Б.ГАФУРОВ					[{"date": "2019-11-08 12:42:54", "user": "209", "prev_value": []}, {"date": "2019-11-08 12:43:14", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-11-08 12:45:31", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-12-11 13:13:7", "user": "209", "prev_value": {"status_id": "SEEKER", "passport_issuer": ""}}, {"date": "2019-12-11 13:13:23", "user": "209", "prev_value": {"hired_date": "-0001-11-30"}}, {"date": "2019-12-11 13:17:33", "user": "209", "prev_value": {"contract_number": ""}}, {"date": "2019-12-11 13:17:58", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-12-11 13:34:57", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-12-25 9:14:15", "user": "209", "prev_value": {"current_passport_number": "", "work_permit_paid_till_date": "2020-01-06"}}, {"date": "2019-12-25 9:15:44", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-27 15:3:50", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-01-27 15:3:57", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}, {"date": "2020-01-27 15:6:6", "user": "209", "prev_value": {"reg_date": "2019-11-08", "visa_expired_date": "2020-02-06", "current_passport_number": ""}}]	1969-04-13	2018-01-31	2028-01-30	\N	\N	2019-12-06	2019-12-06	2020-12-06	2020-02-06	\N	\N	\N	\N	\N	2019-11-07	2019-11-07	2019-12-25	\N	209	0	0	7	2	2	0	2	0	\N	\N
189	402054833	ФАЁЗОВА	АДОЛАТ	209	8	[3, 2, 4]	FEMALE														4618	6585819	МУЙДИНОВНА				РАМЕНСКОЕ 097						[{"date": "2019-11-08 12:50:17", "user": "209", "prev_value": []}, {"date": "2019-11-08 12:50:29", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-11-08 12:51:35", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-12-23 14:22:0", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "status_id": "SEEKER", "departure_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2019-12-23 14:23:14", "user": "209", "prev_value": {"current_passport_number": ""}}]	1972-01-25	2018-04-18	2028-04-17	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2019-11-07	2019-11-07	2019-11-08	2019-12-23	209	0	0	7	2	2	0	0	0	\N	\N
190	C6598031	НГУЕН	ДАК ХАО	232	6	[3, 2, 4]	MALE						69	2100006232	202402235		MULTI	WORK	12	2030554	4619	7818270		NGUYEN	DAC HAO		шереметьево 646	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			БАКНИНЬ		[{"date": "2019-11-20 14:59:30", "user": "209", "prev_value": []}, {"date": "2019-11-20 15:0:41", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "employ_permit_id": ""}}, {"date": "2019-11-20 15:0:53", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2019-12-28 10:4:50", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "visa_serie": "", "visa_number": "", "visa_category": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": "-0001-11-30", "invitation_number": "", "visa_expired_date": "-0001-11-30", "visa_multiplicity": "", "visa_started_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2019-12-28 10:5:9", "user": "209", "prev_value": {"reg_date": "2019-12-30", "current_passport_number": ""}}, {"date": "2020-01-21 12:27:2", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "current_passport_number": ""}}, {"date": "2020-01-21 12:27:8", "user": "209", "prev_value": {"status_id": "SEEKER", "current_passport_number": ""}}, {"date": "2020-01-21 12:28:29", "user": "209", "prev_value": {"work_address_id": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "current_passport_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30"}}, {"date": "2020-01-21 12:29:55", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-03-17 11:1:2", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "1630760", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2019-12-23", "visa_expired_date": "2020-03-21", "visa_multiplicity": "SINGLE", "visa_started_date": "2019-12-23"}}, {"date": "2020-11-16 17:28:28", "user": "209", "prev_value": {"hired_date": "2020-01-21", "employ_permit_id": "41", "work_permit_number": "2000003693", "work_permit_issued_date": "2020-01-20", "work_permit_expired_date": "2020-11-26", "work_permit_started_date": "2020-01-20"}}, {"date": "2020-11-16 17:30:18", "user": "209", "prev_value": {"reg_date": "2019-12-28", "visa_serie": "13", "visa_number": "0061630", "visa_issued_date": "2020-03-10", "visa_expired_date": "2020-11-26", "visa_started_date": "2020-03-22"}}, {"date": "2020-11-19 12:45:19", "user": "209", "prev_value": {"reg_date": null}}, {"date": "2021-11-16 9:33:39", "user": "209", "prev_value": {"reg_date": "2020-11-18", "visa_number": "1771294", "visa_issued_date": "2020-11-09", "visa_expired_date": "2021-11-20", "visa_started_date": "2020-11-27"}}, {"date": "2021-11-16 9:34:53", "user": "209", "prev_value": {"work_permit_number": "2000005034", "work_permit_issued_date": "2020-10-28", "work_permit_expired_date": "2021-11-20", "work_permit_started_date": "2020-11-21"}}, {"date": "2022-04-11 15:30:14", "user": "209", "prev_value": {"employ_permit_id": "51"}}, {"date": "2022-06-15 11:12:2", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1980-05-25	2019-01-10	2029-01-10	\N	\N	2021-10-28	2021-11-20	2022-11-19	\N	\N	\N	2021-11-09	2021-11-21	2022-11-19	2019-12-26	2019-12-26	2021-11-16	\N	232	60	0	1	2	2	0	2	0	\N	\N
191	401488265	ПОЧОДЖОНОВА	РУХСАТОЙ	209	6	[3, 2, 4]	FEMALE						69	1900139617							4618	6595129	АСКАРОВНА					ОВД В ХУДЖАНДЕ					[{"date": "2019-11-22 12:48:6", "user": "209", "prev_value": []}, {"date": "2019-11-22 12:48:31", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-11-22 12:49:39", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-12-17 16:28:45", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "current_passport_number": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-12-17 16:29:53", "user": "209", "prev_value": {"reg_date": "-0001-11-30", "visa_expired_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2019-12-17 16:29:55", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2019-12-17 16:35:42", "user": "209", "prev_value": {"contract_number": "", "current_passport_number": ""}}, {"date": "2019-12-17 16:35:51", "user": "209", "prev_value": {"status_id": "SEEKER", "current_passport_number": ""}}, {"date": "2019-12-17 16:36:4", "user": "209", "prev_value": {"passport_issuer": "", "current_passport_number": ""}}, {"date": "2019-12-18 10:11:44", "user": "209", "prev_value": {"passport_issuer": "ОВД ХУДЖАНДЕ", "current_passport_number": ""}}, {"date": "2019-12-25 9:2:13", "user": "209", "prev_value": {"current_passport_number": "", "work_permit_paid_till_date": "2020-01-16"}}, {"date": "2020-01-09 16:31:4", "user": "209", "prev_value": {"status_id": "WORKER", "current_passport_number": ""}}, {"date": "2020-01-09 16:31:17", "user": "209", "prev_value": {"fired_date": "-0001-11-30", "current_passport_number": ""}}]	1972-09-28	2017-04-17	2027-04-16	\N	\N	2019-12-16	2019-12-16	2020-12-16	2020-02-16	\N	\N	\N	\N	2020-02-17	2019-11-20	2019-11-20	2019-11-22	\N	209	0	0	7	2	2	0	2	0	\N	\N
193	#4	Басов	Дмитрий	0	3	[0]	MALE																Борисович										[{"date": "2020-02-06 11:49:15", "user": "207", "prev_value": []}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
194	C3552764	ВУ	ХОНГ ВИНЬ	232	6	[3, 2, 4]	MALE						69	2200006525	202402362		MULTI	WORK	12	1947523	4622	0205527		VU	HONG VINH		домодедово 1682	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХЫНГИЕН		[{"date": "2020-02-06 14:4:29", "user": "209", "prev_value": []}, {"date": "2020-02-06 14:5:21", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": "", "current_passport_number": ""}}, {"date": "2020-02-06 14:5:47", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": "", "current_passport_number": ""}}, {"date": "2020-02-25 10:42:41", "user": "209", "prev_value": {"employ_permit_id": "44", "current_passport_number": ""}}, {"date": "2020-04-16 14:10:23", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2021-12-20 11:16:7", "user": "209", "prev_value": {"passport_number": "C3552764"}}, {"date": "2021-12-20 11:16:48", "user": "209", "prev_value": {"status_id": "CANCELLED", "passport_number": "C3552763"}}, {"date": "2021-12-20 11:17:4", "user": "209", "prev_value": {"employer_id": "4", "employ_permit_id": "45"}}, {"date": "2021-12-20 11:17:12", "user": "209", "prev_value": {"host_id": "4"}}, {"date": "2022-02-17 10:41:6", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-03-14 13:30:44", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null, "work_permit_paid_till_date": null}}, {"date": "2022-04-26 11:35:25", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2276450", "visa_issued_date": "2022-02-07", "visa_expired_date": "2022-04-27", "visa_multiplicity": "SINGLE", "visa_started_date": "2022-02-07"}}, {"date": "2022-10-17 11:57:53", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2022-10-17 12:0:47", "user": "209", "prev_value": {"reg_date": "2022-02-17"}}]	1993-02-11	2017-06-23	2027-06-23	\N	\N	2022-01-17	2022-03-15	2022-12-13	\N	\N	\N	2022-04-11	2022-04-28	2022-12-13	2022-02-13	2022-02-13	2022-06-17	\N	232	64	0	1	2	2	0	2	0	\N	\N
195	AN4838083	ДИКАНОВ	ШУХРАТ	115	6	[3, 2, 4]	MALE														4620	0263837	САДИКЖАНОВИЧ				ДОМОДЕДОВО 640	МКК 50-32			КЫРГЫЗСТАН		[{"date": "2020-02-26 12:38:9", "user": "209", "prev_value": []}, {"date": "2020-02-26 12:39:40", "user": "209", "prev_value": {"host_id": "", "reg_date": "-0001-11-30", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "migr_card_issued_date": "-0001-11-30", "current_passport_number": ""}}, {"date": "2020-02-26 12:39:46", "user": "209", "prev_value": {"current_passport_number": ""}}, {"date": "2020-02-27 11:14:12", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "current_passport_number": ""}}, {"date": "2020-02-27 11:14:24", "user": "209", "prev_value": {"real_address_id": "", "current_passport_number": ""}}, {"date": "2020-02-27 11:15:41", "user": "209", "prev_value": {"migr_card_serie": "46 20", "current_passport_number": ""}}, {"date": "2020-02-27 11:20:36", "user": "209", "prev_value": {"visa_expired_date": "-0001-11-30", "current_passport_number": "", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2020-03-11 11:30:25", "user": "209", "prev_value": {"hired_date": null, "contract_number": ""}}, {"date": "2020-03-11 11:30:34", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2020-03-11 11:30:57", "user": "209", "prev_value": {"host_id": "4"}}, {"date": "2020-03-17 10:19:34", "user": "209", "prev_value": {"hired_date": "2010-03-11"}}, {"date": "2020-04-07 12:2:58", "user": "209", "prev_value": {"visa_expired_date": "2020-05-22", "work_permit_paid_till_date": null}}, {"date": "2020-04-07 12:54:51", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1984-10-23	2017-02-22	2027-02-22	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2021-03-10	2020-02-23	2020-02-23	2020-02-27	\N	0	0	0	7	2	2	0	0	0	\N	\N
196	#7734418884	Сосновская	Яна	177	1	[0]																	Ивановна										[{"date": "2020-04-21 12:14:6", "user": "207", "prev_value": []}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
197	#6910023875	Чинь	Динь Лан	177	1	[0]																											[{"date": "2020-04-21 12:16:28", "user": "207", "prev_value": []}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
199	C8797112	НГУЕН	ТХАНЬ ХАЙ	232	2	[3, 2, 4]	MALE																	NGUYEN	THANH HAI			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ИЕНБАЙ		[{"date": "2021-11-17 8:20:19", "user": "209", "prev_value": []}, {"date": "2021-11-17 8:20:43", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": ""}}, {"date": "2021-11-17 8:21:3", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2021-11-19 14:43:50", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2021-11-19 14:44:42", "user": "209", "prev_value": {"last_name_en": "HGUYEN"}}, {"date": "2022-05-16 12:57:43", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1994-08-04	2020-02-06	2030-02-06	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	63	0	1	2	2	0	0	0	\N	\N
200	C9794353	НГУЕН	ТХИ БИК ХАНГ	232	11	[3, 2, 4]	FEMALE						69	2200008603			MULTI	WORK	12	2196619	4620	7584980		NGUYEN	THI BICH HANG		шереметьево 1208	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАНОЙ		[{"date": "2021-11-17 8:29:27", "user": "209", "prev_value": []}, {"date": "2021-11-17 8:29:44", "user": "209", "prev_value": {"employer_id": "", "employ_permit_id": ""}}, {"date": "2021-11-17 8:29:55", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-01-24 10:30:13", "user": "209", "prev_value": {"occupation_id": "", "work_address_id": ""}}, {"date": "2022-01-24 10:35:20", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-01-24 10:42:3", "user": "209", "prev_value": {"migr_card_serie": "46 20", "visa_expired_date": "2022-11-09"}}, {"date": "2022-02-16 13:53:3", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-02-16 14:12:15", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-02-16 14:40:24", "user": "209", "prev_value": {"work_permit_expired_date": "2022-10-19"}}, {"date": "2022-03-14 12:57:0", "user": "209", "prev_value": {"reg_date": "2022-01-25", "visa_serie": "24", "visa_number": "1926491", "visa_issued_date": "2021-12-30", "visa_expired_date": "2022-03-14", "visa_multiplicity": "SINGLE", "visa_started_date": "2021-11-10"}}, {"date": "2022-10-03 15:2:7", "user": "209", "prev_value": {"employ_permit_id": "63"}}, {"date": "2022-11-02 11:39:58", "user": "209", "prev_value": {"work_permit_number": "2100006426", "work_permit_issued_date": "2021-12-15", "work_permit_expired_date": "2022-11-09", "work_permit_started_date": "2021-11-10"}}, {"date": "2022-11-02 11:41:19", "user": "209", "prev_value": {"visa_number": "1947403", "visa_issued_date": "2022-03-09", "visa_expired_date": "2022-11-09", "visa_started_date": "2022-03-15"}}, {"date": "2022-11-02 11:41:49", "user": "209", "prev_value": {"reg_date": "2022-03-15"}}]	1974-01-28	2021-07-29	2031-07-29	\N	\N	2022-10-26	2022-11-09	2023-11-08	\N	\N	\N	2022-10-27	2022-11-10	2023-11-08	2022-01-22	2022-01-22	2022-11-02	\N	232	81	0	1	2	2	0	2	0	\N	\N
228	C9911688	ЛЕ	АНЬ КУАН	232	2	[3, 2, 4]	MALE																	LE	ANH QUAN			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ИЕНБАЙ		[{"date": "2022-03-21 15:9:14", "user": "209", "prev_value": []}, {"date": "2022-03-21 15:9:41", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-03-21 15:10:2", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-08-22 11:47:9", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1986-10-07	2021-12-22	2031-12-22	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	70	0	4	2	2	0	0	0	\N	\N
201	C8872429	ДАНГ	КУАНГ ЗУИ	232	6	[3, 2, 4]	MALE						69	2200006557	202402380		MULTI	WORK	12	1947570	4622	0219329		DANG	QUANG DUY		ДОМОДЕВО 1824	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ИЕНБАЙ		[{"date": "2021-12-19 18:40:40", "user": "209", "prev_value": []}, {"date": "2021-12-19 18:43:27", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-19 18:43:48", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-02-22 13:31:29", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-04-11 11:43:54", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-04-11 11:46:10", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-04-26 11:50:22", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2276454", "visa_issued_date": "2022-02-07", "visa_expired_date": "2022-04-27", "visa_multiplicity": "SINGLE", "visa_started_date": "2022-02-07"}}, {"date": "2022-10-03 14:33:13", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1996-11-08	2020-02-07	2030-02-07	\N	\N	2022-01-17	2023-04-11	2022-12-13	\N	\N	\N	2022-04-20	2022-04-20	2022-12-13	2022-02-19	2022-02-19	2022-02-24	\N	232	65	0	4	2	2	0	2	0	\N	\N
203	C9869178	ЛЕ	ТХИ БИК НГУЕТ	232	11	[3, 2, 4]	FEMALE						69	2200008963	202402367		MULTI	WORK	12	2196941	4622	0197882		LE	THI BICH NGUYET		ДОМОДЕВО 1141	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАНЬХОА		[{"date": "2021-12-19 18:53:4", "user": "209", "prev_value": []}, {"date": "2021-12-19 18:53:38", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-19 18:53:58", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-02-16 17:25:44", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-03-28 11:44:52", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-03-28 11:49:6", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-04-26 11:55:27", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2276453", "visa_issued_date": "2022-02-07", "visa_expired_date": "2022-04-27", "visa_multiplicity": "SINGLE", "visa_started_date": "2022-02-07"}}, {"date": "2022-10-27 15:43:55", "user": "209", "prev_value": {"occupation_id": "3"}}, {"date": "2022-12-08 15:52:30", "user": "209", "prev_value": {"employ_permit_id": "65", "work_permit_number": "2200006532", "work_permit_issued_date": "2022-01-17", "work_permit_expired_date": "2022-12-13", "work_permit_started_date": "2022-03-29"}}, {"date": "2022-12-08 15:53:39", "user": "209", "prev_value": {"reg_date": "2022-02-17", "visa_number": "1947544", "visa_issued_date": "2022-04-18", "visa_expired_date": "2022-12-13", "visa_started_date": "2022-04-18"}}]	1984-03-19	2021-11-02	2031-11-02	\N	\N	2022-11-30	2022-12-13	2023-12-12	\N	\N	\N	2022-12-02	2022-12-13	2023-12-12	2022-02-13	2022-02-13	2022-12-13	\N	232	84	0	4	2	2	0	2	0	\N	\N
204	C9857796	ЛЕ	ВАН ТЮНГ	232	2	[3, 2, 4]	MALE																	LE	VAN CHUNG			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАНЬХОА		[{"date": "2021-12-19 18:57:22", "user": "209", "prev_value": []}, {"date": "2021-12-19 18:57:52", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-19 18:58:7", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-05-16 12:58:5", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	2003-01-17	2021-10-26	2031-10-26	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	65	0	4	2	2	0	0	0	\N	\N
205	C9866307	ХОАНГ	ТХИ ХАНГ	232	11	[3, 2, 4]	FEMALE						69	2200008748	202402356		MULTI	WORK	12	2196948	4622	0224914		HOANG 	THI HANG		ДОМОДЕВО 1140	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАНЬХОА		[{"date": "2021-12-20 10:35:5", "user": "209", "prev_value": []}, {"date": "2021-12-20 10:35:35", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-20 10:35:49", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-02-22 13:36:17", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-03-28 12:12:8", "user": "209", "prev_value": {"status_id": "SEEKER", "fired_date": null, "hired_date": null, "contract_number": ""}}, {"date": "2022-03-28 12:13:53", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-04-26 10:31:58", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2276772", "visa_issued_date": "2022-02-07", "visa_expired_date": "2022-04-27", "visa_started_date": "2022-02-15"}}, {"date": "2022-04-26 11:40:52", "user": "209", "prev_value": {"visa_multiplicity": "SINGLE"}}, {"date": "2022-10-27 17:23:25", "user": "209", "prev_value": {"occupation_id": "4", "employ_permit_id": "64"}}, {"date": "2022-12-08 14:31:51", "user": "209", "prev_value": {"work_permit_number": "2200006500", "work_permit_issued_date": "2022-01-17", "work_permit_expired_date": "2022-12-13", "work_permit_started_date": "2022-03-29"}}, {"date": "2022-12-08 14:32:55", "user": "209", "prev_value": {"reg_date": "2022-02-24", "visa_number": "1947558", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2022-04-18", "visa_expired_date": "2022-12-13", "visa_started_date": "2022-04-18"}}]	1989-03-10	2021-11-08	2031-11-08	\N	\N	2022-11-21	2022-12-13	2023-11-08	\N	\N	\N	2022-12-02	2022-12-14	2023-11-08	2022-02-19	2022-02-19	2022-12-13	\N	232	81	0	1	2	2	0	2	0	\N	\N
206	C9854793	ЛО	ВАН ДАТ	232	11	[3, 2, 4]	MALE						69	2200008730	202402366		MULTI	WORK	12	2196946	4622	0186375		LO	VAN DAT		ДОМОДЕВО 378	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАНЬХОА		[{"date": "2021-12-20 10:38:29", "user": "209", "prev_value": []}, {"date": "2021-12-20 10:38:51", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-20 10:39:5", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2021-12-20 15:32:11", "user": "209", "prev_value": {"passport_issued_date": null, "passport_expired_date": null}}, {"date": "2022-02-17 10:37:50", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-02-17 10:59:6", "user": "209", "prev_value": {"visa_expired_date": "2022-04-02"}}, {"date": "2022-03-14 13:51:36", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null, "work_permit_paid_till_date": null}}, {"date": "2022-04-26 11:18:12", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2276451", "visa_issued_date": "2022-02-07", "visa_expired_date": "2022-04-27", "visa_started_date": "2022-02-07"}}, {"date": "2022-04-26 11:41:19", "user": "209", "prev_value": {"visa_multiplicity": "SINGLE"}}, {"date": "2022-10-27 16:56:36", "user": "209", "prev_value": {"occupation_id": "3", "employ_permit_id": "64"}}, {"date": "2022-12-08 14:3:37", "user": "209", "prev_value": {"work_permit_number": "2200006518", "work_permit_issued_date": "2022-01-17", "work_permit_expired_date": "2022-12-13", "work_permit_started_date": "2022-03-15"}}, {"date": "2022-12-08 14:4:50", "user": "209", "prev_value": {"reg_date": "2022-02-17", "visa_number": "1947517", "visa_issued_date": "2022-04-11", "visa_expired_date": "2022-12-13", "visa_started_date": "2022-04-28"}}]	1984-03-01	2021-11-02	2031-11-02	\N	\N	2022-11-21	2022-12-13	2023-11-08	\N	\N	\N	2022-12-02	2022-12-14	2023-11-08	2022-02-13	2022-02-13	2022-12-13	\N	232	81	0	1	2	2	0	2	0	\N	\N
208	C9854780	НГУЕН	ВАН ЧОНГ	232	11	[3, 2, 4]	MALE						69	2200008755	202402365		MULTI	WORK	12	2196947	4622	0196367		NGUYEN	VAN TRONG		ДОМОДЕВО 1507	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАНЬХОА		[{"date": "2021-12-20 10:44:36", "user": "209", "prev_value": []}, {"date": "2021-12-20 10:45:10", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-20 10:45:23", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-02-17 10:44:9", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-03-28 12:34:54", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-03-28 12:35:54", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-04-26 10:45:49", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2276446", "visa_issued_date": "2022-02-07", "visa_expired_date": "2022-04-27", "visa_started_date": "2022-02-07"}}, {"date": "2022-10-27 17:14:50", "user": "209", "prev_value": {"employ_permit_id": "64"}}, {"date": "2022-12-08 14:16:32", "user": "209", "prev_value": {"work_permit_number": "2200006476", "work_permit_issued_date": "2022-01-17", "work_permit_expired_date": "2022-12-13", "work_permit_started_date": "2022-03-29"}}, {"date": "2022-12-08 14:18:22", "user": "209", "prev_value": {"visa_number": "1947555", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2022-04-18", "visa_expired_date": "2022-12-13", "visa_multiplicity": "SINGLE", "visa_started_date": "2022-04-18", "migr_card_issued_date": "2022-02-13"}}, {"date": "2022-12-08 14:19:17", "user": "209", "prev_value": {"reg_date": "2022-02-17", "migr_card_issued_date": "2022-12-13"}}, {"date": "2022-12-08 15:24:54", "user": "209", "prev_value": {"work_permit_issued_date": "2023-11-08"}}]	1992-06-26	2021-11-02	2031-11-02	\N	\N	2022-11-21	2022-12-13	2023-11-08	\N	\N	\N	2022-12-02	2022-12-14	2023-11-08	2022-02-13	2022-02-13	2022-12-13	\N	232	81	0	1	2	2	0	2	0	\N	\N
209	C9854781	КУАТЬ	ТХИ ЧАНГ	232	11	[3, 2, 4]	FEMALE						69	2200008762	202402364		MULTI	WORK	12	2196944	4622	0203223		QUACH	THI TRANG		ДОМОДЕВО 1011	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАНЬХОА		[{"date": "2021-12-20 10:48:14", "user": "209", "prev_value": []}, {"date": "2021-12-20 10:48:40", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-20 10:48:53", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-02-16 17:4:22", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-03-28 12:53:40", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-03-28 12:55:33", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-04-26 11:27:36", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2276449", "visa_issued_date": "2022-02-07", "visa_expired_date": "2022-04-27", "visa_started_date": "1970-01-01"}}, {"date": "2022-04-26 11:41:50", "user": "209", "prev_value": {"visa_multiplicity": "SINGLE"}}, {"date": "2022-12-08 13:19:30", "user": "209", "prev_value": {"employ_permit_id": "64", "work_permit_number": "2200006483", "work_permit_issued_date": "2022-01-17", "work_permit_expired_date": "2022-12-13", "work_permit_started_date": "2022-03-29"}}, {"date": "2022-12-08 13:21:4", "user": "209", "prev_value": {"reg_date": "2022-02-17", "visa_number": "1947556", "visa_issued_date": "2022-04-18", "visa_expired_date": "2022-12-13", "visa_started_date": "2022-04-18"}}]	2000-01-22	2021-11-02	2031-11-02	\N	\N	2022-11-21	2022-12-13	2023-11-08	\N	\N	\N	2022-12-02	2022-12-14	2023-11-08	2022-02-13	2022-02-13	2022-12-13	\N	232	81	0	1	2	2	0	2	0	\N	\N
212	C9866308	ЛЕ	ХЫУ ТИНЬ	232	11	[3, 2, 4]	MALE						69	2200008770	202402357		MULTI	WORK	12	2196945	4622	0200755		LE	HUU CHINH		ДОМОДЕВО 1273	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ					[{"date": "2021-12-20 10:55:1", "user": "209", "prev_value": []}, {"date": "2021-12-20 10:55:26", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-20 10:55:37", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-02-16 17:14:31", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-03-28 13:13:38", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-03-28 13:14:52", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-03-28 13:17:56", "user": "209", "prev_value": {"work_permit_expired_date": "1970-01-01"}}, {"date": "2022-04-26 11:22:32", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2276447", "visa_issued_date": "2022-02-07", "visa_expired_date": "2022-04-27", "visa_started_date": "2022-02-07"}}, {"date": "2022-04-26 11:41:36", "user": "209", "prev_value": {"visa_multiplicity": "SINGLE"}}, {"date": "2022-10-27 16:39:58", "user": "209", "prev_value": {"employ_permit_id": "64"}}, {"date": "2022-12-08 13:43:48", "user": "209", "prev_value": {"work_permit_number": "2200006490", "work_permit_issued_date": "2022-01-17", "work_permit_expired_date": "2022-12-13", "work_permit_started_date": "2022-03-29"}}, {"date": "2022-12-08 13:48:1", "user": "209", "prev_value": {"reg_date": "2022-02-17", "visa_number": "1947557", "visa_issued_date": "2022-04-18", "visa_expired_date": "2022-12-13", "visa_started_date": "2022-04-18"}}]	1990-06-23	2021-11-08	2031-11-08	\N	\N	2022-11-21	2022-12-13	2023-11-08	\N	\N	\N	2022-12-02	2022-12-14	2023-11-08	2022-02-13	2022-02-13	2022-12-13	\N	232	81	0	1	2	2	0	2	0	\N	\N
213	C0505154	НГУЕН	ЧИ ТХАНЬ	232	2	[3, 2, 4]	MALE																	NGUYEN	TRI THANH			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХОАБИНЬ		[{"date": "2021-12-20 10:59:31", "user": "209", "prev_value": []}, {"date": "2021-12-20 11:0:5", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-20 11:0:15", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-01-25 14:13:57", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1994-09-17	2015-06-03	2025-06-03	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	64	0	1	2	2	0	0	0	\N	\N
214	B7399865	ЛЕ	ДАК ДОАН	232	2	[3, 2, 4]	MALE																	LE	DAC DOAN			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАЙНГУЕН		[{"date": "2021-12-20 11:4:13", "user": "209", "prev_value": []}, {"date": "2021-12-20 11:4:41", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-20 11:4:54", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-01-18 13:21:44", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1990-05-07	2013-01-17	2023-01-17	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	64	0	1	2	2	0	0	0	\N	\N
218	K0065416	ДАМ	КУАНГ ЧУНГ	232	11	[3, 2, 4]	MALE						69	2200008949	202400032		MULTI	WORK	12	2196943	4120	0016496		DAM	QUANG TRUNG		Шереметьево 1320	ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ			Тхайбинь		[{"date": "2022-01-18 13:45:26", "user": "209", "prev_value": []}, {"date": "2022-01-18 13:45:54", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-01-18 13:46:9", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-03-09 10:50:39", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-04-11 12:13:38", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-04-11 12:15:8", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-04-26 9:32:19", "user": "209", "prev_value": {"passport_number": "N2093427", "passport_issued_date": "2019-07-18", "passport_expired_date": "2029-07-18"}}, {"date": "2022-05-17 14:0:43", "user": "209", "prev_value": {"work_permit_issued_date": "2022-02-08"}}, {"date": "2022-05-17 14:10:7", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2277483", "visa_issued_date": "2022-03-01", "visa_expired_date": "2022-05-18", "visa_started_date": "2022-03-01"}}, {"date": "2022-05-17 15:39:51", "user": "209", "prev_value": {"migr_card_serie": "4620", "migr_card_number": "7683996"}}, {"date": "2022-12-08 15:17:31", "user": "209", "prev_value": {"employ_permit_id": "64", "work_permit_number": "2200006733", "work_permit_issued_date": "2022-05-13", "work_permit_expired_date": "2022-12-13", "work_permit_started_date": "2022-04-11"}}, {"date": "2022-12-08 15:18:53", "user": "209", "prev_value": {"reg_date": "2022-03-09", "visa_number": "2163592", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2022-05-16", "visa_expired_date": "2022-12-13", "visa_multiplicity": "SINGLE", "visa_started_date": "2022-05-19"}}]	1981-10-05	2022-04-20	2032-04-20	\N	\N	2022-11-30	2022-12-13	2023-12-12	\N	\N	\N	2022-12-02	2022-12-14	2023-12-12	2022-03-05	2022-03-05	2022-12-13	\N	232	83	0	1	2	2	0	2	0	\N	\N
221	#5	КПП Шереметьево	Начальник	0	9	[0]																											[{"date": "2022-02-09 11:21:43", "user": "207", "prev_value": {"last_name_ru": " Ф", "first_name_ru": " И", "middle_name_ru": "О"}}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
222	#6	КПП Домодедово	Начальник	0	9	[0]																											[{"date": "2022-02-09 11:23:27", "user": "207", "prev_value": {"employer_id": ""}}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
223	C9926913	НГУЕН	ТХЕ ДИНЬ	232	6	[3, 2, 4]	MALE						69	2200007060	202400121		SINGLE	WORK	12	2163757	4522	0344112		NGUYEN	THE DINH		ВНУКОВО 389	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАНАМ		[{"date": "2022-02-22 13:42:37", "user": "209", "prev_value": []}, {"date": "2022-02-22 13:45:12", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-02-22 13:45:31", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-05-05 11:48:6", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-05-19 12:16:49", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-05-19 12:20:46", "user": "209", "prev_value": {"hired_date": null, "contract_number": ""}}, {"date": "2022-05-19 13:5:37", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2022-06-22 12:43:16", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2279555", "visa_issued_date": "2022-04-22", "visa_expired_date": "2022-06-29", "visa_started_date": "2022-04-22"}}, {"date": "2022-08-29 10:12:43", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1989-10-09	2022-01-24	2032-01-24	\N	\N	2022-03-21	2022-05-20	2023-02-23	\N	\N	\N	2022-06-08	2022-06-30	2023-02-23	2022-05-02	2022-05-02	2022-05-05	\N	232	69	0	1	2	2	0	2	0	\N	\N
224	C6778096	ЧАН	ХАЙ КУАНГ	232	11	[3, 2, 4]	MALE						69	2200007053	202400120		MULTI	WORK	12	2163808	4622	0605301		TRAN	HAI QUANG		домодедово 1830	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХЫАТХИЕН-ХЮЭ		[{"date": "2022-02-22 14:6:59", "user": "209", "prev_value": []}, {"date": "2022-02-22 14:7:21", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-02-22 14:7:33", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-06-02 10:58:7", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-06-02 11:2:59", "user": "209", "prev_value": {"migr_card_serie": "46 22"}}, {"date": "2022-06-20 13:54:34", "user": "209", "prev_value": {"hired_date": null, "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-06-20 13:54:42", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2022-06-20 13:55:11", "user": "209", "prev_value": {"reg_date": "2022-06-02"}}, {"date": "2022-06-29 11:54:54", "user": "209", "prev_value": {"visa_serie": "24", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_multiplicity": "SINGLE"}}, {"date": "2022-06-29 11:56:8", "user": "209", "prev_value": {"visa_serie": "", "visa_number": "2280088", "visa_issued_date": "2022-05-11", "visa_expired_date": "2022-06-29", "visa_started_date": "2022-05-11"}}]	1988-10-03	2019-02-20	2029-02-20	\N	\N	2022-03-21	2022-06-20	2023-02-23	\N	\N	\N	2022-06-27	2022-06-30	2023-02-23	2022-06-01	2022-06-01	2022-06-16	\N	232	69	0	1	2	2	0	2	0	\N	\N
225	C6778097	НГУЕН	ТХИ ТХАНЬ МИ	232	11	[3, 2, 4]	FEMALE						69	2200007039	202400123		SINGLE	WORK	12	2163807	4622	0619259		NGUYEN	THI THANH MY		домодедово1094	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХЫАТХИЕН-ХЮЭ		[{"date": "2022-02-22 16:39:18", "user": "209", "prev_value": []}, {"date": "2022-02-22 16:39:40", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-02-22 16:39:54", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-06-02 11:20:27", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-06-02 11:22:27", "user": "209", "prev_value": {"migr_card_serie": "46 22"}}, {"date": "2022-06-20 13:28:20", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-06-20 13:28:50", "user": "209", "prev_value": {"reg_date": "2022-06-02"}}, {"date": "2022-06-29 11:29:58", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2280089", "visa_issued_date": "2022-05-11", "visa_expired_date": "2022-06-29", "visa_started_date": "2022-05-11"}}, {"date": "2022-12-12 14:40:14", "user": "209", "prev_value": {"reg_date": "2022-06-16"}}]	1997-03-06	2019-02-20	2029-02-20	\N	\N	2022-03-21	2022-06-20	2023-02-23	\N	\N	\N	2022-06-27	2022-06-30	2023-02-23	2022-06-01	2022-06-01	2022-06-29	\N	232	69	0	1	2	2	0	2	0	\N	\N
226	C9069499	ФАМ	ВИЕТ ТУИ	232	6	[3, 2, 4]	MALE						69	2200007046	202400122		SINGLE	WORK	12	2163758	4522	0331875		PHAM	VIET TUY		ВНУКОВО 396	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАЙЗЫОНГ		[{"date": "2022-02-22 17:3:11", "user": "209", "prev_value": []}, {"date": "2022-02-22 17:3:28", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-02-22 17:3:39", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-05-05 11:58:47", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-05-19 12:57:40", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-05-19 12:58:4", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-06-22 13:19:43", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2279556", "visa_issued_date": "2022-04-22", "visa_expired_date": "2022-06-29", "visa_started_date": "2022-04-22"}}, {"date": "2022-08-29 11:43:15", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}]	1991-11-20	2020-03-23	2030-03-23	\N	\N	2022-03-21	2022-05-20	2023-02-23	\N	\N	\N	2022-06-08	2022-06-30	2023-02-23	2022-05-02	2022-01-02	2022-05-05	\N	0	69	0	1	2	2	0	2	0	\N	\N
227	C9966911	НГО	ТХИ ХОНГ ТЫОЙ	232	6	[3, 2, 4]	FEMALE						69	2200007430			MULTI	WORK	12	2163904	4622	0758625		NGO	THI HONG TUOI		ДОМОДЕВО 1319	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			Тхайбинь		[{"date": "2022-03-21 15:0:32", "user": "209", "prev_value": []}, {"date": "2022-03-21 15:1:21", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-03-21 15:1:40", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-07-01 11:47:58", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-07-12 15:13:56", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-07-15 12:12:1", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-08-02 13:8:8", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2280591", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2022-05-24", "visa_expired_date": "2022-08-03", "visa_multiplicity": "SINGLE", "visa_started_date": "2022-05-24"}}, {"date": "2022-12-14 15:59:47", "user": "209", "prev_value": {"fired_date": null}}, {"date": "2022-12-14 16:0:24", "user": "209", "prev_value": {"reg_date": "2022-07-01"}}, {"date": "2022-12-19 11:0:35", "user": "209", "prev_value": {"status_id": "WORKER"}}]	1999-11-27	2022-02-17	2032-02-17	\N	\N	2022-04-25	2022-07-14	2023-02-23	\N	\N	\N	2022-07-28	2022-08-04	2023-02-23	2022-06-30	2022-06-30	2022-08-02	\N	232	70	0	4	2	2	0	2	0	\N	\N
230	C9918534	ДАМ	ДИНЬ ТУЕН	232	11	[3, 2, 4]	MALE						69	2200007448	202400222		SINGLE	WORK	12	2163903	4622	0747863		DAM	DINH TUYEN		ДОМОДЕВО 1234	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			Тхайбинь		[{"date": "2022-03-21 15:17:27", "user": "209", "prev_value": []}, {"date": "2022-03-21 15:17:48", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-03-21 15:18:3", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-07-01 11:58:2", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-07-11 11:54:2", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-07-15 11:52:54", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-08-02 12:59:21", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2280592", "visa_issued_date": "2022-05-24", "visa_expired_date": "2022-08-03", "visa_started_date": "2022-05-24"}}]	1991-05-22	2022-01-25	2032-01-25	\N	\N	2022-04-25	2022-07-14	2023-02-23	\N	\N	\N	2022-07-28	2022-08-04	2023-02-23	2022-06-30	2022-06-30	2022-07-01	\N	232	70	0	4	2	2	0	2	0	\N	\N
231	C9731529	ХИНЬ	НГОК НЯН	232	2	[3, 2, 4]	MALE																	HUYNH	NGOC NHAN			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ФУИЕН		[{"date": "2022-04-05 15:38:5", "user": "209", "prev_value": []}, {"date": "2022-04-05 15:38:36", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-04-05 15:38:53", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-08-22 11:47:38", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1996-03-03	2021-12-16	2031-12-16	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	70	0	4	2	2	0	0	0	\N	\N
233	#7	КПП Внуково	Начальник	177	9	[0]																											[{"date": "2022-04-28 12:52:35", "user": "207", "prev_value": {"gender": "MALE"}}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	0	0	\N	\N
234	с9392617	НГУЕН	ХАК ЗАУ	232	4	[3, 2, 4]	MALE																	NGUYEN	KHAC DAU			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАНОЙ		[{"date": "2022-05-17 17:3:39", "user": "209", "prev_value": []}, {"date": "2022-05-17 17:4:4", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-05-17 17:4:17", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-06-22 13:40:28", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1993-07-10	2020-10-27	2030-10-27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	67	0	1	2	2	0	0	0	\N	\N
235	Р00046659	ЧЫОНГ	НГОК	232	11	[3, 2, 4]	MALE						69	2200008018	202400576		SINGLE	WORK	12	2196568	4620	4575306		TRUONG	NGOC		Шереметьево 546	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ВЬЕТНАМ		[{"date": "2022-07-19 14:28:13", "user": "209", "prev_value": []}, {"date": "2022-07-19 14:28:40", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-07-19 14:28:55", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-09-19 10:49:41", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-10-07 12:12:52", "user": "209", "prev_value": {"status_id": "SEEKER", "fired_date": null, "hired_date": null, "contract_number": ""}}, {"date": "2022-10-07 12:14:35", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-11-02 12:12:40", "user": "209", "prev_value": {"reg_date": "2022-09-20", "visa_serie": "24", "visa_number": "5208740", "visa_issued_date": "2022-08-30", "visa_expired_date": "2022-11-13", "visa_started_date": "2022-08-30"}}, {"date": "2022-12-19 11:2:9", "user": "209", "prev_value": {"hired_date": "2023-10-07"}}]	1996-10-10	2022-07-07	2032-07-07	\N	\N	2022-08-09	2022-10-07	2023-06-19	\N	\N	\N	2022-10-24	2022-11-14	2023-06-19	2022-09-15	2022-09-15	2022-11-02	\N	232	79	0	4	2	2	0	2	0	\N	\N
236	Р00046274	ФАН	ТХАНЬ	232	11	[3, 2, 4]	MALE						69	2200008025	202400574		SINGLE	WORK	12	2196646	4620	4739151		PHAN	THANH		Шереметьево 1219	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ВЬЕТНАМ		[{"date": "2022-07-19 14:39:26", "user": "209", "prev_value": []}, {"date": "2022-07-19 14:40:9", "user": "209", "prev_value": {"host_id": "", "employer_id": "", "occupation_id": "", "reg_address_id": "", "real_address_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-09-19 10:37:12", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-10-07 13:16:0", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-10-07 13:17:9", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-11-07 12:24:12", "user": "209", "prev_value": {"reg_date": "2022-09-20", "visa_serie": "24", "visa_number": "5208741", "visa_issued_date": "2022-08-30", "visa_expired_date": "2022-11-13", "visa_started_date": "2022-08-30"}}]	1996-09-03	2022-07-07	2032-07-07	\N	\N	2022-08-09	2022-10-07	2023-06-19	\N	\N	\N	2022-11-02	2022-11-14	2023-06-19	2022-09-15	2022-09-15	2022-11-07	\N	232	79	0	4	2	2	0	2	0	\N	\N
237	C0264872	ЧАН	ВАН ЛАП	232	11	[3, 2, 4]	MALE						69	2200008000	202400789		SINGLE	WORK	12	2196570	4620	4739152		TRAN	VAN LAP		Шереметьево 1219	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХЫАТХИЕН-ХЮЭ		[{"date": "2022-07-19 14:48:12", "user": "209", "prev_value": []}, {"date": "2022-07-19 14:48:32", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-07-19 14:48:44", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-07-19 14:54:48", "user": "209", "prev_value": {"passport_issued_date": null, "passport_expired_date": null}}, {"date": "2022-07-19 15:50:34", "user": "209", "prev_value": {"birth_place": "ВЬЕТНАМ"}}, {"date": "2022-09-19 10:56:16", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-10-07 12:55:0", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-10-07 12:56:13", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-11-02 12:21:51", "user": "209", "prev_value": {"reg_date": "2022-09-20", "visa_serie": "24", "visa_number": "5208739", "visa_issued_date": "2022-08-30", "visa_expired_date": "2022-11-13", "visa_started_date": "2022-08-30"}}]	1988-01-01	2015-04-16	2025-04-16	\N	\N	2022-08-09	2022-10-07	2023-06-19	\N	\N	\N	2022-10-24	2022-11-14	2023-06-19	2022-09-15	2022-09-15	2022-11-02	\N	232	79	0	4	2	2	0	2	0	\N	\N
238	C2171467	ТО	ВАН ЗУНГ	232	11	[3, 2, 4]	MALE						69	2200008427	202401136		MULTI	WORK	12	2196899	4620	4791120		TO	VAN DUNG		Шереметьево 579	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			НАМДИНЬ		[{"date": "2022-07-19 15:29:13", "user": "209", "prev_value": []}, {"date": "2022-07-19 15:29:46", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": ""}}, {"date": "2022-07-19 15:29:58", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-08-29 9:44:41", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2022-10-25 12:6:52", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-11-09 14:53:35", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-11-09 14:55:2", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-12-08 14:58:26", "user": "209", "prev_value": {"reg_date": "2022-10-25", "visa_serie": "24", "visa_number": "5111209", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2022-10-11", "visa_expired_date": "2022-12-24", "visa_multiplicity": "SINGLE", "visa_started_date": "2022-10-11"}}]	1985-06-24	2016-08-09	2026-08-09	\N	\N	2022-09-16	2022-11-10	2023-08-19	\N	\N	\N	2022-11-28	2022-12-25	2023-08-19	2022-10-20	2022-10-20	2022-12-13	\N	232	80	0	1	2	2	0	2	0	\N	\N
239	Р00059007	НГУЕН	ТХЕ АНЬ ТУАН	232	11	[3, 2, 4]	MALE						69	2200008410	202400892		SINGLE	WORK	12	2196900	4620	4768718		NGUYEN	THE ANH TUAN		Шереметьево 585	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ВЬЕТНАМ		[{"date": "2022-07-19 15:32:46", "user": "209", "prev_value": []}, {"date": "2022-07-19 15:32:58", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": ""}}, {"date": "2022-07-19 15:33:9", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-08-26 13:32:55", "user": "209", "prev_value": {"passport_expired_date": null}}, {"date": "2022-08-29 9:44:27", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2022-10-25 12:13:44", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-11-09 14:33:59", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-11-09 14:35:21", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-12-08 14:52:59", "user": "209", "prev_value": {"reg_date": "2022-10-25", "visa_serie": "24", "visa_number": "5111211", "visa_issued_date": "2022-10-11", "visa_expired_date": "2022-12-24", "visa_started_date": "2022-10-11"}}]	2001-04-29	2022-07-10	2032-07-10	\N	\N	2022-09-16	2022-11-10	2023-08-19	\N	\N	\N	2022-11-28	2022-12-25	2023-08-19	2022-10-20	2022-10-20	2022-12-13	\N	232	80	0	1	2	2	0	2	0	\N	\N
240	Р00059008	НГУЕН	ТХЕ АНЬ ТУ	232	11	[3, 2, 4]	MALE						69	2200008402	202400894		MULTI	WORK	12	2196898	4620	4792087		NGUYEN	THE ANH TU		шереметьево 605	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ВЬЕТНАМ		[{"date": "2022-07-19 15:36:25", "user": "209", "prev_value": []}, {"date": "2022-07-19 15:36:50", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": ""}}, {"date": "2022-07-19 15:37:2", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-08-29 9:44:8", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2022-10-25 12:18:52", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-11-09 14:12:4", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": ""}}, {"date": "2022-11-09 14:14:3", "user": "209", "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}, {"date": "2022-12-08 14:46:10", "user": "209", "prev_value": {"reg_date": "2022-10-25", "visa_serie": "24", "visa_number": "5111210", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2022-10-11", "visa_expired_date": "2022-12-24", "visa_multiplicity": "SINGLE", "visa_started_date": "2022-10-11"}}]	2004-06-28	2022-07-10	2032-07-10	\N	\N	2022-09-16	2022-11-10	2023-08-19	\N	\N	\N	2022-11-28	2022-12-25	2023-08-19	2022-10-20	2022-10-20	2022-12-13	\N	232	80	0	4	2	2	0	2	0	\N	\N
244	C4079939	ХА	ТХИ ЗОАН	232	2	[3, 2, 4]	FEMALE																	HA	THI DOAN			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ИЕНБАЙ		[{"date": "2022-09-29 11:17:34", "user": "209", "prev_value": []}, {"date": "2022-09-29 11:17:51", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": ""}}, {"date": "2022-09-29 11:18:8", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-10-03 14:25:47", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	1991-11-11	2017-10-26	2027-10-26	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	0	0	1	2	2	0	0	0	\N	\N
245	Р00101705	НГУЕН	ТИЕН ТХАНЬ	232	2	[3, 2, 4]	MALE																	NGUYEN	TIEN THANH			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ					[{"date": "2022-09-29 11:21:30", "user": "209", "prev_value": []}, {"date": "2022-09-29 11:22:6", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": ""}}, {"date": "2022-09-29 11:22:20", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-10-03 14:26:47", "user": "209", "prev_value": {"status_id": "SEEKER"}}]	2003-06-08	2022-07-14	2023-07-14	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	0	0	1	2	2	0	0	0	\N	\N
247	Р00670008	НГУЕН	ТИЕН АНЬ	232	11	[3, 2, 4]	MALE						69	2200008635	202401709		SINGLE	WORK	24	5114261	4620	4880024		NGUYEN	TIEN ANH		Шереметьево 1539	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ					[{"date": "2022-10-11 13:21:25", "user": "209", "prev_value": []}, {"date": "2022-10-11 13:21:52", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-10-11 13:22:8", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-12-27 11:50:3", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2023-01-18 11:19:10", "user": 3, "prev_value": {"status_id": 10}}, {"date": "2023-01-18 11:22:21", "user": 3, "prev_value": {"work_permit_issuer_id": 0, "work_permit_started_date": null}}, {"date": "2023-01-18 11:23:47", "user": 3, "prev_value": {"work_permit_expired_date": null}}, {"date": "2023-01-23 11:37:39", "user": 3, "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null}}]	1985-06-16	2022-09-21	2032-09-21	\N	\N	2022-11-07	2023-01-23	2023-10-05	\N	\N	\N	2022-12-19	2022-12-19	2023-02-12	2022-12-23	2022-12-23	2022-12-27	\N	232	82	0	1	2	2	0	2	0	\N	2023-01-23 11:37:39
248	C4034959	НГО	КУАНГ ХУНГ	232	2	[3, 2, 4]	MALE																	NGO	QUANG HUNG			МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ХАНОЙ		[{"date": "2022-10-11 13:26:26", "user": "209", "prev_value": []}, {"date": "2022-10-11 13:26:52", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2022-10-11 13:27:6", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-10-12 14:40:43", "user": "209", "prev_value": {"birth_place": ""}}, {"date": "2023-02-13 9:17:7", "user": 3, "prev_value": {"status_id": 10}}]	1977-01-01	2017-10-19	2027-10-19	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	82	0	1	2	2	0	0	0	\N	2023-02-13 09:17:07
105	N1789540	Нгуен	Фыонг Нам	232	1	[3, 2]	MALE			82	0261656													Nguyen	Phuong Nam			ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ	RESIDENT_CARD		ХАТИНЬ		[{"date": "2018-11-28 15:18:2", "user": "209", "prev_value": {"resident_document_serie": "", "resident_document_number": "", "resident_document_issuer_id": "", "resident_document_issued_date": "-0001-11-30", "resident_document_expired_date": "-0001-11-30"}}, {"date": "2019-03-15 10:37:12", "user": "208", "prev_value": {"resident_document_issuer_id": "2"}}, {"date": "2021-09-03 13:10:45", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2022-01-17 11:12:20", "user": "209", "prev_value": {"status_id": "FIRED", "fired_date": "2016-07-31", "employer_id": "4"}}, {"date": "2022-01-17 11:15:43", "user": "209", "prev_value": {"host_id": "4"}}, {"date": "2022-01-17 11:16:26", "user": "209", "prev_value": {"work_address_id": ""}}, {"date": "2023-01-03 22:14:18", "user": 1, "prev_value": {"status_id": 11}}, {"date": "2023-01-03 22:31:44", "user": 1, "prev_value": {"last_name_en": "NQUYEN"}}, {"date": "2023-01-04 16:0:0", "user": 3, "prev_value": {"last_name_en": "NGUYEN", "last_name_ru": "НГУЕН", "first_name_en": "PHUONG NAM", "first_name_ru": "ФЫОНГ НАМ"}}]	1967-03-07	2016-09-19	2026-09-19	2012-04-16	2022-04-05	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2017-01-25	\N	232	0	0	1	11	0	0	0	0	\N	2023-01-04 16:00:00
241	N2256125	Фам	Тхи Хиен	232	1	[3, 2]	FEMALE																	Pham	Thi Hien			ПОСОЛЬСТВО ВЬЕТНАМА В РОССИИ			Тхайбинь		[{"date": "2022-07-26 13:46:23", "user": "209", "prev_value": []}, {"date": "2022-07-26 13:52:49", "user": "209", "prev_value": {"employer_id": ""}}, {"date": "2022-07-26 14:1:46", "user": "209", "prev_value": {"occupation_id": "", "work_address_id": ""}}, {"date": "2022-07-26 14:6:36", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-07-26 14:29:33", "user": "207", "prev_value": {"status_id": "WORKER"}}, {"date": "2022-07-26 14:37:30", "user": "207", "prev_value": []}, {"date": "2022-07-26 14:37:51", "user": "207", "prev_value": {"status_id": "BOSS"}}, {"date": "2022-07-26 14:44:54", "user": "209", "prev_value": {"status_id": "WORKER"}}, {"date": "2022-07-26 15:6:11", "user": "209", "prev_value": {"hired_date": "2022-07-27", "employer_id": "1", "contract_number": "13"}}, {"date": "2022-07-26 15:6:19", "user": "209", "prev_value": {"host_id": "1"}}, {"date": "2022-07-26 15:50:30", "user": "209", "prev_value": {"employer_id": "4"}}, {"date": "2022-07-26 15:50:40", "user": "209", "prev_value": {"hired_date": "2022-07-22"}}, {"date": "2022-07-26 15:50:51", "user": "209", "prev_value": {"contract_number": "6"}}, {"date": "2022-07-26 15:50:59", "user": "209", "prev_value": {"host_id": "4"}}, {"date": "2023-01-04 16:3:32", "user": 1, "prev_value": {"last_name_en": "PHAM", "last_name_ru": "ФАМ", "first_name_en": "THI HIEN", "first_name_ru": "ТХИ ХИЕН"}}]	1982-02-09	2021-05-12	2031-05-12	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	232	0	0	1	20	20	0	0	0	\N	2023-01-04 16:03:32
147	401078036	ЧАБОРОВ	КЕНЧАБОЙ	209	6	[3, 2, 4]	MALE						69	2100093926							4622	1207746	ЧАЛИЛОВИЧ				ДОМОДЕВО 768	ОВД В ХУДЖАНДЕ					[{"date": "2019-03-14 13:3:6", "user": "209", "prev_value": []}, {"date": "2019-03-14 13:3:22", "user": "209", "prev_value": {"employer_id": "", "occupation_id": ""}}, {"date": "2019-03-14 13:4:45", "user": "209", "prev_value": {"host_id": "", "entry_date": "-0001-11-30", "reg_address_id": "", "migr_card_serie": "", "real_address_id": "", "entry_checkpoint": "", "migr_card_number": "", "visa_expired_date": "-0001-11-30", "migr_card_issued_date": "-0001-11-30"}}, {"date": "2019-05-06 12:13:7", "user": "209", "prev_value": {"status_id": "SEEKER"}}, {"date": "2019-05-06 12:18:33", "user": "209", "prev_value": {"hired_date": "-0001-11-30", "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": "", "work_permit_issued_date": "-0001-11-30", "work_permit_expired_date": "-0001-11-30", "work_permit_started_date": "-0001-11-30", "work_permit_paid_till_date": "-0001-11-30"}}, {"date": "2019-05-06 12:20:42", "user": "209", "prev_value": {"reg_date": "-0001-11-30"}}, {"date": "2019-05-27 12:54:21", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-05-25"}}, {"date": "2019-06-03 12:32:12", "user": "209", "prev_value": {"passport_issuer": ""}}, {"date": "2019-06-07 10:4:48", "user": "209", "prev_value": {"visa_expired_date": "2019-06-09"}}, {"date": "2019-07-03 16:2:51", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-06-25"}}, {"date": "2019-07-03 16:3:30", "user": "209", "prev_value": {"reg_date": "2019-03-14", "visa_expired_date": "2019-07-25"}}, {"date": "2019-07-16 10:48:22", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-07-25"}}, {"date": "2019-07-16 10:53:18", "user": "209", "prev_value": {"reg_date": "2019-06-05"}}, {"date": "2019-07-31 13:18:40", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-08-25"}}, {"date": "2019-07-31 13:19:5", "user": "209", "prev_value": {"visa_expired_date": "2019-08-25"}}, {"date": "2019-08-27 13:28:9", "user": "209", "prev_value": {"reg_date": "2019-07-04"}}, {"date": "2019-09-10 13:24:53", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-09-25"}}, {"date": "2019-09-10 13:25:12", "user": "209", "prev_value": {"reg_date": "2019-08-01", "visa_expired_date": "2019-09-25"}}, {"date": "2019-10-04 11:54:16", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-11-25"}}, {"date": "2019-10-04 12:0:43", "user": "209", "prev_value": {"reg_date": "2019-08-29", "fired_date": "-0001-11-30"}}, {"date": "2019-10-29 14:11:44", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-12-25"}}, {"date": "2019-10-29 14:11:54", "user": "209", "prev_value": {"visa_expired_date": "2019-11-25"}}, {"date": "2019-12-04 15:53:57", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-01-25"}}, {"date": "2019-12-04 15:54:16", "user": "209", "prev_value": {"reg_date": "2019-09-25", "visa_expired_date": "2019-01-25"}}, {"date": "2019-12-04 16:25:4", "user": "209", "prev_value": {"work_permit_paid_till_date": "2019-02-25"}}, {"date": "2019-12-04 16:25:12", "user": "209", "prev_value": {"visa_expired_date": "2019-02-25"}}, {"date": "2019-12-25 9:25:17", "user": "209", "prev_value": {"reg_date": "2019-10-29", "visa_expired_date": "2020-02-25", "current_passport_number": ""}}, {"date": "2019-12-25 9:26:3", "user": "209", "prev_value": {"current_passport_number": "", "work_permit_paid_till_date": "2020-02-25"}}, {"date": "2020-03-18 13:28:50", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-03-25"}}, {"date": "2020-03-18 13:29:20", "user": "209", "prev_value": {"reg_date": "2019-12-05", "visa_expired_date": "2020-03-25"}}, {"date": "2020-04-23 12:23:36", "user": "209", "prev_value": {"work_address_id": "", "work_permit_issued_date": "2019-04-25", "work_permit_expired_date": "2020-04-25", "work_permit_started_date": "2019-04-25", "work_permit_paid_till_date": "2020-04-25"}}, {"date": "2020-04-23 12:23:49", "user": "209", "prev_value": {"visa_expired_date": "2020-04-25"}}, {"date": "2020-05-22 13:26:21", "user": "209", "prev_value": {"work_permit_expired_date": "2020-05-26", "work_permit_started_date": "2021-04-26", "work_permit_paid_till_date": "2020-05-26"}}, {"date": "2020-05-22 13:34:15", "user": "209", "prev_value": {"work_permit_expired_date": "2021-05-26"}}, {"date": "2020-05-22 13:36:9", "user": "209", "prev_value": {"reg_date": "2020-01-31", "visa_expired_date": "2020-05-26"}}, {"date": "2020-06-01 11:41:57", "user": "209", "prev_value": {"reg_date": "2020-04-23"}}, {"date": "2020-07-20 11:49:37", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-06-26"}}, {"date": "2020-07-20 11:50:2", "user": "209", "prev_value": {"reg_date": "2020-05-22", "visa_expired_date": "2020-06-26"}}, {"date": "2020-07-20 13:47:17", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-07-26"}}, {"date": "2020-07-20 13:47:25", "user": "209", "prev_value": {"visa_expired_date": "2020-07-26"}}, {"date": "2020-08-20 13:29:20", "user": "209", "prev_value": {"reg_date": "2020-06-26", "visa_expired_date": "2020-08-26", "work_permit_paid_till_date": "2020-08-26"}}, {"date": "2020-09-21 13:8:57", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-09-26"}}, {"date": "2020-09-21 13:10:8", "user": "209", "prev_value": {"reg_date": "2020-07-21", "visa_expired_date": "2020-09-26"}}, {"date": "2020-11-18 12:57:44", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-10-26"}}, {"date": "2020-11-18 12:58:20", "user": "209", "prev_value": {"visa_expired_date": "2020-10-26"}}, {"date": "2020-11-19 12:33:29", "user": "209", "prev_value": {"reg_date": "2020-08-20"}}, {"date": "2020-12-23 12:19:12", "user": "209", "prev_value": {"work_permit_paid_till_date": "2020-12-26"}}, {"date": "2020-12-23 12:19:33", "user": "209", "prev_value": {"visa_expired_date": "2020-12-26"}}, {"date": "2021-01-13 12:31:19", "user": "209", "prev_value": {"visa_expired_date": "2021-01-26", "work_permit_paid_till_date": "2021-01-26"}}, {"date": "2021-02-16 14:38:2", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-02-26"}}, {"date": "2021-02-16 14:38:17", "user": "209", "prev_value": {"visa_expired_date": "2021-02-26"}}, {"date": "2021-02-16 14:38:59", "user": "209", "prev_value": {"reg_date": "2020-11-19"}}, {"date": "2021-04-26 13:14:44", "user": "209", "prev_value": {"work_permit_number": "1900047998", "work_permit_issued_date": "2020-04-26", "work_permit_expired_date": "2021-04-26", "work_permit_started_date": "2020-04-26", "work_permit_paid_till_date": "2021-03-26"}}, {"date": "2021-04-26 13:29:35", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2021-04-26 13:37:43", "user": "209", "prev_value": {"status_id": "FIRED", "hired_date": "2019-05-06", "contract_number": "31"}}, {"date": "2021-04-26 13:39:3", "user": "209", "prev_value": {"fired_date": "2021-04-26", "contract_number": "32"}}, {"date": "2021-04-26 13:40:1", "user": "209", "prev_value": {"reg_date": "2021-01-13", "visa_expired_date": "2021-03-26"}}, {"date": "2021-04-26 14:6:24", "user": "209", "prev_value": {"work_permit_expired_date": "2022-04-26", "work_permit_started_date": "2021-04-26", "work_permit_paid_till_date": "2021-04-26"}}, {"date": "2021-05-07 10:45:47", "user": "209", "prev_value": {"visa_expired_date": "2021-05-26"}}, {"date": "2021-05-12 13:17:57", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-05-19"}}, {"date": "2021-05-12 14:1:5", "user": "209", "prev_value": {"visa_expired_date": "2021-05-19"}}, {"date": "2021-06-15 9:19:56", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-06-19"}}, {"date": "2021-06-15 9:20:7", "user": "209", "prev_value": {"visa_expired_date": "2021-06-19"}}, {"date": "2021-08-27 12:6:12", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-07-19"}}, {"date": "2021-08-27 12:6:25", "user": "209", "prev_value": {"visa_expired_date": "2021-07-19"}}, {"date": "2021-09-03 13:54:54", "user": "209", "prev_value": {"status_id": "WORKER", "fired_date": null}}, {"date": "2021-09-03 13:59:14", "user": "209", "prev_value": {"reg_date": "2021-04-27"}}, {"date": "2021-09-06 14:39:28", "user": "209", "prev_value": {"status_id": "FIRED", "birth_place": "ТАДЖИКИСТАН", "employer_id": "7"}}, {"date": "2021-09-06 14:40:16", "user": "209", "prev_value": {"fired_date": "2021-09-06", "hired_date": "2021-04-27"}}, {"date": "2021-09-06 14:40:53", "user": "209", "prev_value": {"reg_date": "2021-08-30"}}, {"date": "2021-09-07 14:9:45", "user": "209", "prev_value": {"contract_number": "42"}}, {"date": "2022-01-10 11:6:38", "user": "209", "prev_value": {"visa_expired_date": "2021-11-19"}}, {"date": "2022-01-10 11:7:4", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-11-19"}}, {"date": "2022-01-17 11:8:55", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-01-19"}}, {"date": "2022-01-17 11:9:18", "user": "209", "prev_value": {"visa_expired_date": "2021-01-19"}}, {"date": "2022-04-18 13:40:34", "user": "209", "prev_value": {"work_permit_issued_date": "2021-04-19", "work_permit_expired_date": "2022-04-19", "work_permit_started_date": "2021-04-19"}}, {"date": "2022-04-18 13:50:27", "user": "209", "prev_value": {"reg_date": "2021-09-07", "visa_expired_date": "2021-02-19"}}, {"date": "2022-05-17 16:18:3", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-02-19"}}, {"date": "2022-05-17 16:18:14", "user": "209", "prev_value": {"visa_expired_date": "2022-05-19"}}, {"date": "2022-09-19 11:11:16", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-07-19"}}, {"date": "2022-09-19 11:11:43", "user": "209", "prev_value": {"visa_expired_date": "2022-07-19"}}, {"date": "2022-10-12 14:5:43", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-10-19"}}, {"date": "2022-10-12 14:8:56", "user": "209", "prev_value": {"host_id": "7", "reg_date": "2022-03-16", "entry_date": "2019-03-12", "migr_card_serie": "4618", "entry_checkpoint": "РАМЕНСКОЕ 004", "migr_card_number": "6371335", "migr_card_issued_date": "2019-03-12"}}, {"date": "2022-11-16 15:10:47", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-11-19"}}, {"date": "2022-12-12 15:20:37", "user": "209", "prev_value": {"work_permit_paid_till_date": "2021-12-19"}}, {"date": "2023-01-18 10:51:4", "user": 3, "prev_value": {"reg_date": "2022-10-12", "status_id": 11}}, {"date": "2023-01-18 10:53:4", "user": 3, "prev_value": {"departure_date": null}}]	1969-07-04	2016-05-17	2026-05-16	\N	\N	2022-04-19	2022-04-19	2023-04-19	2023-01-19	\N	\N	\N	\N	\N	2022-10-09	2022-10-09	2022-12-15	2023-01-18	209	0	0	4	2	2	0	2	0	\N	2023-01-18 10:53:04
246	C1326972	НГУЕН	ТХИ ВАН АНЬ	232	11	[3, 2, 4]	FEMALE						69	2200008610	202401184		SINGLE	WORK	24	5113445	4620	4880023		NGUYEN	THI VAN ANH		Шереметьево 1539	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			Тхайбинь		[{"date": "2022-09-29 11:25:33", "user": "209", "prev_value": []}, {"date": "2022-09-29 11:25:47", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": ""}}, {"date": "2022-09-29 11:25:58", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-10-11 13:14:6", "user": "209", "prev_value": {"employ_permit_id": ""}}, {"date": "2022-12-27 11:23:11", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-12-27 11:37:0", "user": "209", "prev_value": {"invitation_number": ""}}, {"date": "2023-01-18 11:49:19", "user": 3, "prev_value": {"status_id": 10}}, {"date": "2023-01-23 11:23:17", "user": 3, "prev_value": {"work_permit_serie": "", "work_permit_number": "", "work_permit_issuer_id": 0, "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null}}]	1992-02-27	2016-03-02	2026-03-02	\N	\N	2022-10-26	2023-01-23	2023-10-05	\N	\N	\N	2022-12-02	2022-12-02	2023-01-30	2022-12-23	2022-12-23	2022-01-27	\N	232	82	0	1	2	2	0	2	0	\N	2023-01-23 11:23:17
202	C9601793	ВИ	ЧОНГ ХЫНГ	232	7	[3, 2, 4]	MALE						69	2200008956	202402381		MULTI	WORK	12	2196942	4622	0173367		VI	TRONG HUNG		ДОМОДЕВО 695	МИГРАЦИОННЫЙ ДЕПАРТАМЕНТ			ТХАНЬХОА		[{"date": "2021-12-19 18:47:54", "user": "209", "prev_value": []}, {"date": "2021-12-19 18:48:33", "user": "209", "prev_value": {"employer_id": "", "occupation_id": "", "work_address_id": "", "employ_permit_id": ""}}, {"date": "2021-12-19 18:49:1", "user": "209", "prev_value": {"host_id": "", "reg_address_id": "", "real_address_id": ""}}, {"date": "2022-02-16 17:20:19", "user": "209", "prev_value": {"reg_date": null, "entry_date": null, "visa_serie": "", "visa_number": "", "visa_issuer_id": "", "migr_card_serie": "", "entry_checkpoint": "", "migr_card_number": "", "visa_issued_date": null, "invitation_number": "", "visa_expired_date": null, "visa_started_date": null, "migr_card_issued_date": null}}, {"date": "2022-03-28 11:9:23", "user": "209", "prev_value": {"status_id": "SEEKER", "hired_date": null, "contract_number": "", "work_permit_serie": "", "work_permit_number": "", "work_permit_issued_date": null, "work_permit_expired_date": null, "work_permit_started_date": null, "work_permit_paid_till_date": null}}, {"date": "2022-04-26 11:45:7", "user": "209", "prev_value": {"visa_serie": "24", "visa_number": "2276452", "visa_issued_date": "2022-02-07", "visa_expired_date": "2022-04-27", "visa_started_date": "2022-02-07"}}, {"date": "2022-04-26 11:49:2", "user": "209", "prev_value": {"visa_multiplicity": "SINGLE"}}, {"date": "2022-10-27 15:16:9", "user": "209", "prev_value": {"occupation_id": "1"}}, {"date": "2022-12-08 15:39:3", "user": "209", "prev_value": {"employ_permit_id": "65", "work_permit_number": "2200006564", "work_permit_issued_date": "2022-01-17", "work_permit_expired_date": "2022-12-13", "work_permit_started_date": "2022-03-29"}}, {"date": "2022-12-08 15:40:22", "user": "209", "prev_value": {"reg_date": "2022-02-17", "visa_number": "1947545", "visa_issuer_id": "ВЬЕТНАМ Г.ХАНОЙ", "visa_issued_date": "2022-04-18", "visa_expired_date": "2022-12-13", "visa_started_date": "2022-04-18"}}, {"date": "2023-02-06 11:57:14", "user": 3, "prev_value": {"status_id": 11}}]	1997-04-26	2021-10-15	2031-10-15	\N	\N	2022-11-30	2022-12-13	2023-12-12	\N	\N	\N	2022-12-02	2022-12-14	2023-12-12	2022-02-13	2022-02-13	2022-12-13	\N	232	84	0	4	2	2	0	2	0	\N	2023-02-06 11:57:14
\.


--
-- Data for Name: employers; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.employers (id, name_ru, full_name_ru, director_id, type_id, user_ids, taxpayer_code, active_business_type, rcoad, bcc, acc_book_number, account_number, ca, bic, acc_reg_number, uni_reg_number, prime_reg_number, bank, phone, history, acc_reg_date, prime_reg_date, uni_reg_date, booker_id, taxpayer_id, address_id, created_at, updated_at) FROM stdin;
3	Отделение по вопросам Миграции МО МВД России "Кимрский"	Отделение  по вопросам миграции «Кимрский» УВМ УМВД по Тверской области	0	11	[3, 4, 5, 2]													[]	[{"date": "2019-02-19 12:25:7", "user": "209", "prev_value": {"name": "ОВМ «Кимрский» УВМ УМВД по Тверской области"}}]	\N	\N	\N	0	0	0	\N	\N
11	ООО «Звездочка»	Общество с ограниченной ответственностью «Звездочка»	0	12	[2, 4]	503401001					40702810701590000420	30101810145250000411	044525411			1145034001881	Филиал "Центральный" Банк ВТБ (ПАО)	[]	[{"date": "2020-04-21 12:24:24", "user": "207", "prev_value": []}]	\N	\N	\N	197	5034048585	18	\N	\N
10	ООО «Детская одежда»	Общество с ограниченной ответственностью «Детская одежда»	196	12	[2, 4]	773401001					40702810502820001915	30101810200000000593	044525593			5187746017938	АО "АЛЬФА-БАНК"	[]	[{"date": "2020-04-21 12:24:12", "user": "207", "prev_value": []}]	\N	\N	\N	0	7734418884	17	\N	\N
9	АО "Комбинат рабочей одежды"	Акционерное общество ""Комбинат рабочей одежды""	193	12	[2, 4]	027401001												[]	[{"date": "2020-02-06 13:18:28", "user": "207", "prev_value": []}]	\N	\N	\N	0	274043510	16	\N	\N
8	Отдел трудовой миграции УВМ УМВД России по Тверской области	Отдел трудовой миграции Управления по вопросам миграции УМВД России по Тверской области	0	10	[3, 5, 4, 2]													[]	[{"date": "2018-10-01 20:55:3", "user": "207", "prev_value": []}]	\N	\N	\N	0	0	0	\N	\N
14	Отряд пограничного контроля ФСБ России             в МАП Внуково		233	10	[0]													[]	[{"date": "2022-04-28 12:40:52", "user": "207", "prev_value": []}]	\N	\N	\N	0	0	0	\N	\N
6	УВМ ГУ МВД по г. Москве	Управление по вопросам миграции ГУ МВД России по городу Москве	52	10	[2]													[]	{}	\N	\N	\N	0	0	0	\N	\N
2	УВМ УМВД РОССИИ по Тверской области	Управление по вопросам миграции УМВД России по Тверской области	18	10	[3, 5, 4, 2]													[]	[{"date": "2018-11-08 11:2:14", "user": "209", "prev_value": {"name": "УВМ УМВД по Тверской области"}}]	\N	\N	\N	0	0	0	\N	\N
5	ООО "Рога и копыта"	Общество с ограниченной ответственностью "Рога и копыта"	51	1	[2]	771231001	46.42 Торговля оптовая одеждой и	45000000000		567	 4070 1810 9000 0000 0598	30101810400000000225	044525225	69 002345432	77 002345678	5147712345678	ПАО Сбербанк	[{"phone": "+7 495 1234567"}]	[{"date": "2018-04-09 10:6:22", "user": "211", "prev_value": {"booker": "", "director": ""}}]	2015-04-28	2015-04-28	2015-04-28	51	7712345678	5	\N	\N
4	ООО "Белка"	Общество с ограниченной ответственностью "Белка"	241	2	[2, 3, 4, 5]	691001001	14.12 Производство спецодежды			332				69 001767108	69 001765627	1096910002298		[{"phone": "+7 48236 31771"}, {"phone": "8 903 805-46-65"}, {"phone": "8 905 600-25-59"}, {"phone": "8 904 021-38-37"}]	[{"date": "2018-11-19 12:28:10", "user": "209", "prev_value": {"uni_reg_date": "2009-12-01"}}, {"date": "2022-01-20 22:47:55", "user": "207", "prev_value": []}, {"date": "2022-07-27 15:9:54", "user": "207", "prev_value": {"director": "16"}}, {"date": "2022-12-20 21:46:8", "user": 1, "prev_value": {"phone": "+7 48236 31771"}}]	2009-06-30	2009-06-30	2009-06-30	4	6910019068	1	\N	2022-12-20 21:46:08
1	ООО "Унисервис"	Общество с ограниченной ответственностью "Унисервис"	241	2	[2, 3, 4, 5]	691001001	14.12 Производство спецодежды	28426000000		506		30101810028090000992	042809992	69 002236098	69 002236097	1166952050077	ООО КБ "Гефест", г. Кимры	[{"phone": "+7 48236 31771"}, {"phone": "8 903 805-46-65"}, {"phone": "8 905 600-25-59"}, {"phone": "8 904 021-38-37"}]	[{"date": "2019-11-01 22:19:19", "user": "207", "prev_value": {"bank": "ООО КБ\\"Гефест\\",г.Кимры"}}, {"date": "2022-07-27 15:10:5", "user": "207", "prev_value": {"director": "3"}}, {"date": "2022-12-20 21:46:30", "user": 1, "prev_value": {"phone": "+7 48236 31771"}}]	2016-01-11	2016-01-11	2016-01-12	4	6910022825	1	\N	2022-12-20 21:46:30
13	Отряд пограничного контроля ФСБ России             в МАП Домодедово		222	10	[0]													[]	[{"date": "2022-02-09 11:23:9", "user": "207", "prev_value": []}]	\N	\N	\N	0	0	0	\N	\N
7	ООО "Элеганс"	Общество с ограниченной ответственностью "Элеганс"	16	1	[3, 4, 5, 2]	691001001	14.13									1186952007549		[{"phone": "+7 48236 31771"}]	[{"date": "2018-12-05 8:44:2", "user": "208", "prev_value": {"name": "ООО\\"Элеганс\\""}}]	2018-05-30	2018-05-30	\N	4	6910023875	4	\N	\N
12	Отряд пограничного контроля ФСБ России             в МАП Шереметьево		221	10	[0]													[]	[{"date": "2022-02-09 10:18:43", "user": "207", "prev_value": []}, {"date": "2022-02-09 10:19:2", "user": "207", "prev_value": {"name": "ОТРЯДА ПОГРАНИЧНОГО КОНТРОЛЯ ФСБ РОССИИ В МАП ШЕРЕМЕТЬЕВО"}}, {"date": "2022-02-09 10:26:6", "user": "207", "prev_value": {"director": ""}}, {"date": "2022-02-09 10:33:50", "user": "207", "prev_value": {"name": "ОТРЯД ПОГРАНИЧНОГО КОНТРОЛЯ ФСБ РОССИИ В МАП ШЕРЕМЕТЬЕВО"}}, {"date": "2022-02-09 10:34:44", "user": "207", "prev_value": {"name": "ОТРЯД ПОГРАНИЧНОГО КОНТРОЛЯ ФСБ РОССИИ         В МАП ШЕРЕМЕТЬЕВО"}}, {"date": "2022-02-09 10:35:49", "user": "207", "prev_value": {"name": "ОТРЯД ПОГРАНИЧНОГО КОНТРОЛЯ ФСБ РОССИИ             В МАП ШЕРЕМЕТ"}}, {"date": "2022-02-09 10:36:51", "user": "207", "prev_value": {"name": "ОТРЯД ПОГРАНИЧНОГО КОНТРОЛЯ ФСБ РОССИИ             В МАП ШЕРЕМЕТ"}}, {"date": "2022-02-09 10:49:31", "user": "207", "prev_value": {"name": "ОТРЯД ПОГРАНИЧНОГО КОНТРОЛЯ ФСБ РОССИИ             В МАП ШЕРЕМЕТЬЕВО"}}]	\N	\N	\N	0	0	0	\N	\N
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0000_00_00_000000_create_sessions_table	1
2	0000_00_00_000000_create_teams_table	2
3	0000_00_00_000000_create_users_table	3
4	0000_00_00_000000_add_two_factor_columns_to_users_table	4
9	0000_00_00_000000_create_failed_jobs_table	5
12	0000_00_00_000000_create_password_resets_table	6
14	0000_00_00_000000_create_personal_access_tokens_table	6
17	0000_00_00_000000_create_team_invitations_table	6
18	0000_00_00_000000_create_team_user_table	6
19	0000_00_00_000000_create_telescope_entries_table	6
25	0000_00_00_000000_create_addresses_table	7
26	0000_00_00_000000_create_countries_table	7
28	0000_00_00_000000_create_employers_table	7
30	0000_00_00_000000_create_occupations_table	7
33	0000_00_00_000000_create_statuses_table	7
34	0000_00_00_000000_create_types_table	7
35	0000_00_00_000000_create_usage_permits_table	7
45	0000_00_00_000000_create_employees_table	8
46	0000_00_00_000000_create_permits_table	8
47	0000_00_00_000000_create_quotas_table	8
48	0000_00_00_000000_create_staff_table	8
49	0000_00_00_000001_create_employee_job_table	8
50	0000_00_00_000001_create_employee_turnover_table	8
\.


--
-- Data for Name: occupations; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.occupations (id, user_ids, code, name_ru, description, history, created_at, updated_at) FROM stdin;
9	[3, 5, 4, 2]	22605	Инженер по автоматизации и механизации производственных процессов		[{"date": "2022-12-16 21:26:25", "user": 1, "prev_value": {"name_ru": "инженер по автоматизации и механизации производственных процессов"}}]	2022-12-10 12:13:05	2022-12-16 21:26:25
4	[3, 5, 4, 2]	23504	Конструктор одежды		[{"date": "2018-07-25 11:16:57", "user": "209", "prev_value": {"name": "конструктор"}}, {"date": "2022-12-16 21:27:14", "user": 1, "prev_value": {"name_ru": "конструктор одежды"}}]	2022-12-10 12:13:05	2022-12-16 21:27:14
28	[3, 2, 4]	25531	Наладчик оборудования		[{"date": "2019-05-27 13:33:11", "user": "209", "prev_value": []}, {"date": "2022-12-16 21:27:34", "user": 1, "prev_value": {"name_ru": "наладчик оборудования"}}]	2022-12-10 12:13:05	2022-12-16 21:27:34
15	[3, 5, 4, 2]	25857	Программист		[{"date": "2022-12-16 21:27:53", "user": 1, "prev_value": {"name_ru": "программист"}}]	2022-12-10 12:13:05	2022-12-16 21:27:53
26	[2]	22149	Специалист по охране труда		[{"date": "2018-11-20 15:13:58", "user": "208", "prev_value": []}, {"date": "2022-12-16 21:28:16", "user": 1, "prev_value": {"name_ru": "специалист по охране труда"}}]	2022-12-10 12:13:05	2022-12-16 21:28:16
6	[3, 5, 4, 2]	27041	Техник по наладке и испытаниям		[{"date": "2022-12-16 21:28:37", "user": 1, "prev_value": {"name_ru": "техник по наладке и испытаниям"}}]	2022-12-10 12:13:05	2022-12-16 21:28:37
16	[3, 5, 4, 2]	27120	Техник-технолог		[{"date": "2022-12-16 21:28:43", "user": 1, "prev_value": {"name_ru": "техник-технолог"}}]	2022-12-10 12:13:05	2022-12-16 21:28:43
30	[3, 2]	20336	Бухгалтер		[{"date": "2022-07-26 14:42:10", "user": "209", "prev_value": []}, {"date": "2022-12-16 21:25:57", "user": 1, "prev_value": {"name_ru": "бухгалтер"}}]	2022-12-10 12:13:05	2022-12-16 21:25:57
29	[3, 2]	20560	Генеральный директор		[{"date": "2022-07-26 13:57:1", "user": "209", "prev_value": []}, {"date": "2022-12-16 21:26:4", "user": 1, "prev_value": {"name_ru": "генеральный директор"}}]	2022-12-10 12:13:05	2022-12-16 21:26:04
21	[2]	11786	Дворник		[{"date": "2022-12-16 19:53:22", "user": 1, "prev_value": {"name_ru": "Дворник"}}, {"date": "2022-12-16 21:26:11", "user": 1, "prev_value": {"name_ru": "дворник"}}]	2022-12-10 12:13:05	2022-12-16 21:26:11
12	[3, 5, 4, 2]	22491	Инженер-конструктор		[{"date": "2022-12-16 21:26:18", "user": 1, "prev_value": {"name_ru": "инженер-конструктор"}}]	2022-12-10 12:13:05	2022-12-16 21:26:18
10	[3, 5, 4, 2]	22544	Инженер по внедрению новой техники и технологии		[{"date": "2022-12-16 21:26:32", "user": 1, "prev_value": {"name_ru": "инженер по внедрению новой техники и технологии"}}]	2022-12-10 12:13:05	2022-12-16 21:26:32
7	[3, 5, 4, 2]	22583	Инженер по качеству		[{"date": "2022-12-16 21:26:39", "user": 1, "prev_value": {"name_ru": "инженер по качеству"}}]	2022-12-10 12:13:05	2022-12-16 21:26:39
11	[3, 5, 4, 2]	22642	Инженер по организации управления производством		[{"date": "2022-12-16 21:26:46", "user": 1, "prev_value": {"name_ru": "инженер по организации управления производством"}}]	2022-12-10 12:13:05	2022-12-16 21:26:46
8	[3, 5, 4, 2]	22678	Инженер  по подготовке производства		[{"date": "2022-12-16 21:26:53", "user": 1, "prev_value": {"name_ru": "инженер  по подготовке производства"}}]	2022-12-10 12:13:05	2022-12-16 21:26:53
13	[3, 5, 4, 2]	22854	Инженер-технолог		[{"date": "2022-12-16 21:27:0", "user": 1, "prev_value": {"name_ru": "инженер-технолог"}}]	2022-12-10 12:13:05	2022-12-16 21:27:00
22	[2]	23369	Кассир		[{"date": "2022-12-16 19:53:31", "user": 1, "prev_value": {"name_ru": "Кассир"}}, {"date": "2022-12-16 21:27:7", "user": 1, "prev_value": {"name_ru": "кассир"}}]	2022-12-10 12:13:05	2022-12-16 21:27:07
5	[3, 5, 4, 2]	24110	Механик		[{"date": "2022-12-16 21:27:21", "user": 1, "prev_value": {"name_ru": "механик"}}]	2022-12-10 12:13:05	2022-12-16 21:27:21
20	[2]	14544	Монтажник		[{"date": "2022-12-16 19:53:38", "user": 1, "prev_value": {"name_ru": "Монтажник"}}, {"date": "2022-12-16 21:27:28", "user": 1, "prev_value": {"name_ru": "монтажник"}}]	2022-12-10 12:13:05	2022-12-16 21:27:28
14	[3, 5, 4, 2]	25114	Начальник цеха		[{"date": "2022-12-16 21:27:42", "user": 1, "prev_value": {"name_ru": "начальник цеха"}}]	2022-12-10 12:13:05	2022-12-16 21:27:42
2	[3, 5, 4, 2]	17738	Раскройщик		[{"date": "2022-12-16 21:28:4", "user": 1, "prev_value": {"name_ru": "раскройщик"}}]	2022-12-10 12:13:05	2022-12-16 21:28:04
18	[2]	18880	Столяр строительный		[{"date": "2022-12-16 19:54:4", "user": 1, "prev_value": {"name_ru": "Столяр строительный"}}, {"date": "2022-12-16 21:28:23", "user": 1, "prev_value": {"name_ru": "столяр строительный"}}]	2022-12-10 12:13:05	2022-12-16 21:28:23
3	[3, 5, 4, 2]	27142	Технолог		[{"date": "2022-12-16 21:28:57", "user": 1, "prev_value": {"name_ru": "технолог"}}]	2022-12-10 12:13:05	2022-12-16 21:28:57
27	[3, 4, 2]	25531	Переводчик		[{"date": "2018-11-28 14:20:1", "user": "209", "prev_value": []}, {"date": "2022-12-16 19:53:51", "user": 1, "prev_value": {"name_ru": "ПЕРЕВОДЧИК"}}, {"date": "2022-12-16 21:27:48", "user": 1, "prev_value": {"name_ru": "переводчик"}}]	2022-12-10 12:13:05	2022-12-16 21:27:48
17	[2]	18576	Слесарь строительный		[{"date": "2022-12-16 19:53:58", "user": 1, "prev_value": {"name_ru": "Слесарь строительный"}}, {"date": "2022-12-16 21:28:11", "user": 1, "prev_value": {"name_ru": "слесарь строительный"}}]	2022-12-10 12:13:05	2022-12-16 21:28:11
19	[2]	18883	Сторож (вахтер)		[{"date": "2022-12-16 19:54:10", "user": 1, "prev_value": {"name_ru": "Сторож (вахтер)"}}, {"date": "2022-12-16 21:28:29", "user": 1, "prev_value": {"name_ru": "сторож (вахтер)"}}]	2022-12-10 12:13:05	2022-12-16 21:28:29
1	[3, 5, 4, 2]	19601	Швея		[{"date": "2022-12-16 21:28:49", "user": 1, "prev_value": {"name_ru": "швея"}}]	2022-12-10 12:13:05	2022-12-16 21:28:49
25	[2]	27866	Энергетик		[{"date": "2018-11-20 15:13:47", "user": "208", "prev_value": []}, {"date": "2022-12-16 21:29:10", "user": 1, "prev_value": {"name_ru": "энергетик"}}]	2022-12-10 12:13:05	2022-12-16 21:29:10
32	[1]	20656	Главный бухгалтер	\N	\N	2022-12-29 08:04:41	2022-12-29 08:04:41
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.password_resets (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: permits; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.permits (id, employer_id, user_ids, number, quota_id, total, issued_date, expired_date, history, details, created_at, updated_at) FROM stdin;
1	1	[3, 5, 4, 2]	1700000093	3	16	\N	2018-03-27	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"2\\",\\"1\\",\\"6\\"],\\"quantity\\":[\\"1\\",\\"7\\",\\"8\\"]}\\r", "employer_name": ""}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 7, "country_id": 232, "occupation_id": 1}, {"quantity": 8, "country_id": 232, "occupation_id": 6}]	\N	\N
2	1	[3, 5, 4, 2]	1700000216	3	8	\N	2018-05-18	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"1\\",\\"15\\"],\\"quantity\\":[\\"2\\",\\"5\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 6}, {"quantity": 5, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 15}]	\N	\N
3	1	[3, 5, 4, 2]	1700000294	3	3	\N	2018-06-01	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"1\\"],\\"quantity\\":[\\"3\\"]}\\r", "employer_name": ""}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 1}]	\N	\N
4	1	[3, 5, 4, 2]	1700000368	3	5	\N	2018-06-24	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"1\\",\\"6\\",\\"9\\"],\\"quantity\\":[\\"3\\",\\"1\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 9}]	\N	\N
5	1	[3, 5, 4, 2]	1700000390	3	2	\N	2018-08-15	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"11\\",\\"10\\"],\\"quantity\\":[\\"1\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 11}, {"quantity": 1, "country_id": 232, "occupation_id": 10}]	\N	\N
6	1	[3, 5, 4, 2]	1700000520	3	2	\N	2018-10-06	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"13\\"],\\"quantity\\":[\\"1\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 13}]	\N	\N
7	1	[3, 5, 4, 2]	1700000544	3	5	\N	2018-10-18	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"13\\",\\"10\\"],\\"quantity\\":[\\"3\\",\\"1\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 13}, {"quantity": 1, "country_id": 232, "occupation_id": 10}]	\N	\N
8	1	[3, 5, 4, 2]	1700000625	3	7	\N	2018-01-11	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"12\\",\\"8\\",\\"9\\",\\"11\\"],\\"quantity\\":[\\"3\\",\\"1\\",\\"1\\",\\"1\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 12}, {"quantity": 1, "country_id": 232, "occupation_id": 8}, {"quantity": 1, "country_id": 232, "occupation_id": 9}, {"quantity": 1, "country_id": 232, "occupation_id": 11}]	\N	\N
9	1	[3, 5, 4, 2]	1700000632	3	9	\N	2018-11-28	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"13\\",\\"7\\",\\"10\\"],\\"quantity\\":[\\"5\\",\\"1\\",\\"1\\",\\"2\\"]}\\r", "employer_name": ""}}]	[{"quantity": 5, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 13}, {"quantity": 1, "country_id": 232, "occupation_id": 7}, {"quantity": 2, "country_id": 232, "occupation_id": 10}]	\N	\N
10	1	[3, 5, 4, 2]	1700000657	3	6	\N	2018-12-07	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"12\\",\\"8\\"],\\"quantity\\":[\\"4\\",\\"1\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 4, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 12}, {"quantity": 1, "country_id": 232, "occupation_id": 8}]	\N	\N
11	1	[3, 5, 4, 2]	1600000614	1	8	\N	2017-12-08	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"7\\",\\"12\\",\\"8\\",\\"9\\"],\\"quantity\\":[\\"4\\",\\"1\\",\\"1\\",\\"1\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 4, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 7}, {"quantity": 1, "country_id": 232, "occupation_id": 12}, {"quantity": 1, "country_id": 232, "occupation_id": 8}, {"quantity": 1, "country_id": 232, "occupation_id": 9}]	\N	\N
13	1	[3, 5, 4, 2]	1600000558	1	17	\N	2017-11-29	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"8\\",\\"12\\",\\"16\\",\\"10\\",\\"7\\"],\\"quantity\\":[\\"10\\",\\"1\\",\\"1\\",\\"1\\",\\"2\\",\\"2\\"]}\\r", "employer_name": ""}}]	[{"quantity": 10, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 8}, {"quantity": 1, "country_id": 232, "occupation_id": 12}, {"quantity": 1, "country_id": 232, "occupation_id": 16}, {"quantity": 2, "country_id": 232, "occupation_id": 10}, {"quantity": 2, "country_id": 232, "occupation_id": 7}]	\N	\N
17	1	[3, 5, 4, 2]	1700000640	3	4	2017-10-27	2018-11-30	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"2\\",\\"1\\"],\\"quantity\\":[\\"1\\",\\"1\\",\\"2\\"]}\\r", "employer_name": ""}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 2, "country_id": 232, "occupation_id": 1}]	\N	\N
18	1	[3, 5, 4, 2]	1700000720	3	5	2017-12-08	2019-01-10	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"11\\",\\"12\\"],\\"quantity\\":[\\"3\\",\\"1\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 11}, {"quantity": 1, "country_id": 232, "occupation_id": 12}]	\N	\N
19	1	[3, 5, 4, 2]	1800000114	4	12	2018-02-14	2019-03-26	[{"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"6\\",\\"1\\",\\"2\\"],\\"quantity\\":[\\"4\\",\\"7\\",\\"1\\"]}\\r", "employer_name": ""}}]	[{"quantity": 4, "country_id": 232, "occupation_id": 6}, {"quantity": 7, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 2}]	\N	\N
20	4	[3, 5, 4, 2]	1800000107	5	5	2018-02-14	2019-02-18	[{"date": "2018-03-13 12:11:47", "user": "209", "prev_value": {"details": "{'occupation':[], 'quantity':[]}", "issued_date": "2018-02-14", "expired_date": "2019-02-18"}}, {"date": "2018-03-21 21:23:21", "user": "207", "prev_value": {"details": "{\\"occupation\\":[\\"1\\"],\\"quantity\\":[\\"5\\"]}\\r", "employer_name": ""}}]	[{"quantity": 5, "country_id": 232, "occupation_id": 1}]	\N	\N
21	5	[2]	7700001234	6	19	2018-04-03	2019-04-02	[{"date": "2018-04-05 9:54:35", "user": "211", "prev_value": {"issued_date": "2018-04-02"}}]	[{"quantity": 6, "country_id": 229, "occupation_id": 22}, {"quantity": 5, "country_id": 229, "occupation_id": 20}, {"quantity": 8, "country_id": 229, "occupation_id": 21}]	\N	\N
22	5	[2]	7700003456	\N	4	2017-06-07	2018-06-02	[{"date": "2018-04-05 12:47:23", "user": "211", "prev_value": {"expired_date": "2018-06-06"}}]	[{"quantity": 4, "country_id": 44, "occupation_id": 20}]	\N	\N
23	1	[3, 5, 4, 2]	1800000259	4	5	2018-04-04	2019-05-17	[{"date": "2018-05-16 13:42:14", "user": "209", "prev_value": {"quota_id": "2017", "expired_date": "2018-05-18"}}]	[{"quantity": 5, "country_id": 232, "occupation_id": 1}]	\N	\N
24	1	[3, 5, 4, 2]	1800000298	4	3	2018-05-14	2019-06-23	[{"date": "2018-06-08 12:38:31", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 1}]	\N	\N
25	4	[3, 5, 4, 2]	1800000450	5	7	2018-07-04	2019-07-14	[{"date": "2018-07-11 12:56:39", "user": "209", "prev_value": {"number": "180000450"}}]	[{"quantity": 4, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 5}, {"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 1, "country_id": 232, "occupation_id": 3}]	\N	\N
26	1	[3, 5, 4, 2]	1800000428	4	7	2018-07-04	2019-07-11	[{"date": "2018-07-11 12:56:28", "user": "209", "prev_value": {"number": "180000428"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 5}, {"quantity": 1, "country_id": 232, "occupation_id": 3}, {"quantity": 1, "country_id": 232, "occupation_id": 13}, {"quantity": 1, "country_id": 232, "occupation_id": 10}, {"quantity": 1, "country_id": 232, "occupation_id": 11}]	\N	\N
27	1	[3, 4, 5, 2]	1800000629	4	8	2018-10-02	2019-11-27	[{"date": "2018-11-14 12:21:12", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 13}, {"quantity": 2, "country_id": 232, "occupation_id": 10}, {"quantity": 1, "country_id": 232, "occupation_id": 7}, {"quantity": 1, "country_id": 232, "occupation_id": 4}]	\N	\N
28	1	[3, 5, 4, 2]	1800000717	4	6	2018-10-30	2019-12-06	[{"date": "2018-11-07 10:1:19", "user": "209", "prev_value": []}]	[{"quantity": 1, "country_id": 232, "occupation_id": 12}, {"quantity": 1, "country_id": 232, "occupation_id": 8}, {"quantity": 4, "country_id": 232, "occupation_id": 6}]	\N	\N
29	1	[3, 5, 4, 2]	1800000724	4	1	2018-10-30	2020-01-19	[{"date": "2018-11-07 10:3:25", "user": "209", "prev_value": []}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
30	4	[3, 4, 2]	1800000731	5	3	2018-10-30	2019-11-18	[{"date": "2018-11-19 10:26:34", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 1}]	\N	\N
31	4	[3, 4, 2]	1800000756	5	5	2018-11-26	2019-12-01	[{"date": "2018-12-11 11:18:53", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 4, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 4}]	\N	\N
32	4	[3, 4, 2]	1900000069	8	4	2019-02-04	2020-02-17	[{"date": "2019-02-15 12:21:55", "user": "209", "prev_value": []}, {"date": "2019-03-01 13:2:5", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 4, "country_id": 232, "occupation_id": 1}]	\N	\N
33	1	[3, 4, 2]	1900000132	7	9	2019-02-15	2020-03-25	[{"date": "2019-02-20 13:52:43", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 5, "country_id": 232, "occupation_id": 1}, {"quantity": 4, "country_id": 232, "occupation_id": 6}]	\N	\N
34	1	[3, 4, 2]	1900000260	7	1	2019-03-28	2020-04-04	[{"date": "2019-05-20 10:58:22", "user": "209", "prev_value": []}, {"date": "2019-05-20 10:59:25", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
35	1	[3, 2]	1900000365	7	6	2019-06-10	2020-07-10	[{"date": "2019-06-24 10:46:19", "user": "209", "prev_value": []}, {"date": "2019-06-24 10:48:8", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}, {"date": "2019-08-05 12:46:30", "user": "209", "prev_value": {"details": "{\\"country\\":[\\"232\\",\\"232\\",\\"232\\",\\"232\\"],\\"occupation\\":[\\"1\\",\\"11\\",\\"10\\",\\"5\\"],\\"quantity\\":[\\"2\\",\\"1\\",\\"1\\",\\"1\\"]}"}}, {"date": "2019-09-05 10:9:30", "user": "209", "prev_value": {"details": "{\\"country\\":[\\"232\\",\\"232\\",\\"232\\",\\"232\\",\\"232\\"],\\"occupation\\":[\\"1\\",\\"11\\",\\"10\\",\\"5\\",\\"5\\"],\\"quantity\\":[\\"2\\",\\"1\\",\\"1\\",\\"1\\",\\"1\\"]}"}}, {"date": "2019-09-05 10:13:29", "user": "209", "prev_value": {"details": "{\\"country\\":[\\"232\\",\\"232\\",\\"232\\",\\"232\\",\\"232\\",\\"232\\"],\\"occupation\\":[\\"1\\",\\"11\\",\\"10\\",\\"5\\",\\"5\\",\\"3\\"],\\"quantity\\":[\\"2\\",\\"1\\",\\"1\\",\\"1\\",\\"1\\",\\"1\\"]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 11}, {"quantity": 1, "country_id": 232, "occupation_id": 10}, {"quantity": 1, "country_id": 232, "occupation_id": 5}, {"quantity": 1, "country_id": 232, "occupation_id": 3}]	\N	\N
36	4	[3, 4, 2]	1900000358	8	6	2019-06-10	2020-07-13	[{"date": "2019-06-24 10:48:57", "user": "209", "prev_value": []}, {"date": "2019-06-24 10:50:14", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 3, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 3}, {"quantity": 1, "country_id": 232, "occupation_id": 5}]	\N	\N
37	1	[3, 2]	1900000397	7	3	2019-06-26	2020-07-01	[{"date": "2019-08-05 12:23:5", "user": "209", "prev_value": []}, {"date": "2019-08-05 12:23:47", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 1}]	\N	\N
38	1	[3, 2]	1900000492	7	3	2019-08-28	2020-09-11	[{"date": "2019-08-29 12:21:50", "user": "209", "prev_value": []}, {"date": "2019-08-29 12:22:27", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}, {"date": "2019-09-05 10:21:16", "user": "209", "prev_value": {"quota_id": "2018", "expired_date": "2019-09-12"}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 1}]	\N	\N
39	4	[3, 2]	1900000647	8	2	2019-10-23	2020-11-17	[{"date": "2019-11-13 15:39:43", "user": "209", "prev_value": []}, {"date": "2019-11-13 15:40:11", "user": "209", "prev_value": {"quota_id": "1969", "expired_date": "1970-01-01"}}, {"date": "2019-11-13 15:41:4", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 4}]	\N	\N
40	1	[3, 2]	1900000679	7	2	2019-11-12	2020-12-05	[{"date": "2019-11-20 13:45:0", "user": "209", "prev_value": []}, {"date": "2019-11-20 13:45:25", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 6}]	\N	\N
41	1	[3, 2]	1900000661	7	5	2019-11-12	2020-11-26	[{"date": "2019-11-20 13:46:9", "user": "209", "prev_value": []}, {"date": "2019-11-20 13:47:55", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 2, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 6}, {"quantity": 1, "country_id": 232, "occupation_id": 4}]	\N	\N
42	4	[3, 2]	1900000573	8	1	2019-10-23	2020-10-23	[{"date": "2019-11-20 13:48:52", "user": "209", "prev_value": []}, {"date": "2019-11-20 13:49:15", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
43	1	[3, 2]	1900000686	7	1	2019-11-19	2020-11-21	[{"date": "2019-12-16 13:36:29", "user": "209", "prev_value": []}, {"date": "2019-12-16 13:36:51", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 1}]	\N	\N
44	4	[3, 2]	1900000703	8	1	2019-12-16	2020-12-22	[{"date": "2020-01-09 11:44:43", "user": "209", "prev_value": []}, {"date": "2020-01-27 10:38:43", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
45	4	[3, 2]	2000000029	10	5	2020-01-21	2021-01-26	[{"date": "2020-02-10 14:47:58", "user": "209", "prev_value": []}, {"date": "2020-02-25 10:34:19", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 5, "country_id": 232, "occupation_id": 6}]	\N	\N
46	4	[3, 2]	2000000050	10	2	2020-02-04	2021-02-16	[{"date": "2020-02-25 10:31:34", "user": "209", "prev_value": []}, {"date": "2020-02-25 10:32:5", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}]	\N	\N
47	1	[3, 2]	2000000195	9	1	2020-03-11	2021-04-03	[{"date": "2020-03-20 12:43:46", "user": "209", "prev_value": []}, {"date": "2020-03-20 12:47:34", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
48	1	[3, 2]	2000000205	9	4	2020-03-11	2021-03-24	[{"date": "2020-03-20 12:48:17", "user": "209", "prev_value": []}, {"date": "2020-03-20 12:49:6", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}, {"quantity": 2, "country_id": 232, "occupation_id": 6}]	\N	\N
49	1	[3, 2]	2000000300	9	2	2020-06-17	2021-06-30	[{"date": "2020-06-23 12:40:55", "user": "209", "prev_value": []}, {"date": "2020-06-23 12:41:41", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 5}, {"quantity": 1, "country_id": 232, "occupation_id": 1}]	\N	\N
50	4	[3, 2]	2000000413	10	1	2020-10-12	2021-10-22	[{"date": "2020-10-22 12:24:42", "user": "209", "prev_value": []}, {"date": "2020-10-22 12:25:1", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
51	1	[3, 2]	2000000484	9	2	2020-11-21	2021-11-20	[{"date": "2020-11-16 16:56:42", "user": "209", "prev_value": []}, {"date": "2020-11-16 16:57:6", "user": "209", "prev_value": {"issued_date": "2020-10-28"}}, {"date": "2020-11-17 10:11:11", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}]	\N	\N
52	1	[3, 2]	2000000460	9	3	2020-11-26	2021-11-25	[{"date": "2020-11-16 16:57:56", "user": "209", "prev_value": []}, {"date": "2020-11-17 10:10:33", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 2, "country_id": 232, "occupation_id": 1}]	\N	\N
53	4	[3, 2]	2000000420	10	2	2020-11-17	2021-11-16	[{"date": "2020-11-17 10:5:48", "user": "209", "prev_value": []}, {"date": "2020-11-17 10:9:4", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 4}]	\N	\N
54	4	[3, 2]	2000000501	12	1	2021-01-26	2022-01-25	[{"date": "2021-01-20 17:18:59", "user": "209", "prev_value": []}, {"date": "2021-01-20 17:20:9", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
55	4	[3, 2]	2100000544	12	2	2021-02-05	2022-02-15	[{"date": "2021-02-15 11:22:8", "user": "209", "prev_value": []}, {"date": "2021-02-15 11:22:22", "user": "209", "prev_value": {"quota_id": "2020", "expired_date": "2021-02-16"}}, {"date": "2021-02-15 11:22:45", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}]	\N	\N
56	1	[3, 2]	2100000590	11	3	2021-03-12	2022-03-23	[{"date": "2021-03-18 15:51:32", "user": "209", "prev_value": []}, {"date": "2021-03-18 15:53:38", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 1}, {"quantity": 2, "country_id": 232, "occupation_id": 6}]	\N	\N
57	1	[3, 2]	2100000600	11	1	2021-03-15	2022-03-31	[{"date": "2021-03-18 16:1:52", "user": "209", "prev_value": []}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
58	1	[3, 2]	2100000720	11	1	2021-05-31	2022-06-29	[{"date": "2021-06-03 19:37:36", "user": "209", "prev_value": []}, {"date": "2021-06-03 19:38:10", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 1}]	\N	\N
59	5	[2]	555	\N	5	2021-08-12	2021-09-01	[{"date": "2021-08-20 16:14:51", "user": "211", "prev_value": []}, {"date": "2021-08-20 16:15:4", "user": "211", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}, {"date": "2022-03-15 15:34:52", "user": "207", "prev_value": {"details": "{\\"country\\":[\\"13\\",\\"\\"],\\"occupation\\":[\\"20\\",\\"\\"],\\"quantity\\":[\\"5\\",\\"\\"]}"}}]	[{"quantity": 5, "country_id": 13, "occupation_id": 20}]	\N	\N
60	1	[3, 2]	2100000872	11	2	2021-09-27	2022-11-19	[{"date": "2021-11-16 9:43:16", "user": "209", "prev_value": []}, {"date": "2021-11-16 9:43:41", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}]	\N	\N
61	1	[3, 2]	2100000897	11	2	2021-09-27	2022-11-24	[{"date": "2021-11-16 9:44:21", "user": "209", "prev_value": []}, {"date": "2021-11-16 9:44:41", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}]	\N	\N
62	4	[3, 2]	2100000880	12	\N	2021-09-27	2022-11-15	[{"date": "2021-11-16 9:45:24", "user": "209", "prev_value": []}]	[]	\N	\N
63	1	[3, 2]	2100000946	11	2	2021-11-02	2022-11-09	[{"date": "2021-11-17 8:15:27", "user": "209", "prev_value": []}, {"date": "2021-11-17 8:15:48", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}]	\N	\N
64	1	[3, 2]	2100000992	11	8	2021-12-12	2022-12-13	[{"date": "2021-12-19 18:5:2", "user": "209", "prev_value": []}, {"date": "2021-12-19 18:32:43", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 4}, {"quantity": 1, "country_id": 232, "occupation_id": 3}, {"quantity": 3, "country_id": 232, "occupation_id": 6}]	\N	\N
65	4	[3, 2]	21000001001	12	4	2021-12-15	2022-12-13	[{"date": "2021-12-19 18:35:0", "user": "209", "prev_value": []}]	[{"quantity": 3, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 3}]	\N	\N
66	4	[3, 2]	2200001044	14	1	2022-01-17	2023-01-24	[{"date": "2022-01-24 13:13:43", "user": "209", "prev_value": []}, {"date": "2022-01-24 13:14:17", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
67	1	[3, 2]	2200001037	13	1	2022-01-17	2023-01-20	[{"date": "2022-01-25 12:51:18", "user": "209", "prev_value": []}, {"date": "2022-01-25 12:51:43", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
68	4	[3, 2]	2200001076	14	2	2022-02-03	2023-02-14	[{"date": "2022-02-15 13:7:25", "user": "209", "prev_value": []}]	[{"quantity": 2, "country_id": 232, "occupation_id": 1}]	\N	\N
69	1	[3, 2]	2200001164	13	5	2022-02-17	2023-02-23	[{"date": "2022-02-22 12:49:28", "user": "209", "prev_value": []}, {"date": "2022-03-15 14:17:3", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 5, "country_id": 232, "occupation_id": 6}]	\N	\N
70	4	[3, 2]	2200001189	14	4	2022-02-18	2023-02-23	[{"date": "2022-02-22 12:50:51", "user": "209", "prev_value": []}, {"date": "2022-02-22 12:51:23", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}, {"date": "2022-03-15 15:29:43", "user": "207", "prev_value": {"quota_id": "2021", "expired_date": "2022-02-23"}}]	[{"quantity": 4, "country_id": 232, "occupation_id": 6}]	\N	\N
77	1	[3, 2]	2200001213	13	1	2022-03-28	2023-03-30	[{"date": "2022-03-31 11:27:47", "user": "209", "prev_value": []}, {"date": "2022-03-31 11:28:16", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
78	1	[3, 2]	2200001397	13	1	2022-06-14	2023-06-28	[{"date": "2022-06-29 10:47:53", "user": "209", "prev_value": []}, {"date": "2022-06-29 10:48:16", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 1}]	\N	\N
79	4	[3, 2]	2200001380	14	3	2022-06-14	2023-06-19	[{"date": "2022-07-19 14:21:4", "user": "209", "prev_value": []}, {"date": "2022-07-19 14:21:26", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 1}]	\N	\N
80	1	[3, 2]	2200001502	13	3	2022-08-18	2023-08-19	[{"date": "2022-08-22 12:37:2", "user": "209", "prev_value": []}, {"date": "2022-08-22 12:37:24", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 6}]	\N	\N
81	1	[3, 2]	2200001407	13	6	2022-06-14	2023-11-08	[{"date": "2022-08-29 9:42:48", "user": "209", "prev_value": []}, {"date": "2022-08-29 9:43:13", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 6, "country_id": 232, "occupation_id": 1}]	\N	\N
82	1	[3, 2]	2200001559	13	3	2022-10-04	2023-10-05	[{"date": "2022-10-05 13:5:2", "user": "209", "prev_value": []}, {"date": "2022-10-11 13:12:27", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 3, "country_id": 232, "occupation_id": 6}]	\N	\N
83	1	[3, 2]	2200001686	13	1	2022-11-30	2023-12-12	[{"date": "2022-12-08 15:8:11", "user": "209", "prev_value": []}, {"date": "2022-12-08 15:8:40", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 1, "country_id": 232, "occupation_id": 6}]	\N	\N
84	4	[3, 2]	2200001679	14	2	2022-11-30	2023-12-12	[{"date": "2022-12-08 15:29:17", "user": "209", "prev_value": []}, {"date": "2022-12-08 15:29:39", "user": "209", "prev_value": {"details": "{'country':[], 'occupation':[], 'quantity':[]}"}}]	[{"quantity": 2, "country_id": 232, "occupation_id": 6}]	\N	\N
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quotas; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.quotas (id, year, employer_id, user_ids, total, history, details, issued_date, expired_date, created_at, updated_at) FROM stdin;
1	2016	1	[0]	\N	[{"date": "2022-12-23 8:59:26", "user": "207", "prev_value": []}]	[]	\N	\N	\N	\N
2	2016	4	[0]	\N	[{"date": "2022-12-23 9:0:5", "user": "207", "prev_value": []}]	[]	\N	\N	\N	\N
3	2017	1	[3, 5, 4, 2]	38	[{"date": "2018-04-20 9:48:53", "user": "208", "prev_value": {"issued_date": "2017-01-01"}}]	[{"quantity": 29, "country_id": 232, "occupation_id": 1}, {"quantity": 6, "country_id": 232, "occupation_id": 2}, {"quantity": 1, "country_id": 232, "occupation_id": 3}, {"quantity": 1, "country_id": 232, "occupation_id": 4}, {"quantity": 1, "country_id": 232, "occupation_id": 5}]	\N	2017-12-31	\N	\N
4	2018	1	[3, 5, 4, 2]	21	\N	[{"quantity": 1, "country_id": 232, "occupation_id": 3}, {"quantity": 1, "country_id": 232, "occupation_id": 4}, {"quantity": 1, "country_id": 232, "occupation_id": 5}, {"quantity": 17, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 2}]	\N	2018-12-31	\N	\N
5	2018	4	[3, 4, 5, 2]	20	[{"date": "2018-11-20 14:6:33", "user": "208", "prev_value": []}]	[{"quantity": 1, "country_id": 232, "occupation_id": 4}, {"quantity": 1, "country_id": 232, "occupation_id": 5}, {"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 16, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 3}]	\N	2018-12-31	\N	\N
6	2018	5	[2]	68	[{"date": "2018-04-05 18:31:29", "user": "211", "prev_value": {"details": "{\\"country\\":[\\"229\\",\\"229\\",\\"209\\",\\"44\\",\\"229\\"],\\"occupation\\":[\\"20\\",\\"21\\",\\"20\\",\\"18\\",\\"22\\"],\\"quantity\\":[\\"12\\",\\"25\\",\\"6\\",\\"10\\",\\"15\\"]}"}}]	[{"quantity": 12, "country_id": 229, "occupation_id": 20}, {"quantity": 25, "country_id": 229, "occupation_id": 21}, {"quantity": 6, "country_id": 232, "occupation_id": 20}, {"quantity": 10, "country_id": 44, "occupation_id": 18}, {"quantity": 15, "country_id": 229, "occupation_id": 22}]	\N	2018-12-31	\N	\N
7	2019	1	[3, 4, 2]	20	[{"date": "2018-11-20 15:18:11", "user": "207", "prev_value": []}]	[{"quantity": 16, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 1, "country_id": 232, "occupation_id": 3}, {"quantity": 1, "country_id": 232, "occupation_id": 4}, {"quantity": 1, "country_id": 232, "occupation_id": 5}]	\N	2020-12-31	\N	\N
8	2019	4	[2, 3, 5]	12	[{"date": "2019-08-22 14:59:15", "user": "207", "prev_value": []}]	[{"quantity": 8, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 4}, {"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 1, "country_id": 232, "occupation_id": 3}, {"quantity": 1, "country_id": 232, "occupation_id": 5}]	\N	2020-12-31	\N	\N
9	2020	1	[3, 2]	20	[{"date": "2020-09-15 14:8:3", "user": "207", "prev_value": []}]	[{"quantity": 1, "country_id": 232, "occupation_id": 3}, {"quantity": 1, "country_id": 232, "occupation_id": 5}, {"quantity": 17, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 2}]	\N	2020-12-31	\N	\N
10	2020	4	[3, 2]	20	[{"date": "2020-09-15 14:7:56", "user": "207", "prev_value": []}]	[{"quantity": 1, "country_id": 232, "occupation_id": 4}, {"quantity": 1, "country_id": 232, "occupation_id": 5}, {"quantity": 1, "country_id": 232, "occupation_id": 2}, {"quantity": 16, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 3}]	\N	2020-12-31	\N	\N
11	2021	1	[3, 2]	13	[{"date": "2021-09-01 14:32:24", "user": "207", "prev_value": []}]	[{"quantity": 11, "country_id": 232, "occupation_id": 1}, {"quantity": 1, "country_id": 232, "occupation_id": 3}, {"quantity": 1, "country_id": 232, "occupation_id": 4}]	\N	2021-12-31	\N	\N
13	2022	1	[3, 2]	7	[{"date": "2022-02-17 8:23:23", "user": "207", "prev_value": []}]	[{"quantity": 7, "country_id": 232, "occupation_id": 1}]	\N	\N	\N	\N
14	2022	4	[3, 2]	5	[{"date": "2022-02-17 8:22:39", "user": "207", "prev_value": []}]	[{"quantity": 5, "country_id": 232, "occupation_id": 1}]	\N	\N	\N	\N
12	2021	4	[3, 2]	7	[{"date": "2021-09-01 14:32:39", "user": "207", "prev_value": []}, {"date": "2022-12-24 19:51:21", "user": 3, "prev_value": {"details": "[{\\"quantity\\": 5, \\"country_id\\": 232, \\"occupation_id\\": 1}, {\\"quantity\\": 1, \\"country_id\\": 232, \\"occupation_id\\": 3}, {\\"quantity\\": 1, \\"country_id\\": 232, \\"occupation_id\\": 4}]"}}]	[{"quantity": "5", "country_id": "232", "occupation_id": "1"}, {"quantity": "1", "country_id": "232", "occupation_id": "3"}, {"quantity": "1", "country_id": "232", "occupation_id": "4"}]	\N	2021-12-31	\N	2022-12-24 19:51:21
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
sldQW7LRIKlZqTwtgzOpXaD6FqOJfIagCDLyakKM	\N	188.127.231.138	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36	YTo1OntzOjc6InBlclBhZ2UiO2k6MTU7czo2OiJfdG9rZW4iO3M6NDA6ImZsa2YzNzJ4UzhDRktrQTZoZWpKeFZFVnIySVlDQzdkNU9aZHZvVjkiO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjI3OiJodHRwOi8vd3d3Ljc3MTUzNzcucnUvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM6InVybCI7YToxOntzOjg6ImludGVuZGVkIjtzOjMxOiJodHRwOi8vd3d3Ljc3MTUzNzcucnUvZW1wbG95ZWVzIjt9fQ==	1676410918
ruhQsGFHrk7d8Pfe4zsz1dp5T6wseK7msaYamy1m	\N	109.74.204.123		YTozOntzOjY6Il90b2tlbiI7czo0MDoiNDQ5aldPTjJPNG9RUEt3b3VlRXJIclBPZzdpM1dNRlFZcTZKYk9qYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTM6Imh0dHA6Ly9lbS5sb2MiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1676413853
U549WNx0Dlk6fSn0C0OLe9HuHVCgrGIpdj7k3UJ2	\N	109.74.204.123	curl/7.54.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQWk0MnV6QjIxY01YZERyRmo2UDZjVDRjUHVZMXZJbDNwcFNsNG5PSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9zNTQwOTE4LnNydmFwZS5jb206ODAwMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1676413863
eYecvMc0SCzupnR9sf9ZUZbXcG56pW56wogrCXd2	\N	109.74.204.123		YTozOntzOjY6Il90b2tlbiI7czo0MDoiVndveDRFdElTTmx2UmFKbjVTRTBRM0Nqd1BNUEllcU1nT1dvWXhDbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9zNTQwOTE4LnNydmFwZS5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1676413878
ReQc6Fe4D6PIid5LWH124byXGgJg0BJquHNUqjBR	\N	188.127.231.138	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36	YTo1OntzOjc6InBlclBhZ2UiO2k6MTU7czo2OiJfdG9rZW4iO3M6NDA6Ikh1aVVJOHFsRWI1YUlCTXVJcVFGOGNFUTJSWHBXZHpnNHhNdW0wT1MiO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjI3OiJodHRwOi8vd3d3Ljc3MTUzNzcucnUvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM6InVybCI7YToxOntzOjg6ImludGVuZGVkIjtzOjMxOiJodHRwOi8vd3d3Ljc3MTUzNzcucnUvZW1wbG95ZWVzIjt9fQ==	1676410916
JaWFF6eucPPf3Yb8jmxBwzNEV1ztCZ8JARmXVMkZ	\N	188.127.231.138	Mozilla/5.0 (compatible; StatOnlineRuBot/1.0)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNHUybzM4N05jTzNGd1FNQjZIb0U4MzNYTU1uc1pQejEyeEtBUlkxcyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTc6Imh0dHA6Ly83NzE1Mzc3LnJ1Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1676411125
A7tWAdfbqbPHnCWN617oJz99b2iwrtfR1IawG934	\N	109.74.204.123	curl/7.54.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWkplOE04UDZCb2xhVjZrYkh0WjgwN1ZwSnJsT0tTUk1GTzRvTnF0eCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9zNTQwOTE4LnNydmFwZS5jb206ODAwMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1676413861
Sk6JwLIp1AK32DkVh0m40rCe29ETUj3MIXYOZota	\N	109.74.204.123	curl/7.54.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUdJbzFJYWRudmJwMVdsYUhVdmJFTXpUaEtJQk95eW5Tc0FzNGJEWCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly9zNTQwOTE4LnNydmFwZS5jb206ODAwMi9pbmRleC5waHAiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1676413865
g91AKsPh0Cy0nF9OOV4rTg8B84E2JvBSi7VnuBlM	\N	162.142.125.210	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoick1DRDJIelE1T0hJc0FIR3lzZnN0TVhoRVlpRWM4STNYRzh2VEpRaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xODguMTI3LjIzMS4xMzg6ODAwMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1676415929
qaBc6Czp3Ay7E0ksxLOZV6nZmL5yzHcHnYje7RWp	\N	188.127.231.138	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36	YTo1OntzOjc6InBlclBhZ2UiO2k6MTU7czo2OiJfdG9rZW4iO3M6NDA6IjAzYndJS3EzcVROT3l0djVmb3dpWnRmYVF2dlJsaVZXYWpJZnNJVDkiO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjIzOiJodHRwOi8vNzcxNTM3Ny5ydS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6Mjc6Imh0dHA6Ly83NzE1Mzc3LnJ1L2VtcGxveWVlcyI7fX0=	1676410916
P8Zc8SbJ597iwyzNAKLcPvGlkYCCQZ5yHhpIQFVF	\N	188.127.231.138	Mozilla/5.0 (compatible; StatOnlineRuBot/1.0)	YTo1OntzOjc6InBlclBhZ2UiO2k6MTU7czo2OiJfdG9rZW4iO3M6NDA6ImlwS0J1d3pFYUdNM1FpNjJFeUZueENpNUdGZkdWcG0zNTVGa2tOakMiO3M6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6Mjc6Imh0dHA6Ly83NzE1Mzc3LnJ1L2VtcGxveWVlcyI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjI3OiJodHRwOi8vNzcxNTM3Ny5ydS9lbXBsb3llZXMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1676411125
tmjugLFKNC1Gxaa93WBUvBkANGcfbGsQ7ucbTBaR	\N	109.74.204.123	curl/7.54.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWlkUjEzbG5LdTU0Nk54dXlrcXJrN0VTU2ppNmVXWk5obDBzRUpCWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9zNTQwOTE4LnNydmFwZS5jb206ODAwMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1676413861
8CBbw2rZFBwHLuP4gQjpCEfkOsRBR9SK2zvnWGaB	\N	109.74.204.123	curl/7.54.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidnZDS3J1NTlIYlJDZ0RzRnE4c0ZGWHpuZGx0SG8wSzlvVUpZVVBQeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9zNTQwOTE4LnNydmFwZS5jb206ODAwMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1676413867
oDTZj6f7Wk99kDpPRXVQzNlxGzDxcHpwmSr2MD2s	\N	167.94.138.45	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTHM0c004YXF3Y05YTmZKTlNaS201WmJVcm9mQjBFRkZTaWlwb0JqciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xODguMTI3LjIzMS4xMzg6ODAwMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1676415931
K6fSS1uCw5pTqKN1LfvHL0b6zGhIKiTAKvBc17Mh	\N	188.127.231.138	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36	YTo1OntzOjc6InBlclBhZ2UiO2k6MTU7czo2OiJfdG9rZW4iO3M6NDA6InEwNkNDeWM3NkhwOVFnc0VqQlc2N1cwSDdCVjJDZVJJNlhnWUY1S0UiO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjI3OiJodHRwOi8vNzcxNTM3Ny5ydS9lbXBsb3llZXMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM6InVybCI7YToxOntzOjg6ImludGVuZGVkIjtzOjI3OiJodHRwOi8vNzcxNTM3Ny5ydS9lbXBsb3llZXMiO319	1676410915
LfIERVrzmzXc7odbSEndRBEtDlhQPLXxmhSXn5RN	\N	188.127.231.138	Mozilla/5.0 (compatible; StatOnlineRuBot/1.0)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHpLOUVHUU94QUdYMzNFWHM3VFluR2hjMXBlSUtXanI5Mjcyd2ltZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjM6Imh0dHA6Ly83NzE1Mzc3LnJ1L2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1676411125
RiHlaLO5E69YB9uKwAPyMjJRxyQDx91SAnjNqQTi	\N	109.74.204.123	curl/7.54.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYm1MdWVSN1g2MnVNVDQ0RERnSEhnaEF6cUsxdzUyV3RqbGpQZ1V5YiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9zNTQwOTE4LnNydmFwZS5jb206ODAwMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1676413862
mG7LdgQCLFqBPwGYYtm3EYEkuDdPxHlgTIp0GobS	\N	109.74.204.123	Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMEM1NEpJTm9MSGhxS0U0bktRUUg4ZE5nTnNlUmtucVVueU1mcVMwaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTA6Imh0dHA6Ly93d3ciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1676413869
gsVqmIAI5NaC90HPSqyTAxrr0FmHC0uiS1bNB7su	\N	167.248.133.60	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRWhxQlhvcjVXWTNLcGpFcTVLaHZibExBNFRhUjVLUnY0Njh4OE9IVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xODguMTI3LjIzMS4xMzg6ODAwMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1676415933
Ew5aE0uTQQ9w7ylnEjEhbc2GXaPrmro7wIfYLJFo	\N	109.74.204.123	curl/7.54.0	YToyOntzOjY6Il90b2tlbiI7czo0MDoiQnFNUU9yaTdlMXZxOE10RlpqSE53NkRDSUxTaWU5Tm9EdWoxWHY5YiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1676413862
PVhdGkzAxmRrSaX17tO95ISeSDvn7IZBQLmsYAYc	\N	188.127.231.138	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36	YTo1OntzOjc6InBlclBhZ2UiO2k6MTU7czo2OiJfdG9rZW4iO3M6NDA6IkNMS3JWOWlubGNVS2ZMVk92QzJTQkNjTDJNbEl0QXNTZzlQaXNNYnQiO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjMxOiJodHRwOi8vd3d3Ljc3MTUzNzcucnUvZW1wbG95ZWVzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozMToiaHR0cDovL3d3dy43NzE1Mzc3LnJ1L2VtcGxveWVlcyI7fX0=	1676410915
AyWQcQTav11tByLPwCYomep5pmbqHH5eR6a1rpAw	\N	188.127.231.138	Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36; 360Spider	YTo1OntzOjc6InBlclBhZ2UiO2k6MTU7czo2OiJfdG9rZW4iO3M6NDA6Ims2OUI3b05kZ1lLSktHeFRJUFQxV1BDM0JzbWcxWmVXUFRROEdIZEciO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjI3OiJodHRwOi8vd3d3Ljc3MTUzNzcucnUvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM6InVybCI7YToxOntzOjg6ImludGVuZGVkIjtzOjMxOiJodHRwOi8vd3d3Ljc3MTUzNzcucnUvZW1wbG95ZWVzIjt9fQ==	1676412509
jUVYUpXEIpm2CDglbQq0pzrctk2XKhro0ilq5z2y	\N	109.74.204.123		YTozOntzOjY6Il90b2tlbiI7czo0MDoiY1ZxV1JMblFmVmhBWmJ3TGpDQ2c0WHVLMjVHRjhKaDRRTEdEUEhuSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTM6Imh0dHA6Ly9lbS5sb2MiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1676413877
AtKlxXNg2TuNQ79eWbcldbyeykGzBASSNUq4YbPO	\N	188.127.231.138	Expanse, a Palo Alto Networks company, searches across the global IPv4 space multiple times per day to identify customers&#39; presences on the Internet. If you would like to be excluded from our scans, please send IP addresses/domains to: scaninfo@paloaltonetworks.com	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNDJTTGQ0bDdzOVRVdG5oMUMycWFzbzAzT2VsNW1MSk9FZ1JNZTZ2SSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTc6Imh0dHA6Ly83NzE1Mzc3LnJ1Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1676418740
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.staff (id, year, month, employer_id, employees, user_ids, created_at, updated_at) FROM stdin;
1	2009	06	4	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
2	2009	07	4	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
3	2009	08	4	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
4	2009	09	4	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
5	2009	10	4	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
6	2009	11	4	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
7	2009	12	4	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
8	2016	01	1	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
9	2016	02	1	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
10	2016	03	1	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
11	2016	04	1	[4]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
12	2016	05	1	[4, 21]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
13	2016	06	1	[4, 21, 22, 24, 17, 25, 26, 27]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
14	2016	07	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
15	2016	08	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
16	2016	09	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
17	2016	10	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
18	2016	11	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
19	2016	12	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
20	2017	01	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
21	2017	02	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
22	2017	03	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
23	2017	04	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
24	2017	05	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
25	2017	06	5	[55]	[2]	2023-01-06 20:45:00	2023-01-06 20:45:00
26	2017	06	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
27	2017	07	5	[55]	[2]	2023-01-06 20:45:00	2023-01-06 20:45:00
28	2017	07	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
29	2017	08	5	[55]	[2]	2023-01-06 20:45:00	2023-01-06 20:45:00
30	2017	08	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
31	2017	09	5	[55]	[2]	2023-01-06 20:45:00	2023-01-06 20:45:00
32	2017	09	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45]	[2, 3, 4, 5]	2023-01-06 20:45:00	2023-01-06 20:45:00
33	2017	10	5	[55]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
34	2017	10	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45, 42, 48, 49]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
35	2017	11	5	[55]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
36	2017	11	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45, 42, 48, 49, 73, 67]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
37	2017	12	5	[55]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
38	2017	12	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45, 42, 48, 49, 73, 67]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
39	2018	01	5	[55]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
40	2018	01	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45, 42, 48, 49, 73, 67, 62]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
41	2018	02	5	[55]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
42	2018	02	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45, 42, 48, 49, 73, 67, 62]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
43	2018	03	5	[55]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
44	2018	03	1	[4, 21, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45, 42, 48, 49, 73, 67, 62, 23, 20, 19, 29]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
45	2018	04	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
46	2018	04	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45, 42, 48, 49, 73, 67, 62, 23, 20, 19, 29]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
47	2018	05	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
48	2018	05	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 33, 45, 42, 48, 49, 73, 67, 23, 20, 19, 29, 31, 38, 32, 40, 34, 39]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
49	2018	06	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
50	2018	06	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 45, 42, 49, 67, 23, 20, 19, 29, 31, 38, 32, 40, 34, 39, 43]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
51	2018	07	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
52	2018	07	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 46, 67, 23, 20, 19, 29, 31, 38, 32, 40, 34, 39, 43]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
53	2018	08	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
54	2018	08	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 23, 20, 19, 29, 31, 38, 32, 40, 34, 39]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
55	2018	09	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
56	2018	09	4	[90, 85, 84, 88, 86, 89]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
57	2018	09	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 23, 20, 19, 29, 31, 38, 32, 40, 34, 39, 105, 87, 82]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
58	2018	10	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
59	2018	10	4	[85, 84, 88, 86, 89, 97]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
60	2018	10	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 23, 20, 19, 29, 31, 38, 32, 40, 34, 39, 105, 87, 82, 47, 63]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
61	2018	11	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
62	2018	11	4	[85, 84, 88, 86, 89, 97, 101, 94, 104]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
63	2018	11	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 23, 20, 19, 29, 31, 38, 32, 40, 34, 39, 105, 87, 82, 47, 63, 70, 72, 68, 66, 15]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
64	2018	12	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
65	2018	12	4	[85, 84, 88, 86, 89, 97, 101, 94, 104, 106, 107]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
66	2018	12	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 23, 20, 19, 29, 31, 38, 32, 40, 34, 39, 105, 87, 82, 47, 63, 70, 72, 68, 66, 15, 75, 74, 77, 76, 78, 79]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
67	2019	01	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
68	2019	01	4	[85, 84, 88, 86, 89, 97, 101, 94, 104, 106, 107]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
124	2020	03	4	[85, 89, 97, 94, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
165	2021	03	4	[89, 94, 185, 98, 99, 91]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
69	2019	01	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 23, 19, 29, 31, 38, 32, 40, 34, 39, 105, 87, 82, 47, 63, 70, 72, 68, 66, 15, 74, 77, 76, 78, 79, 80]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
70	2019	01	7	[125, 111, 110, 108, 115]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
71	2019	02	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
72	2019	02	4	[85, 84, 88, 86, 89, 97, 101, 94, 104, 81, 59, 36, 37, 113, 112]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
73	2019	02	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 19, 29, 31, 32, 40, 34, 39, 105, 87, 82, 47, 63, 70, 72, 68, 66, 15, 74, 77, 76, 78, 79, 80]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
74	2019	02	7	[125, 111, 110, 108, 115, 132, 134, 135, 133, 131, 130, 123, 124, 118, 120, 127, 124, 123, 120, 118, 119, 122]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
75	2019	03	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
76	2019	03	4	[85, 88, 86, 89, 97, 101, 94, 104, 81, 59, 36, 37, 113, 112]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
77	2019	03	1	[4, 22, 24, 17, 25, 26, 27, 159, 154, 153, 40, 34, 39, 105, 87, 82, 47, 63, 70, 72, 68, 66, 15, 74, 76, 78, 80]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
78	2019	03	7	[125, 111, 110, 108, 132, 134, 135, 133, 131, 130, 123, 124, 118, 120, 127, 124, 123, 120, 118, 119, 122, 140, 136, 138, 137, 145, 139]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
79	2019	04	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
80	2019	04	4	[85, 88, 86, 89, 97, 101, 94, 104, 81, 59, 36, 37, 113]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
81	2019	04	1	[4, 22, 24, 25, 26, 27, 159, 154, 153, 40, 34, 105, 87, 82, 47, 63, 70, 72, 68, 66, 15, 74, 76, 78, 80]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
82	2019	04	7	[125, 111, 110, 108, 132, 134, 135, 133, 131, 130, 123, 124, 118, 127, 124, 123, 118, 119, 122, 140, 136, 138, 137, 145, 139, 142]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
83	2019	05	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
84	2019	05	4	[85, 88, 86, 89, 97, 101, 94, 104, 81, 59, 36, 37, 113]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
85	2019	05	1	[4, 22, 24, 25, 26, 27, 159, 154, 153, 34, 105, 87, 82, 63, 70, 72, 68, 66, 15, 76, 78, 80]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
86	2019	05	7	[125, 111, 110, 108, 134, 133, 131, 130, 123, 118, 127, 123, 118, 119, 122, 140, 136, 138, 137, 145, 139, 142, 144, 149, 148, 146]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
87	2019	06	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
88	2019	06	4	[85, 88, 86, 89, 97, 101, 94, 104, 81, 59, 36, 37, 113]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
89	2019	06	1	[4, 22, 24, 25, 26, 27, 159, 154, 153, 105, 87, 82, 63, 70, 72, 68, 66, 15, 76, 78, 80, 44, 41]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
90	2019	06	7	[125, 111, 110, 108, 134, 133, 131, 130, 123, 118, 127, 123, 118, 119, 122, 140, 136, 138, 137, 145, 139, 142, 149, 148, 146, 162, 163, 164]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
91	2019	07	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
92	2019	07	4	[85, 88, 86, 89, 97, 101, 94, 81, 59, 36, 37, 113]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
93	2019	07	1	[4, 22, 24, 25, 26, 27, 159, 154, 153, 105, 87, 82, 70, 72, 68, 66, 15, 76, 78, 80, 44, 41, 65, 50, 64]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
94	2019	07	7	[125, 110, 108, 134, 133, 131, 130, 123, 118, 127, 123, 118, 119, 122, 140, 136, 137, 145, 142, 149, 148, 146, 162, 163, 164, 167, 171]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
95	2019	08	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
96	2019	08	4	[85, 88, 86, 89, 97, 101, 94, 81, 59, 36, 37, 113]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
97	2019	08	1	[4, 22, 24, 25, 26, 27, 159, 154, 153, 105, 87, 82, 70, 72, 68, 66, 15, 76, 78, 80, 44, 41, 65, 50, 64]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
98	2019	08	7	[125, 108, 134, 131, 130, 123, 118, 127, 123, 118, 122, 136, 137, 145, 142, 149, 148, 162, 163, 167, 171, 173, 174, 172]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
99	2019	09	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
100	2019	09	4	[85, 88, 86, 89, 97, 94, 81, 59, 36, 37, 113]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
101	2019	09	1	[4, 22, 24, 25, 26, 27, 159, 154, 153, 105, 87, 82, 70, 72, 68, 66, 15, 76, 78, 80, 44, 41, 65, 50, 170]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
102	2019	09	7	[125, 131, 130, 123, 118, 127, 123, 118, 136, 137, 145, 142, 149, 148, 162, 163, 167, 171, 173, 174, 172]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
103	2019	10	5	[55, 54]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
104	2019	10	4	[85, 88, 89, 97, 94, 81, 59, 36, 37, 113]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
105	2019	10	1	[4, 22, 24, 25, 26, 27, 159, 154, 153, 105, 87, 82, 70, 72, 68, 66, 15, 76, 78, 80, 44, 41, 65, 50, 170, 180, 177]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
106	2019	10	7	[125, 131, 130, 123, 127, 123, 136, 137, 162, 167, 171, 165]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
107	2019	11	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
108	2019	11	4	[85, 88, 89, 97, 94, 59, 36, 37, 113]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
109	2019	11	1	[4, 22, 24, 25, 26, 27, 159, 154, 153, 105, 87, 82, 70, 72, 68, 66, 15, 76, 78, 80, 44, 41, 50, 170, 180, 177, 178, 183, 184]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
110	2019	11	7	[125, 131, 130, 123, 127, 123, 136, 137, 162, 171]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
111	2019	12	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
112	2019	12	4	[85, 88, 89, 97, 94, 36, 37]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
113	2019	12	1	[4, 22, 24, 25, 26, 27, 159, 154, 153, 105, 87, 82, 68, 76, 78, 41, 50, 170, 180, 177, 178, 183, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
114	2019	12	7	[125, 131, 130, 123, 127, 123, 136, 137, 162, 171, 188, 191]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
115	2020	01	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
116	2020	01	4	[85, 89, 97, 94, 36, 37, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
117	2020	01	1	[4, 22, 24, 25, 26, 27, 159, 105, 82, 68, 76, 78, 41, 170, 177, 178, 183, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
118	2020	01	7	[125, 131, 130, 123, 127, 123, 136, 137, 171, 188, 191]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
119	2020	02	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
120	2020	02	4	[85, 89, 97, 94, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
121	2020	02	1	[4, 22, 24, 25, 26, 27, 159, 105, 82, 68, 78, 170, 177, 178, 183, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
122	2020	02	7	[130, 123, 127, 123]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
123	2020	03	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
125	2020	03	1	[4, 22, 24, 25, 26, 27, 159, 105, 82, 68, 78, 170, 177, 178, 183, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
126	2020	03	7	[130, 123, 127, 123, 96, 92, 195]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
127	2020	04	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
128	2020	04	4	[85, 89, 97, 94, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
129	2020	04	1	[4, 22, 25, 26, 159, 105, 82, 68, 78, 170, 177, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
130	2020	04	7	[130, 123, 127, 123, 96, 92, 195]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
131	2020	05	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
132	2020	05	4	[85, 89, 94, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
133	2020	05	1	[4, 22, 25, 26, 159, 105, 82, 78, 177, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
134	2020	05	7	[123, 127, 123]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
135	2020	06	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
136	2020	06	4	[85, 89, 94, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
137	2020	06	1	[4, 22, 25, 26, 159, 105, 82, 78, 177, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
138	2020	06	7	[123, 127, 123]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
139	2020	07	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
140	2020	07	4	[85, 89, 94, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
141	2020	07	1	[4, 22, 25, 26, 159, 105, 82, 78, 177, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
142	2020	07	7	[123, 127, 123]	[3, 4, 5, 2]	2023-01-06 20:45:01	2023-01-06 20:45:01
143	2020	08	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
144	2020	08	4	[85, 89, 94, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
145	2020	08	1	[4, 22, 25, 26, 159, 105, 82, 78, 177, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
146	2020	09	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
147	2020	09	4	[85, 89, 94, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
148	2020	09	1	[4, 22, 25, 26, 159, 105, 82, 78, 177, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
149	2020	10	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
150	2020	10	4	[85, 89, 94, 185]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
151	2020	10	1	[4, 22, 25, 26, 159, 105, 82, 78, 177, 184, 182]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
152	2020	11	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
153	2020	11	4	[85, 89, 94, 185, 98, 99]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
154	2020	11	1	[4, 22, 25, 26, 159, 105, 82, 78, 177, 184, 182, 28, 190, 83, 69, 71]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
155	2020	12	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
156	2020	12	4	[85, 89, 94, 185, 98, 99]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
157	2020	12	1	[4, 22, 25, 26, 159, 105, 82, 78, 177, 184, 182, 28, 190, 83, 69, 71]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
158	2021	01	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
159	2021	01	4	[89, 94, 185, 98, 99, 91]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
160	2021	01	1	[4, 22, 25, 26, 159, 105, 184, 182, 28, 190, 83, 69, 71]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
161	2021	02	5	[55, 54, 58]	[2]	2023-01-06 20:45:01	2023-01-06 20:45:01
162	2021	02	4	[89, 94, 185, 98, 99, 91]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
163	2021	02	1	[4, 22, 25, 26, 159, 105, 184, 182, 28, 190, 83, 69, 71]	[2, 3, 4, 5]	2023-01-06 20:45:01	2023-01-06 20:45:01
164	2021	03	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
166	2021	03	1	[4, 22, 25, 26, 159, 105, 184, 182, 28, 190, 83, 69, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
167	2021	04	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
168	2021	04	4	[89, 94, 185, 98, 99, 91]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
169	2021	04	1	[4, 22, 25, 26, 159, 105, 184, 182, 28, 190, 83, 69, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
170	2021	05	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
171	2021	05	4	[89, 94, 99, 91]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
172	2021	05	1	[4, 22, 159, 105, 184, 182, 28, 190, 83, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
173	2021	06	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
174	2021	06	4	[89, 94, 99, 91]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
175	2021	06	1	[4, 22, 159, 105, 184, 182, 28, 190, 83, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
176	2021	07	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
177	2021	07	4	[89, 94, 99, 91]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
178	2021	07	1	[4, 22, 159, 105, 184, 182, 28, 190, 83, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
179	2021	08	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
180	2021	08	4	[89, 94, 99, 91]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
181	2021	08	1	[4, 22, 159, 105, 184, 182, 28, 190, 83, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
182	2021	09	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
183	2021	09	4	[89, 94, 99, 91, 147]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
184	2021	09	1	[4, 22, 159, 105, 184, 182, 28, 190, 83, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
185	2021	10	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
186	2021	10	4	[89, 94, 99, 91, 147]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
187	2021	10	1	[4, 22, 105, 184, 182, 28, 190, 83, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
188	2021	11	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
189	2021	11	4	[89, 94, 99, 91, 147]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
190	2021	11	1	[4, 22, 105, 184, 182, 28, 190, 83, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
191	2021	12	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
192	2021	12	4	[89, 94, 99, 91, 147]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
193	2021	12	1	[4, 22, 105, 184, 182, 28, 190, 83, 71]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
194	2022	01	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
195	2022	01	4	[94, 99, 91, 147]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
196	2022	01	1	[4, 105, 184, 182, 28, 190, 83]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
197	2022	02	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
198	2022	02	4	[94, 99, 91, 147]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
199	2022	02	1	[4, 105, 184, 182, 28, 190, 83, 200]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
200	2022	03	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
201	2022	03	4	[94, 99, 91, 147, 203, 202]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
202	2022	03	1	[4, 105, 184, 182, 28, 190, 83, 200, 206, 194, 205, 209, 212, 208]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
203	2022	04	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
204	2022	04	4	[94, 99, 91, 147, 203, 202, 201]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
205	2022	04	1	[4, 105, 184, 182, 28, 190, 83, 200, 206, 194, 205, 209, 212, 208, 218]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
206	2022	05	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
207	2022	05	4	[147, 203, 202, 201]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
208	2022	05	1	[4, 105, 184, 182, 190, 83, 200, 206, 194, 205, 209, 212, 208, 218, 226, 223]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
209	2022	06	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
210	2022	06	4	[147, 203, 202, 201]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
211	2022	06	1	[4, 105, 184, 182, 190, 83, 200, 206, 194, 205, 209, 212, 208, 218, 226, 223, 224, 225]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
212	2022	07	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
213	2022	07	4	[147, 203, 202, 201, 16, 227, 230, 241]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
214	2022	07	1	[4, 105, 184, 182, 200, 206, 194, 205, 209, 212, 208, 218, 226, 223, 224, 225, 3, 241]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
215	2022	08	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
216	2022	08	4	[147, 203, 202, 201, 16, 227, 230, 241]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
217	2022	08	1	[4, 105, 184, 182, 200, 206, 194, 205, 209, 212, 208, 218, 226, 223, 224, 225, 3, 241]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
218	2022	09	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
219	2022	09	4	[147, 203, 202, 201, 16, 227, 230, 241]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
220	2022	09	1	[4, 105, 184, 200, 206, 194, 205, 209, 212, 208, 218, 226, 223, 224, 225, 3, 241]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
221	2022	10	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
222	2022	10	4	[147, 203, 202, 201, 16, 227, 230, 241, 235, 236, 237]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
223	2022	10	1	[4, 105, 184, 200, 206, 194, 205, 209, 212, 208, 218, 224, 225, 3, 241]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
224	2022	11	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
225	2022	11	4	[147, 203, 202, 16, 227, 230, 241, 235, 236, 237]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
226	2022	11	1	[4, 105, 200, 206, 205, 209, 212, 208, 218, 224, 225, 3, 241, 240, 239, 238]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
227	2022	12	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
228	2022	12	4	[147, 203, 202, 16, 227, 230, 241, 235, 236, 237]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
229	2022	12	1	[4, 105, 200, 206, 205, 209, 212, 208, 218, 224, 225, 3, 241, 240, 239, 238]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-06 20:45:02
230	2023	01	5	[55, 54, 58]	[2]	2023-01-06 20:45:02	2023-01-06 20:45:02
232	2023	01	1	[4, 105, 200, 206, 205, 209, 212, 208, 218, 224, 225, 3, 241, 240, 239, 238, 246, 247]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-01-18 11:51:19
233	2023	02	5	[55, 54, 58]	[2]	2023-02-01 00:00:00	2023-02-01 00:00:00
235	2023	02	1	[4, 105, 200, 206, 205, 209, 212, 208, 218, 224, 225, 3, 241, 240, 239, 238, 246, 247]	[2, 3, 4, 5]	2023-02-01 00:00:00	2023-02-01 00:00:00
231	2023	01	4	[147, 203, 202, 16, 230, 241, 235, 236, 237]	[2, 3, 4, 5]	2023-01-06 20:45:02	2023-02-01 00:00:00
234	2023	02	4	[203, 202, 16, 230, 241, 235, 236, 237]	[2, 3, 4, 5]	2023-02-01 00:00:00	2023-02-01 00:00:00
\.


--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.statuses (id, name_en, name_ru, user_ids) FROM stdin;
1	Boss	Руководитель	["*"]
2	Cancelled	Аннулирован	["*"]
3	Client	Контрагент	["*"]
4	Denied	Отказан	["*"]
5	Family member	Член семьи	["*"]
6	Fired	Уволен	["*"]
7	On leave	В отпуске	["*"]
8	Left	Убыл	["*"]
9	Official	Чиновник	["*"]
10	Seeker	Соискатель	["*"]
11	Hired	Работник	["*"]
12	Arrived	Прибыл	["*"]
\.


--
-- Data for Name: team_invitations; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.team_invitations (id, team_id, email, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: team_user; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.team_user (id, team_id, user_id, role, created_at, updated_at) FROM stdin;
1	4	3	admin	2022-11-15 13:00:12	2022-11-15 13:00:12
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.teams (id, user_id, name, personal_team, created_at, updated_at) FROM stdin;
1	1	admin	t	2022-11-15 12:57:35	2022-11-15 12:57:54
2	2	Nam's Team	t	2022-11-15 12:58:36	2022-11-15 12:58:36
3	3	Юля's Team	t	2022-11-15 12:59:36	2022-11-15 12:59:36
4	1	editor	f	2022-11-15 13:00:00	2022-11-15 13:00:00
\.


--
-- Data for Name: telescope_entries; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.telescope_entries (sequence, uuid, batch_id, family_hash, should_display_on_index, type, content, created_at) FROM stdin;
\.


--
-- Data for Name: telescope_entries_tags; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.telescope_entries_tags (entry_uuid, tag) FROM stdin;
\.


--
-- Data for Name: telescope_monitoring; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.telescope_monitoring (tag) FROM stdin;
\.


--
-- Data for Name: types; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.types (id, user_ids, code, created_at, updated_at) FROM stdin;
1	["*"]	LEGAL_RUS	2022-12-10 12:13:05	\N
2	["*"]	LEGAL_SEMI	2022-12-10 12:13:05	\N
3	["*"]	LEGAL_FOREIGN	2022-12-10 12:13:05	\N
4	["*"]	INDIVIDUAL	2022-12-10 12:13:05	\N
5	["*"]	PRIVATE	2022-12-10 12:13:05	\N
6	["*"]	NOTARY	2022-12-10 12:13:05	\N
7	["*"]	LAWYER	2022-12-10 12:13:05	\N
8	["*"]	FOREIGN_BRANCH	2022-12-10 12:13:05	\N
9	["*"]	FOREIGN_REP	2022-12-10 12:13:05	\N
10	["*"]	UFMS	2022-12-10 12:13:05	\N
11	["*"]	OUFMS	2022-12-10 12:13:05	\N
12	["*"]	CLIENT	2022-12-10 12:13:05	\N
\.


--
-- Data for Name: usage_permits; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.usage_permits (id, name_ru, user_ids, signing_date, history, address_id, employer_id, created_at, updated_at) FROM stdin;
1	Договор аренды помещения № 5	[3, 2, 4]	2022-06-14	\N	2	4	2022-12-10 12:17:46	2022-12-10 12:17:46
2	Договор аренды помещения № 6	[3, 2, 4]	2022-06-14	\N	2	1	2022-12-10 12:17:46	2022-12-10 12:17:46
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: robert
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, current_team_id, profile_photo_path, created_at, updated_at, two_factor_secret, two_factor_recovery_codes) FROM stdin;
2	Nam	nrobert@mail.ru	\N	$2y$10$txES3t5LPu1GV3vKK/KecuPDqtggdVYHRhaeSSQ5E7KErQoEvxnm6	\N	2	\N	2022-11-15 12:58:36	2022-11-15 12:58:36	\N	\N
1	Robert	7715377@mail.ru	\N	$2y$10$B7UNo94pxQnv3ihVjiFQveKN0p0notJqZaskrqMWvAtWOAAuPBRzy	YLgvgQ1IcDUrm4qDmjH43NyI4tBBt6Of9O7yNv9d7mXDrnqkfD65rfeVeP61	4	profile-photos/h5IMCsE0IRk7TRC29KeObeZFcLfAOhHTXeoNzV9O.jpg	2022-11-15 12:57:35	2023-01-02 12:33:27	\N	\N
3	Кимры	ooolisbel@mail.ru	\N	$2y$10$bDI1TUlpzpAtG75Z23UetuMcCnuGSE8SBZrgI/WwQWLP9lCP1yX1a	WOwfDhsIp0KlNFcu4b0kb0wlKzPRjsDoDCwehXtYUD0mEdQ3YXZ6v4IZzbZb	3	\N	2022-11-15 12:59:36	2022-11-15 12:59:36	\N	\N
\.


--
-- Name: addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.addresses_id_seq', 21, true);


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.countries_id_seq', 240, true);


--
-- Name: employee_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.employee_job_id_seq', 217, true);


--
-- Name: employee_turnover_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.employee_turnover_id_seq', 510, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.employees_id_seq', 249, true);


--
-- Name: employers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.employers_id_seq', 15, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.migrations_id_seq', 50, true);


--
-- Name: occupations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.occupations_id_seq', 33, true);


--
-- Name: permits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.permits_id_seq', 85, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: quotas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.quotas_id_seq', 15, true);


--
-- Name: staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.staff_id_seq', 235, true);


--
-- Name: statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.statuses_id_seq', 13, true);


--
-- Name: team_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.team_invitations_id_seq', 1, false);


--
-- Name: team_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.team_user_id_seq', 1, true);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.teams_id_seq', 4, true);


--
-- Name: telescope_entries_sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.telescope_entries_sequence_seq', 1, false);


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.types_id_seq', 13, true);


--
-- Name: usage_permits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.usage_permits_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: robert
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: employee_job employee_job_employee_id_employer_id_occupation_id_hired_date_f; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employee_job
    ADD CONSTRAINT employee_job_employee_id_employer_id_occupation_id_hired_date_f UNIQUE (employee_id, employer_id, occupation_id, hired_date, fired_date);


--
-- Name: employee_job employee_job_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employee_job
    ADD CONSTRAINT employee_job_pkey PRIMARY KEY (id);


--
-- Name: employee_turnover employee_turnover_employee_id_employer_id_date_status_id_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employee_turnover
    ADD CONSTRAINT employee_turnover_employee_id_employer_id_date_status_id_unique UNIQUE (employee_id, employer_id, date, status_id);


--
-- Name: employee_turnover employee_turnover_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employee_turnover
    ADD CONSTRAINT employee_turnover_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: employers employers_name_ru_taxpayer_id_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employers
    ADD CONSTRAINT employers_name_ru_taxpayer_id_unique UNIQUE (name_ru, taxpayer_id);


--
-- Name: employers employers_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employers
    ADD CONSTRAINT employers_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: occupations occupations_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.occupations
    ADD CONSTRAINT occupations_pkey PRIMARY KEY (id);


--
-- Name: permits permits_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.permits
    ADD CONSTRAINT permits_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: quotas quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.quotas
    ADD CONSTRAINT quotas_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: staff staff_year_month_employer_id_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_year_month_employer_id_unique UNIQUE (year, month, employer_id);


--
-- Name: statuses statuses_name_en_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_name_en_unique UNIQUE (name_en);


--
-- Name: statuses statuses_name_ru_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_name_ru_unique UNIQUE (name_ru);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: team_invitations team_invitations_email_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.team_invitations
    ADD CONSTRAINT team_invitations_email_unique UNIQUE (email);


--
-- Name: team_invitations team_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.team_invitations
    ADD CONSTRAINT team_invitations_pkey PRIMARY KEY (id);


--
-- Name: team_user team_user_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.team_user
    ADD CONSTRAINT team_user_pkey PRIMARY KEY (id);


--
-- Name: team_user team_user_team_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.team_user
    ADD CONSTRAINT team_user_team_id_user_id_unique UNIQUE (team_id, user_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: telescope_entries telescope_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.telescope_entries
    ADD CONSTRAINT telescope_entries_pkey PRIMARY KEY (sequence);


--
-- Name: telescope_entries telescope_entries_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.telescope_entries
    ADD CONSTRAINT telescope_entries_uuid_unique UNIQUE (uuid);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: usage_permits usage_permits_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.usage_permits
    ADD CONSTRAINT usage_permits_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: employees_last_name_ru_citizenship_id_passport_number_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX employees_last_name_ru_citizenship_id_passport_number_index ON public.employees USING btree (last_name_ru, citizenship_id, passport_number);


--
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX password_resets_email_index ON public.password_resets USING btree (email);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: quotas_year_employer_id_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX quotas_year_employer_id_index ON public.quotas USING btree (year, employer_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: teams_user_id_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX teams_user_id_index ON public.teams USING btree (user_id);


--
-- Name: telescope_entries_batch_id_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX telescope_entries_batch_id_index ON public.telescope_entries USING btree (batch_id);


--
-- Name: telescope_entries_created_at_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX telescope_entries_created_at_index ON public.telescope_entries USING btree (created_at);


--
-- Name: telescope_entries_family_hash_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX telescope_entries_family_hash_index ON public.telescope_entries USING btree (family_hash);


--
-- Name: telescope_entries_tags_entry_uuid_tag_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX telescope_entries_tags_entry_uuid_tag_index ON public.telescope_entries_tags USING btree (entry_uuid, tag);


--
-- Name: telescope_entries_tags_tag_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX telescope_entries_tags_tag_index ON public.telescope_entries_tags USING btree (tag);


--
-- Name: telescope_entries_type_should_display_on_index_index; Type: INDEX; Schema: public; Owner: robert
--

CREATE INDEX telescope_entries_type_should_display_on_index_index ON public.telescope_entries USING btree (type, should_display_on_index);


--
-- Name: employee_job employee_job_employee_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employee_job
    ADD CONSTRAINT employee_job_employee_id_foreign FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_turnover employee_turnover_employee_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.employee_turnover
    ADD CONSTRAINT employee_turnover_employee_id_foreign FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: staff staff_employer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_employer_id_foreign FOREIGN KEY (employer_id) REFERENCES public.employers(id) ON DELETE CASCADE;


--
-- Name: team_invitations team_invitations_team_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.team_invitations
    ADD CONSTRAINT team_invitations_team_id_foreign FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: telescope_entries_tags telescope_entries_tags_entry_uuid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.telescope_entries_tags
    ADD CONSTRAINT telescope_entries_tags_entry_uuid_foreign FOREIGN KEY (entry_uuid) REFERENCES public.telescope_entries(uuid) ON DELETE CASCADE;


--
-- Name: usage_permits usage_permits_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: robert
--

ALTER TABLE ONLY public.usage_permits
    ADD CONSTRAINT usage_permits_address_id_foreign FOREIGN KEY (address_id) REFERENCES public.addresses(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

